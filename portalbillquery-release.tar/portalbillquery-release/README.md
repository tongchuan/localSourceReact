# portalbillquery
bgy - portalbillquery （碧桂园财务共享项目 >> 总账 >> portal端单据查询优化）
