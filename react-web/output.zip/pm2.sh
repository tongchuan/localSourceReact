# npm run build or npm run build238
pm2 start server.js --name 'meta'
# stop
# pm2 stop meta
