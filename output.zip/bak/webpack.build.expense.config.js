//友报账
var path = require('path');
var webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
// const CompressionPlugin = require("compression-webpack-plugin");
const moment = require('moment');
const childProcess = require('child_process');

const DEFAULT_PROD_SERVER = '172.20.4.88:8088';

// 获取版本
const packageJSON = require('./package.json');
const GIT_REVISION = childProcess.execSync('git rev-parse HEAD').toString().trim();

module.exports = {
     devtool: 'source-map',

    //可以配置多个入口模块
    entry: {
        index: [
            './src/expense/index'
        ]
    },

    //输出目标
    output: {
        path: path.join(__dirname, 'client/expense/js'),
        filename: '[name].js', //Template based on keys in entry above
        publicPath: 'js/'
    },

    //common.js 是公共模块
    plugins: [
        new webpack.optimize.CommonsChunkPlugin('common.js'),
        new webpack.optimize.DedupePlugin(),
        new webpack.optimize.AggressiveMergingPlugin(),
        new webpack.NoErrorsPlugin(),
        new webpack.optimize.OccurenceOrderPlugin(),
        new webpack.optimize.UglifyJsPlugin({
            comments: false,
            compress: {
                warnings: false
            }
        }),
        // new CompressionPlugin({//gzip 压缩
        //     asset: "[path].gz[query]",
        //     algorithm: "gzip",
        //     test: /\.(js|html)$/,//压缩 js 与 html
        //     threshold: 10240,
        //     minRatio: 0.8
        // }),
        new webpack.DefinePlugin({
            'process.env': {
                'NODE_ENV': JSON.stringify('production'),
                'PROD_SERVER': JSON.stringify(process.env.PROD_SERVER || DEFAULT_PROD_SERVER)
            }
        }),
        new HtmlWebpackPlugin({
            template: 'client/expense/index.hbs',
            hash: true,
            // User defined options
            version: packageJSON.version,
            revision: GIT_REVISION,
            buildTime: moment().format('YYYY-MM-DD HH:mm:ss')
        })
        // // Transfer Files
        // new TransferWebpackPlugin([
        //     {from: 'www'},
        // ], path.resolve(__dirname, 'src')),
        // new ManifestPlugin({
        //     fileName:  'manifest.json'
        // })
    ],

    resolve: {
        extensions: ['', '.js', '.jsx']
    },
    module: {
        loaders: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                loaders: ['babel'],
                include: __dirname
            },
            {
                test: /\.css$/,
                loader: 'style-loader!css-loader'
            },
            {
                test: /\.less$/,
                loader: 'style-loader!css-loader!less-loader'
            },
            {
                test: /\.(png|jpg|bmp)$/,
                loader: 'url-loader?limit=8192'
            },
            {
                test: /\.hbs$/,
                loader: 'handlebars-loader'
            }
        ]
    }
};

