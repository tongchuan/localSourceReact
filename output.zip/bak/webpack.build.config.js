//友报账
var path = require('path');
var webpack = require('webpack');
const DEFAULT_PROD_SERVER = '172.20.13.230:8090';

module.exports = {
    devtool: 'source-map',
    //devtool: 'cheap-module-eval-source-map',

    //可以配置多个入口模块
    entry: {
        index: [
            './src/expense/index'
        ]
    },

    //输入目标
    output: {
        path: path.join(__dirname, 'client/expense/js'),
        filename: '[name].js', //Template based on keys in entry above
        publicPath: '/client/expense/js/'
    },

    //common.js 是公共模块
    plugins: [
        new webpack.optimize.CommonsChunkPlugin('common.js'),
        /**
         * This is where the magic happens! You need this to enable Hot Module Replacement!
         */
        new webpack.HotModuleReplacementPlugin(),
        new webpack.NoErrorsPlugin(),
        new webpack.optimize.OccurenceOrderPlugin(),
        /*new webpack.optimize.UglifyJsPlugin({
         compress: {
         warnings: false
         }
         }),*/
        // // Transfer Files
        // new TransferWebpackPlugin([
        //     {from: 'www'},
        // ], path.resolve(__dirname, 'src')),
        // new ManifestPlugin({
        //     fileName:  'manifest.json'
        // })
        /**
         * DefinePlugin allows us to define free variables, in any webpack build, you can
         * use it to create separate builds with debug logging or adding global constants!
         * Here, we use it to specify a development build.
         */
        new webpack.DefinePlugin({
            'process.env':{
                'NODE_ENV':JSON.stringify('development'),
                'PROD_SERVER': JSON.stringify(process.env.PROD_SERVER || DEFAULT_PROD_SERVER)
            }

        })
    ],

    resolve: {
        extensions: ['', '.js', '.jsx']
    },

    module: {
        loaders: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                loader: 'babel',
                query: {
                    presets: ['es2015', 'stage-0', 'react']
                },
                include: __dirname
            },
            {
                test: /\.css$/,
                loader: 'style-loader!css-loader'
            },
            {
                test: /\.less$/,
                loader: 'style-loader!css-loader!less-loader'
            },
            {
                test: /\.(png|jpg|bmp)$/,
                loader: 'url-loader?limit=8192'
            }
        ]
    }
};
