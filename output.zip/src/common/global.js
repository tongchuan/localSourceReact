var Global = {
    env : 'production'
};

export default Global;