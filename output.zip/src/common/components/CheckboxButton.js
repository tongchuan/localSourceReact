
import React from 'react';

export default class CheckboxButton extends React.Component {
    render() {
        return (
            <div>
                <h4></h4>
                <p></p>
            </div>
        );
    }
};
