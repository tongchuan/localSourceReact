/**
 * 公用请求地址配置文件
 * chenliw@yonyou.com
 * @type {string}
 */

//调用java api的url
var serverUrl  =  location.protocol + "//"+location.host+"/" ;  //发布地址
if (process.env.NODE_ENV === 'development') {
    var serverUrl = 'http://172.20.4.89:8080/';
}
var Config = {
    BABLANCE:{ //结算中心
      //获取待支付数据
      getTableData:serverUrl+'nodebillpay/getshowplanpaydata',
      //已支付
      getTableDataCheck:serverUrl+'nodebillpay/getshowpaysucessdata',
      //支付账户
      sendPaybankacc:serverUrl+'nodebillpay/dealbillpaybankacc',
      //支付成功
      sendPlaySuccess:serverUrl+'nodebillpay/dealbillpaystatussucess',
      //导出支付文件
      sendExport:serverUrl+'nodebillpay/exportbankform',
      //银行参照
      blankRefer:location.protocol+'//'+process.env.PROD_SERVER+'/refbase_ctr/queryRefJSON',
      //支付账户参照
      payAccountRefer: serverUrl + 'pay/querypayaccount',
      //点击支付
      BillPaySend:serverUrl+'nodebillpay/billpaysend',
      // 获取流水号
      getReqSeqNO: serverUrl + 'pay/getreqseqno',
      // 预下单
      onlinePay: serverUrl + 'pay/onlinepay',
      // 预下单取消
      porderCancel: serverUrl + 'pay/pordercancel',
      // 预下单确认
      porderConfirm: serverUrl + 'pay/porderconfirm',
      // 支付结果状态更新
      queryPayResult: serverUrl + 'pay/querypayresult',
      //更新支付状态
      sendBillPayQueryStatues:serverUrl+'nodebillpay/billpayquerystatues'
    },
    BPM:{
        MYTODO : serverUrl+ 'bpm/mytodo',  //我的待办
        MYHASDO : serverUrl+ 'bpm/myhasdo', //我的已办
        MYTODOSEARCH : serverUrl+ 'bpm/mytodo_search', //我的待办模糊查询
        MYHASDOSEARCH : serverUrl+ 'bpm/myhasdo_search', //我的已办模糊查询
        WFHIS :serverUrl+ 'bpm/wfhis',   // 我的待办流程历史
        WFHISBYBUSINESSKEY : serverUrl + 'bpm/wfhisByBusinessKey',  // 我的单据流程历史
        APPROVE :serverUrl+ 'bpm/approve',    //流程审批
        ASSIGNCHECK:serverUrl+ 'bpm/assigncheck',   //获取当前环节的下一环节的指派列表
        REJECTACTIVITIES:serverUrl+ 'bpm/rejectactivities' , //驳回活动列表
        WITHDRAW:serverUrl + 'bpm/withdraw' ,  //取消审批
    },
    NODE:{
        GETNODESBYDATE: serverUrl+ 'node/getNodesByDate',    //按日期排序账本列表接口
        LODETOTALBILL: serverUrl+ 'node/lodeTotalBill' ,  //我的单据查询接口
        listbytype:serverUrl + 'billtypequery/listbytype' ,
        listBillType:serverUrl + 'billtypequery/listbilltype',
        LOADBILL:serverUrl + 'node/loadBills',    //新单据列表接口
        systemIsNc:serverUrl +'/node/systemIsNc', //1:nc系统   0:saas 系统
    },
    PRINT:{
       GETPRINTDATA: serverUrl + 'print/getPrintData' , //发送打印请求前获取相关数据
       GETPRINTDATAHTML: serverUrl + '/print/getPrintDataHtml' ,
       DESIGNVERIFY: serverUrl + 'print/designVerify',
    },
    COMMON:{
        GETBILLTYPE:serverUrl + 'common/getBillType'  // 获取单据类型接口
    },
    HOMEPAGE:{
        CONSUMPTIONANALYSIS: serverUrl + 'experienceAccount/consumptionAnalysis', //取得统计图表数据
        FOURNUMBER: serverUrl + 'experienceAccount/fourNumber',   // 借款，报账 ，进行 ，异常 四大数据
        MYTODOLIST: serverUrl + 'experienceAccount/mytodoList',   // 待办
        MYBILLLIST: serverUrl + 'experienceAccount/myBillList',   // 单据列表
        MYTOBEPAIDLIST: serverUrl + 'experienceAccount/mytobePaidList'  // 支付列表
    },
    SYSTEM:{
        systemIsNc:serverUrl +'/node/systemIsNc', //1:nc系统   0:saas 系统
    }
};

export default Config;
