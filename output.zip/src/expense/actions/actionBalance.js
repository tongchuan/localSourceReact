/**
 * author:zhangtongchuan
 * date: 2017-00-03
 * mail: zhangtch@yonyou.com
 */
import Api from '../../common/restfulApi';
import Config from '../config'

var rootPath = Config.serverUrl;
var api = new Api(rootPath);

// Config.BABLANCE.getTableData="http://127.0.0.1:88/nodebillpay/getshowplanpaydata"//获取待支付数据
// Config.BABLANCE.getTableDataCheck="http://127.0.0.1:88/nodebillpay/getshowpaysucessdata"//已支付
// Config.BABLANCE.sendPaybankacc="http://127.0.0.1:88/nodebillpay/dealbillpaybankacc"//支付账户
// Config.BABLANCE.sendPlaySuccess="http://127.0.0.1:88/nodebillpay/dealbillpaystatussucess"//支付成功
// Config.BABLANCE.sendExport="http://127.0.0.1:88/nodebillpay/exportbankform"//导出支付文件
// Config.BABLANCE.BillPaySend="http://127.0.0.1:88/nodebillpay/billpaysend"
// Config.BABLANCE.sendBillPayQueryStatues="http://127.0.0.1:88/nodebillpay/billpayquerystatues"
// Config.BABLANCE.blankRefer='http://127.0.0.1:88/nodeexpensestandard/json'

// 更新支付状态
export function sendBillPayQueryStatues(data,callback) {
  return (dispatch, getState) => {
    $.ajax({
        type: "post",
        url:  Config.BABLANCE.sendBillPayQueryStatues,
        data: JSON.stringify(data),
        dataType: "json",
        contentType:"application/json;charset=utf-8",
        success: data => {
          callback(undefined,data);
        },
        error: (xhr, status, err) => {
          callback(err);
        }
    });
  }
}


//  点击支付
export function sendBillPaySend(data,callback) {
  return (dispatch, getState) => {
    $.ajax({
        type: "post",
        url: Config.BABLANCE.BillPaySend,
        data: JSON.stringify(data),
        dataType: "json",
        contentType:"application/json;charset=utf-8",
        success: data => {
          callback(undefined,data);
        },
        error: (xhr, status, err) => {
          callback(err);
        }
    });
  }
}

/**
 * 获取流水号，支付相关接口必须调用，所以设置为同步方法
 */
export function getReqSeqNO(data, successCb, failureCb) {
  return (dispatch, getState) => {
    $.ajax({
      type: "post",
      async: false,
      url: Config.BABLANCE.getReqSeqNO,
      data: JSON.stringify(data),
      dataType: "json",
      contentType:"application/json;charset=utf-8",
      success: data => {
        data.code == 0 ? successCb(data) : failureCb(data.information || '获取单据流水号错误');
      },
      error: (xhr, status, err) => {
        callback(err);
      }
    });
  }
}

/**
 * 支付结果状态查询更新接口，如果是在线支付也需要uKey的支持，需要先调用getReqSeqNO接口获取流水号
 */
export function queryPayResult(data, successCb, failureCb) {
  return (dispatch, getState) => {
    $.ajax({
      type: "post",
      url: Config.BABLANCE.queryPayResult,
      data: JSON.stringify(data),
      dataType: "json",
      contentType:"application/json;charset=utf-8",
      success: data => {
        data.code == 0 ? successCb(data) : failureCb(data.information || '预下单确认出现错误')
      },
      error: (xhr, status, err) => {
        callback(err);
      }
    });
  }
}

/**
 * 方法名对应后台名称，虽然叫作onlinePay，其实后台会根据payType来判断是线上还是线下，调用之前必须调用getReqSeqNO接口获取流水号
 */
export function onlinePay(data, successCb, failureCb) {
  return (dispatch, getState) => {
    $.ajax({
      type: "post",
      url: Config.BABLANCE.onlinePay,
      data: JSON.stringify(data),
      dataType: "json",
      contentType:"application/json;charset=utf-8",
      success: data => {
        data.code == 0 ? successCb(data) : failureCb(data.information || '支付遇到未知错误')
      },
      error: (xhr, status, err) => {
        callback(err);
      }
    });
  }
}

/**
 * 确认支付接口，onlinePay接口返回成功后用户如果点击确认则调用此接口，也需要先调用getReqSeqNO接口获取流水号
 */
export function porderConfirm(data, successCb, failureCb) {
  return (dispatch, getState) => {
    $.ajax({
      type: "post",
      url: Config.BABLANCE.porderConfirm,
      data: JSON.stringify(data),
      dataType: "json",
      contentType:"application/json;charset=utf-8",
      success: data => {
        data.code == 0 ? successCb(data) : failureCb(data.information || '支付出现错误')
      },
      error: (xhr, status, err) => {
        callback(err);
      }
    });
  }
}

/**
 * 取消支付接口，onlinePay接口返回成功后如果点击取消则调用此接口，也需要先调用getReqSeqNO接口获取流水号
 */
export function porderCancel(data, successCb, failureCb) {
  return (dispatch, getState) => {
    $.ajax({
      type: "post",
      url: Config.BABLANCE.porderCancel,
      data: JSON.stringify(data),
      dataType: "json",
      contentType:"application/json;charset=utf-8",
      success: data => {
        data.code == 0 ? successCb(data) : failureCb(data.information || '取消支付失败');
      },
      error: (xhr, status, err) => {
        callback(err);
      }
    });
  }
}

//获取待支付数据
export function getTableData(type,data,callback) {
  let url = Config.BABLANCE.getTableData;
  if(type!=0){
    url =Config.BABLANCE.getTableDataCheck;
  }
  return (dispatch, getState) => {
    $.ajax({
      type: "post",
        url: url,
        data: JSON.stringify(data),
        dataType: "json",
        contentType:"application/json;charset=utf-8",
        success: data => {
          callback(undefined,data);
        },
        error: (xhr, status, err) => {
          callback(err);
        }
    });
  }

}


//支付账户
export function sendPaybankacc(data,callback){
  return (dispatch, getState) => {
    $.ajax({
        type: "post",
        url: Config.BABLANCE.sendPaybankacc,
        data: JSON.stringify(data),
        dataType: "json",
        contentType:"application/json;charset=utf-8",
        success: data => {
          callback(undefined,data);
        },
        error: (xhr, status, err) => {
          // console.log(arguments)
          callback(err);
        }
    });
  }
}


//支付成功
export function sendPlaySuccess(data,callback){
  return (dispatch, getState) => {
    $.ajax({
        type: "post",
        url: Config.BABLANCE.sendPlaySuccess,
        data: JSON.stringify(data),
        dataType: "json",
        contentType:"application/json;charset=utf-8",
        success: data => {
          callback(undefined,data);
        },
        error: (xhr, status, err) => {
          // console.log(arguments)
          callback(err);
        }
    });
  }
}

//导出支付文件
export function sendExport(data,callback){
  return (dispatch, getState) => {
    $.ajax({
        type: "post",
        url: Config.BABLANCE.sendExport,
        data: JSON.stringify(data),
        dataType: "json",
        contentType:"application/json;charset=utf-8",
        success: data => {
          callback(undefined,data);
        },
        error: (xhr, status, err) => {
          // console.log(arguments)
          callback(err);
        }
    });
  }
}


export function getTableColumn(callback){
  return (dispatch, getState) => {
      let data = [
        { type: 'string', id: 'id', label: '单据id', hidden:true  },
        { type: 'ref', id: 'pk_billtype', label: '单据类型' ,align: 'left'},
        { type: 'string', id: 'descript', label: '事由' ,align: 'left'},
        { type: 'double', id: 'money', label: '金额',formatter: { format: '$0,0.00' } },
        { type: 'date', id: 'expenseDate', label: '报账日期' ,align: 'left'},
        { type: 'ref', id: 'billuserid', label: '报账人' ,align: 'left'},
        { type: 'ref', id: 'deptid', label: '部门' ,align: 'left'},
        { type: 'ref', id: 'pk_paybankacc', label: '银行账号' ,align: 'left'},
        { type: 'string', id: 'paytypename', label: '支付方式' ,align: 'left'},
        { type: 'string', id: 'paystatus', label: '支付状态' ,align: 'left'}
        /** 现在支付状态有两个字段，一个是paystatus一个是paystatuscode 两个都可以用
        {type: 'enum', id: 'paystatuscode', label: '支付状态', data: [
          {
            key: 'notpay',
            value: '未支付'
          },
          {
            key: 'paysucess',
            value: '支付成功'
          },
          {
            key: 'payfail',
            value: '支付失败'
          },
          {
            key: 'paying',
            value: '支付中'
          }
        ]}
        */
    ];
    callback(data);
  }
}

export function getTableColumnOld(callback){
  return (dispatch, getState) => {
    let isSystemNC = false;
    let data = [
      { type: 'string', id: 'id', label: '单据id', hidden:true  },
      /*{ type: 'ref', id: 'pk_billtype', label: '单据类型' ,align: 'left'},*/
      { type: 'string', id: 'serialNo', label: '单据编号' ,align: 'left'},
      { type: 'string', id: 'recaccname', label: '收款方' ,align: 'left', formatter: {
        type: 'custom',
        callback: value => value && value.length > 8 ? value.substr(0, 8) + '...' : value
      }},
      { type: 'string', id: 'descript', label: '事由' ,align: 'left'},
      { type: 'object', id: 'originalCurrency', label: '币种',formatter: {
          type: 'custom',
          callback: value => transformCurrency(value)
        } ,align: 'left'},
      { type: 'double', id: 'money', label: '金额',formatter: {} },
      { type: 'double', id: 'localMoney', label: '本币金额',formatter: {} },
      { type: 'date', id: 'expenseDate', label: '报账日期' ,align: 'left'},
      { type: 'ref', id: 'billuserid', label: '报账人' ,align: 'left'},
      { type: 'ref', id: 'deptid', label: '部门' ,align: 'left'},
      { type: 'string', id: 'recacc', label: '收款账户' ,align: 'left'},
      { type: 'string', id: 'paytypename', label: '支付方式' ,align: 'left'},
      { type: 'string', id: 'paystatus', label: '支付状态' ,align: 'left'}
    ];

    // 转换币种
    function transformCurrency( result ){
      return result ? result.name:'' ;
    }

    $.ajax({
      type: "post",
      url: Config.NODE.systemIsNc,
      data: JSON.stringify({}),
      dataType: "json",
      contentType:"application/json;charset=utf-8",
      success: result => {
        if(result.code == 1) {  // nc系统，去掉单据编号
          data = data.filter(item => item.id !== 'serialNo');
        }
        callback(data);
      },
      error: (xhr, status, err) => {
        callback(data);
        console.error("判断系统NC/SASS失败，认为是SASS。");
      }
    });
  }
}
