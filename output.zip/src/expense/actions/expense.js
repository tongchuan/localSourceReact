/**
 * Created by liuyyg on 2017/1/17.
 */
import Api from '../../common/restfulApi';
import Config from '../config'

var rootPath = Config.serverUrl;
var api = new Api(rootPath);

export function getVoucherData(callback) {
    return (dispatch, getState) => {
        api.postApi(url, state => {
            console.log(state);
        },suss =>{
            if (suss.success == true) {
                if (typeof callback === 'function') {
                    callback(suss.rows);
                }
            }
        },err => {
            console.log(err);
        });
    };
}

// ajax公用方法封装  chenliw  测试用

export function getExpenseJSON(url , param , method , callback,async){
    method = method || "post";
    var params = JSON.stringify(param)
    if(method == "get" || method == "GET" ){
        params = param
    }
    return () => {
        $.ajax({
            type: method ,
            url: url+"?t="+ new Date().getTime(),
            dataType: "json",
            contentType: "application/json",
            async:async===false?false:true,
            data: params ,
            success: data => {
                if (typeof callback === 'function') {
                    callback(data);
                }
            },
            error: (xhr, status, err) => {
                console.log(err.toString());
            }
        });

    }

}
