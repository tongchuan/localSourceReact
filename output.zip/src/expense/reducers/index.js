import { combineReducers } from 'redux';
import voucher from './voucher'
import balance from './balance'
const rootReducer = combineReducers({
    voucher,
    balance
});

export default rootReducer;
