const initState = {
    voucher: {} //首页的状态信息
};

export default initState;