/**
 * author:zhangtongchuan
 * date: 2017-00-03
 * mail: zhangtch@yonyou.com
 */
 const initBalanceState = {
     UserInfoWidget: {
         numbers: {
             "total_user_number": 0,
             "active_user_number": 0,
             "inactive_user_number": 0,
             "forbidden_user_number": 0,
             "unknown_user_number": 0
         }
     }
 };
export default function balance(state = initBalanceState, action) {
    switch (action.type) {
        default:
            return state;
    }
}
