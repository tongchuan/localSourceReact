/**
 * Created by liuyyg on 2017/1/17.
 */
const initVoucherState = {
    UserInfoWidget: {
        numbers: {
            "total_user_number": 0,
            "active_user_number": 0,
            "inactive_user_number": 0,
            "forbidden_user_number": 0,
            "unknown_user_number": 0
        }
    }
};
export default function voucher(state = initVoucherState, action) {
    switch (action.type) {
        default:
            return state;
    }
}
 