import React from 'react';
import ReactDom from 'react-dom';

import { Provider } from 'react-redux';
import { Router, Route, Link, IndexRoute, hashHistory } from 'react-router';

import appStore from './appStore';
import App from './containers/App';
import NoMatch from './components/NoMatch';
import ToIndex from './components/ToIndex';
import ToApply from './components/ToApply';
import ToBill from './components/ToMyBill';
import ToServe from './components/ToMyServe';
import WaitDealt from './components/MyWaitDealt';
// import ToBalance from './components/ToBalance';
import Balance from './containers/Balance';
import BalancePay from './containers/BalancePay';

import BillDetail from './components/ToMyBillDetail'
import MappingTemplate from './containers/MappingTemplate'; // 模板映射
import BillList from './components/ToBillList';
import BillListTest from './components/ToBillListTest';
import HomePage from './containers/HomePage';
const store = appStore()

ReactDom.render(
    <Provider store={store}>
        <Router  history={hashHistory}>

            <Route path="/" component={App}>
                <IndexRoute component={HomePage}/>
                <Route path="/toIndex" component={ToIndex}></Route>
                <Route path="/toBalance" component={Balance}></Route>
                <Route path="/balance" component={BalancePay}></Route>
                {/**
                  <Route path="/toBalance" component={Balance}></Route>
                  <Route path="/balance" component={BalancePay}></Route>*/}
                <Route path="/toApply" component={ToApply}></Route>
                <Route path="/toBill" component={ToBill}></Route>
                <Route path="/toServe" component={ToServe}></Route>
                <Route path="/waitDealt" component={WaitDealt}></Route>
                <Route path="/waitDealt/:type" component={WaitDealt}></Route>
                <Route path="/toBillDetail" component={BillDetail}></Route>
                <Route path="/MappingTemplate" component={MappingTemplate}></Route>
                <Route path="/toBillList" component={BillList}></Route>
                <Route path="/toBillListTest" component={BillListTest}></Route>
                <Route path="/homepage" component={HomePage}></Route>
                <Route path="*" component={NoMatch}/>
            </Route>
        </Router>
    </Provider>,
    document.getElementById('root')
);
