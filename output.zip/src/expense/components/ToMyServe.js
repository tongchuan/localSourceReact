import React from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import * as expense from '../actions/expense';

class ToMyServe extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    render() {
        return (
            <div className="main-content">
                 toserve.js
            </div>
        );
    }
};

//影射Store的State到App的Props, 这里用做数据
function mapStateToProps(state) {
    return state.voucher;
}

//影射Store的dispath到App的Props,这里用做操作(事件)
function mapDispatchToProps(dispatch) {
    return bindActionCreators(expense, dispatch);
}

//练接是中间组件react-redux功能,用于把React的Props, State, Event和Redux的关联
export default connect(mapStateToProps, mapDispatchToProps)(ToMyServe);