import classNames from 'classnames';
import React, { Component, PropTypes } from 'react';
import { Button } from 'react-bootstrap';

export default class Modal extends Component {
  static propTypes = {

  }

  constructor(props){
    super(props);
    this.state={
      id:'show'+Math.random(),
      title:'',
      children:'',
      timeout:0,
      closeClick:null,
      confirmClick:null,
    }
    this.show = this.show.bind(this);
    this.closeClick = this.closeClick.bind(this);
    this.confirmClick = this.confirmClick.bind(this);
    this.setTimeFun = this.setTimeFun.bind(this);
  }
  show(option={
    title:'',
    children:'',
    show:false,
    timeout:0,
    closeClick:null,
    confirmClick:null,
  }){

    this.setState({
      title:option.title ? option.title : this.state.title,
      children:option.children ?  option.children : this.state.children,
      show:option.closeClick ?  option.show : this.state.show,
      timeout:option.timeout ?  option.timeout : 0,
      closeClick:option.closeClick,
      confirmClick:option.confirmClick,
    });
    console.log(this.state);
    document.getElementById(this.state.id).style.display='block';
  }
  closeClick(event){
    document.getElementById(this.state.id).style.display='none';
    event.preventDefault();
    if(typeof this.state.closeClick=='function'){
      this.state.closeClick();
    }

  }
  confirmClick(event){
    document.getElementById(this.state.id).style.display='none';
    event.preventDefault();
    if(typeof this.state.confirmClick=='function'){
      this.state.confirmClick();
    }

  }
  componentDidMount(){
    this.setTimeFun();
  }
  componentDidUpdate(){
    this.setTimeFun();
  }
  setTimeFun(){
    let that = this;
    if(that.state.timeout!=0){
      setTimeout(()=>{
        document.getElementById(this.state.id).style.display='none';
      },that.state.timeout*1000)
    }
  }
  render(){
    let title =  this.state.title;
    let children =  this.state.children;
    let butConfirm = this.state.confirmClick!=null ? <button type="button" onClick={this.confirmClick} className="btn btn-primary">确定</button>: ''
    let butCancel = this.state.closeClick!=null ? <button type="button" onClick={this.closeClick} className="btn btn-default">取消</button> : ''
    return (
      <div id={this.state.id} className="modal fade in" style={{background:"rgba(0,0,0,.6)"}}>
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <button type="button" onClick={this.closeClick} className="close">
                <span>×</span>
              </button>
              <h4 className="modal-title">{title}</h4>
            </div>
            <div className="modal-body">
              {children}
            </div>
            <div className="modal-footer">
              {butCancel}
              {butConfirm}
            </div>
          </div>
        </div>
    </div>
    );
  }
}
