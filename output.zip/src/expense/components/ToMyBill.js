/**
 * chenliw@yonyou.com
 */
import React from 'react';
import { Grid } from 'ssc-grid';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import * as expense from '../actions/expense';
import  Dialog  from '../../common/components/StaticModel';
import _  from 'lodash' ;
import Config from '../config';
import Spinner  from './spinner/spinner';

import { createHistory } from 'history';
const history = createHistory() ;

class ToMyBill extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            gridList :[] ,
            checkBoxList :[],
            nodeType : []
        }
    }

    componentWillMount = ()=>{
        this.getGridList();
    }




    getGridList = () =>{
        var param ={
            date:null
        }
        this.props.getExpenseJSON(Config.NODE.GETNODESBYDATE,param,"post",function(json){
            json
            debugger;
            console.log(json)

        })

        var _list = {
            "code":"0",
            "content":{
                "2016-10-18":[
                    {
                        "id":3,
                        "userId":"PzSC7qrbh7Aiszq8IM0tX",
                        "pk":"BlSClLpVOWHj5fkt4nw5f",
                        "filepath":null,
                        "money":0,
                        "payDate":1476720000000,
                        "payee":"ee",
                        "payWay":"现金支付",
                        "item":"ss",
                        "valid":true,
                        "expense":false,
                        "note":"",
                        "tagContent":"",
                        "tags":null,
                        "ts":null,
                        "type":"pay",
                        "imageSystemType":"siit"
                    },
                    {
                        "id":2,
                        "pk":"25SCF9Z5EAwYeayU7Wwrn",
                        "userId":"PzSC7qrbh7Aiszq8IM0tX",
                        "materiel":"1",
                        "unitprice":1,
                        "number":1,
                        "unit":"个",
                        "money":1,
                        "taxrate":0.01,
                        "tax":0.01,
                        "gatherDate":1476720000000,
                        "invoiceNumber":"111",
                        "payee":"ww",
                        "filepath":null,
                        "expense":false,
                        "valid":true,
                        "ts":null,
                        "note":"",
                        "tagContent":"",
                        "tags":null,
                        "type":"gather",
                        "imageSystemType":"siit"
                    },
                    {
                        "id":19,
                        "pk":"5iSChJvsKltqtpyw5R4Ra",
                        "userId":"PzSC7qrbh7Aiszq8IM0tX",
                        "phoneNumber":"15623315329",
                        "money":300,"communicateType":"移动电话",
                        "communicateDate":1476720000000,
                        "filepath":null,
                        "expense":false,
                        "valid":true,
                        "ts":1476755296000,
                        "communicateStart":1475251200000,
                        "communicateEnd":1477843200000,
                        "category":null,
                        "imageSystemType":"siit",
                        "type":"communicate",
                        "note":"",
                        "tagContent":"",
                        "tags":null
                    }
                ],
                "2016-10-21":[
                    {
                        "accessToken":null,
                        "id":null,
                        "pk":"geSCOiaywlWLqBncgBH5b",
                        "userId":"PzSC7qrbh7Aiszq8IM0tX",
                        "money":369,
                        "company":"肯德基",
                        "personNum":1,
                        "eatingDate":1476979200000,
                        "filepath":null,
                        "valid":true,
                        "expense":false,
                        "ts":null,
                        "note":"",
                        "tagContent":"出差",
                        "tags":null,
                        "type":"eating",
                        "imageSystemType":"siit"
                    },
                    {
                        "id":27,
                        "pk":"ZJSCGw4jLN9DNkV9G9IVT",
                        "userId":"PzSC7qrbh7Aiszq8IM0tX",
                        "phoneNumber":"15623315329",
                        "money":50,
                        "communicateType":"移动电话",
                        "communicateDate":1476979200000,
                        "filepath":null,
                        "expense":false,
                        "valid":true,
                        "ts":1477013864000,
                        "communicateStart":1475251200000,
                        "communicateEnd":1477843200000,
                        "category":null,
                        "imageSystemType":"siit",
                        "type":"communicate",
                        "note":"",
                        "tagContent":"出差",
                        "tags":null
                    }
                ],
                "2016-10-24":[
                    {
                        "id":4,
                        "userId":"PzSC7qrbh7Aiszq8IM0tX",
                        "pk":"hNSCYWVRQqN3JPAZtyF7B",
                        "filepath":null,
                        "money":14,
                        "buyDate":1477238400000,
                        "buyee":"看看",
                        "buyWay":"现金支付",
                        "item":"静",
                        "valid":true,
                        "expense":false,
                        "note":"",
                        "tagContent":"出差",
                        "tags":null,
                        "type":"buy",
                        "ts":null,
                        "imageSystemType":"siit"
                    },
                    {
                        "id":6,
                        "userId":"PzSC7qrbh7Aiszq8IM0tX",
                        "pk":"bXSCije5cDfGqlbjHc4Ic",
                        "filepath":null,
                        "money":44,
                        "payDate":1477238400000,
                        "payee":"11",
                        "payWay":"现金支付",
                        "item":"11",
                        "valid":true,
                        "expense":false,
                        "note":"",
                        "tagContent":"",
                        "tags":null,
                        "ts":null,
                        "type":"pay",
                        "imageSystemType":"siit"
                    },
                    {"id":7,"pk":"7MSC8drscSNeDsVWcBnfm","userId":"PzSC7qrbh7Aiszq8IM0tX","materiel":"e","unitprice":1,"number":1,"unit":"个","money":1,"taxrate":0.04,"tax":0.04,"gatherDate":1477238400000,"invoiceNumber":"1","payee":"d","filepath":null,"expense":false,"valid":true,"ts":null,"note":"","tagContent":"出差","tags":null,"type":"gather","imageSystemType":"siit"},
                    {"id":30,"pk":"iiSCi5xeJRuNix1Ugqcyx","userId":"PzSC7qrbh7Aiszq8IM0tX","phoneNumber":"15623315329","money":50,"communicateType":"移动电话","communicateDate":1477238400000,"filepath":null,"expense":false,"valid":true,"ts":1477296927000,"communicateStart":1475251200000,"communicateEnd":1477843200000,"category":null,"imageSystemType":"siit","type":"communicate","note":"","tagContent":"出差","tags":null},
                    {"id":125,"pk":"6TSC3f9XaP1Nvi0oPuglS","userId":"PzSC7qrbh7Aiszq8IM0tX","money":23,"otherDate":1477238400000,"filepath":null,"expense":false,"valid":true,"note":"","tagContent":"出差","tags":null,"ts":null,"type":"other","taxrate":0,"includtax":0,"nottax":23,"invoicenum":"","invoicetype":"0","imageSystemType":"siit"},
                    {"id":4,"pk":"J5SCJGANbvVkseARIJ7kO","userId":"PzSC7qrbh7Aiszq8IM0tX","materiel":"1","unitprice":1,"number":1,"money":1,"taxrate":0.01,"tax":0.01,"saleDate":1477238400000,"invoiceNumber":"111","costomer":"114","filepath":null,"expense":false,"valid":true,"ts":1477297308000,"unit":null,"tags":null,"note":"","tagContent":"出差","type":"sale","imageSystemType":"siit"}
                ]
            }
        } ;

        var list = [] ;
        _.forEach(_list.content , function( value ,key ){
            _.forEach(value , function(v2 , k2 ){
                list.push(v2) ;
            })
        })

        $.each(list , function( ind ,obj ){
            obj.sign = ind ;       //标识 重新组装来自9张表的数据，保持唯一性 chenliw 用
        })

        this.setState({
            gridList:list
        }) ;
    }

    //表格复选框事件，供按钮事件监听
    handleSelect=  (rowIdx, rowObj, isSelected, event) =>{

        var checkBoxList =this.state.checkBoxList ;
        if( isSelected ){
            checkBoxList.push({"tabKey" :rowObj.sign , "tabVal":rowObj.type}) ;
        }else{
            for(var i = 0 ; i< checkBoxList.length ; i++){
                if(checkBoxList[i].tabKey == rowObj.sign  ){
                    checkBoxList.splice(i ,1 ) ;
                    break;
                }
            }
        }
        this.setState({
            checkBoxList : checkBoxList
        })
        console.log(checkBoxList)
    }

    testSpinner = () => {
        this.setState({
            loading : true
        });
        setTimeout(
          () => {
              this.setState({
                  loading : false
              });
          }
          ,1000);
    }

    // 根据所选打开modal框
    submitTable = () =>{
        var _this = this ;
        var checkBoxList = this.state.checkBoxList ;
        if(!checkBoxList || checkBoxList.length ==0 ){
            var message = {
                'showModal': true,
                'title': "提示",
                'message': "请选中内容后再报账"
            };
            _this.refs.dialogs.showAlert(message)
            return false ;
        }
        var _data ={
            "code":"0",
            "information":[
                {
                    "nodetypes":["communicate","eating"],
                    "icon":"receipt_jiaotongfeibaoxiao",
                    "billtype":"交通费专项",
                    "isConfig":"true",
                    "type":"bx",
                    "pk":"WPSCc45y3ZLivOHzBnhl6"
                },
                {
                    "nodetypes":["pay","travel","communicate","hotel","eating","other"],
                    "icon":"receipt_chailvbaoxiao",
                    "billtype":"支持差旅",
                    "isConfig":"false",
                    "type":"bx",
                    "pk":"jqSC9fkDKskD0talTiBaY"
                },
                {
                    "nodetypes":["pay"],
                    "icon":"receipt_fukuandan",
                    "billtype":"付款单",
                    "isConfig":"false",
                    "type":"fk",
                    "pk":"cBSCZTURM3HdOpVRCRNQR"
                }
            ]
        };
        // 数组排序 去重 拆分
        var allCheckBox = [];
        $.each(checkBoxList ,function( ind , obj ){
            allCheckBox.push(obj.tabVal)
        })
        $.unique(allCheckBox.sort());

        var modalSign  =  [] ;
        $.each(_data.information , function(ind , obj ){
            var  nodeTypes = obj.nodetypes.sort() ;
            var  result0 =  allCheckBox.length;
            var  result1  = _this.compareArray( allCheckBox , nodeTypes );
            if(result0 == result1) {
                modalSign.push ( {result: obj} ) ;
            }
        })
        console.log(modalSign);

        if( modalSign && modalSign.length > 0) {
            var content = (
              <div className="panel panel-primary">
                  <div className="panel-heading"><span className="glyphicon glyphicon-hand-right"></span> 单击打开单据</div>
                  <div className="panel-body">
                      {modalSign.map(function (val, ind) {
                          return( <p key={"panel-b-"+ind} onclick={_this.openBill.bind(this,val.result) }>{val.result.billtype}</p>)
                      })}
                  </div>
              </div>
            );
            var message = {
                'showModal': true,
                'title': "单据",
                'message': content
            };
            _this.refs.dialogs.showAlert(message)

        }else{
            var message = {
                'showModal': true,
                'title': "提示",
                'message': "您所选的单据不符合报销类型！"
            };
            _this.refs.dialogs.showAlert(message)
        }


    }

    openBill =( param ) =>{
        // location.href="#/toBillDetail"
        history.push({
            pathname: '#/toBillDetail',
            search: '?a=query',

            // 一些不存在url参数上面的当前url的状态值
            state: { the: 'state' }
        })

    }

    setGrid = () =>{
        var tableData=this.state.gridList;
        // imageSystemType : default为默认，siit为国信
        var mockColumnsData = [
            { type: 'string', id: 'sign', label: '前端标识',hidden:true  }, // 0未    1 已报账
            { type: 'string', id: 'expense', label: '报账状态',hidden:true  }, // 0未    1 已报账
            { type: 'string', id: 'filepath', label: '未知' ,hidden:true },
            { type: 'string', id: 'id', label: 'ID',hidden:true  },
            { type: 'string', id: 'imageSystemType', label: '影像系统标识' },
            { type: 'string', id: 'item', label: '项目' },
            { type: 'double', id: 'money', label: '金额' },
            { type: 'string', id: 'note', label: '备注' },
            { type: 'string', id: 'payDate', label: '报账日期' },
            { type: 'string', id: 'payWay', label: '支付方式' },
            { type: 'string', id: 'payee', label: '付款单位' },
            { type: 'string', id: 'pk', label: 'PK',hidden:true },
            { type: 'string', id: 'tagContent', label: '标签' },
            { type: 'string', id: 'tags', label: '标签List',hidden:true },
            { type: 'string', id: 'ts', label: '时间戳',hidden:true  },
            { type: 'string', id: 'type', label: '记事类型' },
            { type: 'string', id: 'userId', label: '用户ID',hidden:true  },
            { type: 'string', id: 'valid', label: '是否有效',hidden:true  }  // 0已删除  1 有效
        ];

        return (
          <Grid columnsModel={mockColumnsData} tableData={tableData} className="ssc-grid"
                operateColumn ={true} paging={true}
                selectRow={{
                      mode: 'checkbox',
                      onSelect: this.handleSelect.bind(this)
                    }}
          />
        )
    }

    render() {
        var _this = this ;
        return (
          <div className="main-content to-my-bill">
              {_this.setGrid() }
              <div className="btn-bottom-fixed">
                  <div className="row btn-bottom">
                      <div className="col-sm-12">
                          <button type="button" className="btn btn-warning fr" onClick={_this.submitTable}>报账</button>
                      </div>
                  </div>
              </div>
              {/* {_this.gridButton() } */}
              <Dialog ref="dialogs"/>
              <Spinner show={this.state.loading} text="努力加载中..."></Spinner>
          </div>
        );
    }


    /**
     * obj2 是否包含 obj1   PS：obj 都是去重后的数组
     * @param obj1
     * @param obj2
     * @return sign  number类型，如果sign = obj1.length  匹配成功
     * */
    compareArray = ( obj1 , obj2 )=>{
        var sign =  0 ;
        for(var i = 0 ; i < obj2.length ; i ++ ){
            for(var j =0 ; j< obj1.length ; j++){
                if(obj2[i] == obj1[j]){
                    sign= sign +1 ;
                }
            }
        }
        return sign;
    }

};
//影射Store的State到App的Props, 这里用做数据
function mapStateToProps(state) {
    return state.voucher;
}

//影射Store的dispath到App的Props,这里用做操作(事件)
function mapDispatchToProps(dispatch) {
    return bindActionCreators(expense, dispatch);
}

//练接是中间组件react-redux功能,用于把React的Props, State, Event和Redux的关联
export default connect(mapStateToProps, mapDispatchToProps)(ToMyBill);
