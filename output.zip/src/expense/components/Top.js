import React from 'react';
import { Link } from 'react-router';

export default class Top extends React.Component {
    constructor(props) {
        super(props);

    }

    closeSideNav = () => {
        var dom = $(".sidenav-container");
        dom.toggleClass("hide");
    }

    render() {
        var _this = this;
        let nav = (
            <div className="top-nav-box">
                <div className="top-nav-ham pull-left" onClick={_this.closeSideNav.bind(this)}>
                    <span className="glyphicon glyphicon-menu-hamburger"></span>
                </div>
                <div className="top-nav-logo">
                    <img src="image/demo/demo-portal-logo.png" width="30px" height="30px"/>
                    <span>友报账 企业智能报账云平台</span>
                </div>
                <div className="top-nav-setting fr">
                    <img src="image/demo/demo-portal-logo.png" alt="" width="30px" height="30px"/>
                    <div>
                        <p>友账表</p>
                        <p>友报账</p>
                    </div>
                    <span className="glyphicon glyphicon-menu-down"></span>
                </div>
                <div className="top-nav-notice fr">
                    <span className="glyphicon glyphicon-bell"></span>
                </div>
                <div className="top-nav-contact fr">
                    <span className="glyphicon glyphicon-headphones"></span>
                </div>
                <div className="top-nav-search fr">
                    <input type="text" placeholder="请输入..." />
                    <i className="glyphicon glyphicon-search"></i>
                </div>
            </div>
        );

        return (
            <div className="portal-nav">
                {nav}
            </div>

        );
    }
};
