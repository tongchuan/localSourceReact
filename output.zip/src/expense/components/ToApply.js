import React from 'react';


export default class ToApply extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    render() {
        return (
            <div className="main-content">
                ToApply.js
            </div>
        );
    }
};
