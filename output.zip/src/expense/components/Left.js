/**
 * Created by liuyyg on 2017/1/20.
 */
import React from 'react';
import { Link } from 'react-router';

export default class Left extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            active: null,
            tree: {}
        }
    }

    renderNode = (node) => {

    };
    onClickNode = (node) => {
        this.setState({
            active: node
        });
    };
    handleChange = (tree) => {
        this.setState({
            tree: tree
        });
    };
    componentDidMount(){
        $('.sidenav-body .nav li').bind('click',function(){
            $('.sidenav-body .nav li').removeClass('nav-active');
            $(this).addClass('nav-active');
        });
    }

    render() {
        let _this = this;
        return (
            <section className="sidenav-container">
                <div className="sidenav-header">
                    {/**
                     <div className="company-logo"></div>
                     <div className="company-name nav-text-shrink shrink-hide"></div>
                     **/}
                </div>
                <div className="sidenav-body">
                    <ul className="nav">
                        <li className="nav-item">
                            <a href="#/toIndex" className="nav-link">
                                <div className="nav-icon">
                                    <i aria-hidden="true" className="glyphicon glyphicon-home"></i>
                                </div>
                                <span>首页</span>
                            </a>
                        </li>
                        <li className="nav-item">
                            <a href="#/toBalance" className="nav-link">
                                <div className="nav-icon">
                                    <i aria-hidden="true" className="glyphicon glyphicon-user"></i>
                                </div>
                                <span>结算中心</span>
                            </a>
                        </li>
                        <li className="nav-item">
                            <a href="#/toApply" className="nav-link">
                                <div className="nav-icon">
                                    <i aria-hidden="true" className="glyphicon glyphicon-user"></i>
                                </div>
                                <span>我的申请</span>
                            </a>
                        </li>

                        <li className="nav-item">
                            <a href="#/toBill" className="nav-link">
                                <div className="nav-icon">
                                    <i aria-hidden="true" className="glyphicon glyphicon-book"></i>
                                </div>
                                <span>我的账本</span>
                            </a>
                        </li>
                        <li className="nav-item">
                            <a href="#/toServe" className="nav-link">
                                <div className="nav-icon">
                                    <i aria-hidden="true" className="glyphicon glyphicon-heart"></i>
                                </div>
                                <span>我的服务</span>
                            </a>
                        </li>
                        <li className="nav-item">
                            <a href="#/waitDealt" className="nav-link">
                                <div className="nav-icon">
                                    <i aria-hidden="true" className="glyphicon glyphicon-heart"></i>
                                </div>
                                <span>我的代办</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </section>
        );
    }
};
