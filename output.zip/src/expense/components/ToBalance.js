import React from 'react';
import { Grid } from 'ssc-grid';
import Dialog from '../../common/components/StaticModel';
import Config  from './../config';

export default class ToBalance extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            tabIndex: 0,
            unCompleteList: [],
            completeList: [],
            selectedRowsObj: {}
        }
    }

    componentWillMount() {
        this.unCompleteList();
    }
    getTestData() {
        let data = [
            {
                "id": "40位主键",    //主键
                "pk_billtype": { "pk": "单据类型主键", "name": "类型名称" },     //单据类型
                "descript": "test",       //事由
                "expense_date": "2017-02-01",    //报账日期
                "money": "100.00",       //金额
                "billuserid": { "pk": "人员主键", "name": "人员名称" },               //报账人
                "deptid": { "pk": "部门主键", "name": "部门名称" },               //部门
                "pk_paybankacc": { "pk": "支付银行账户主键", "name": "银行账号" },       //支付银行账户
                "exportstatus": "已导出",                      //导出状态
                "paystatus": "支付成功"                    //支付状态
            },
            {
                "id": "40位主键",    //主键
                "pk_billtype": { "pk": "单据类型主键", "name": "类型名称" },     //单据类型
                "descript": "test",       //事由
                "expense_date": "2017-02-01",    //报账日期
                "money": "100.00",       //金额
                "billuserid": { "pk": "人员主键", "name": "人员名称" },               //报账人
                "deptid": { "pk": "部门主键", "name": "部门名称" },               //部门
                "pk_paybankacc": { "pk": "支付银行账户主键", "name": "银行账号" },       //支付银行账户
                "exportstatus": "已导出",                      //导出状态
                "paystatus": "支付成功"                    //支付状态
            }

        ];
        return data;
    }

    sendAjax(url, param, callback) {
        $.ajax({
            type: "post",
            url: url,
            dataType: "json",
            headers: {
                "Content-type": "application/json; charset=utf-8"
            },
            data: JSON.stringify(param),
            success: function (json) {
                if (json.success) {
                    if(json.dowbankfilenurl){
                        callback(json.dowbankfilenurl);
                    }else{
                        callback(json.data);
                    }
                } else {
                    alert("操作失败!");
                }
            }
        });
    }

    getSelectedRow(selectedRowsObj) {
        if (Object.keys(selectedRowsObj).length == 0) {
            alert("未选中任何行!");
        }
        let data = [];
        for (var index in selectedRowsObj) {
            if (selectedRowsObj[index].selected) {
                data.push(selectedRowsObj[index].row);
            }
        }
        return data;
    }

    getSelectedParam(selectedRowsObj) {
        let selectedRows = this.getSelectedRow(selectedRowsObj);
        let param = {
            "nodebillpayids": [],    //单据主键
            "userinfo": {}   //操作人信息
        };
        $.each(selectedRows, function (idx, obj) {
            param.nodebillpayids.push(obj.id);
        })
        param.userinfo = {
            pk: selectedRows[0].billuserid.pk,
            name: selectedRows[0].billuserid.name
        }
        return param;
    }

    handleSelect(rowIdx, rowObj, selected) {
        const {selectedRowsObj} = this.state;
        if(selected){
            selectedRowsObj[rowIdx] = { selected, row: rowObj };
        }else{
            delete selectedRowsObj[rowIdx];
        }
        this.setState({
            selectedRowsObj
        });
    }

    handleSelectAll(tableData, selected) {
        let selectedRowsObj = {};
        tableData.forEach((row, idx) => {
            selectedRowsObj[idx] = { selected };
        });
        this.setState({
            selectedRowsObj
        });
    }

    //未审批列表
    unCompleteList() {
        var param = {
            "condition": "",
            "paras": [],
            "fields": [],
            "begin": 0,
            "pagenum": 10
        };
        var _this = this;
        this.sendAjax("http://172.20.4.88:8088/nodebillpay/getshowplanpaydata?phone=13923456789", param, function (data) {
            _this.setState({
                unCompleteList: data
            });
        });
    }

    //已审批列表
    completeList() {
        var param = {
            "condition": "",
            "paras": [],
            "fields": [],
            "begin": 0,
            "pagenum": 10
        };
        var _this = this;
        this.sendAjax("http://172.20.4.88:8088/nodebillpay/getshowpaysucessdata?phone=13923456789", param, function (data) {
            _this.setState({
                completeList: data
            })
        });
    }

    changeTab(index) {
        this.setState({
            tabIndex: index
        });

        var d = $(".w-table-tab li");
        d.eq(0).hasClass("active") ?
            d.eq(0).removeClass("active").siblings().addClass("active") :
            d.eq(0).addClass("active").siblings().removeClass("active")

        if (index == 0) {
            this.unCompleteList();
        } else {
            this.completeList();
        }

    }

    changePayStatus() {
        var _this = this;
        let param = this.getSelectedParam(this.state.selectedRowsObj);
        this.sendAjax("http://172.20.4.88:8088/nodebillpay/dealbillpaystatussucess?phone=13923456789", param, function () {
            _this.unCompleteList();
            alert("操作成功");
        });
    }
    changeExportStatus() {
        var _this = this;
        let param = this.getSelectedParam(this.state.selectedRowsObj);
        this.sendAjax("http://172.20.4.88:8088/nodebillpay/exportbankform?phone=13923456789", param, function (data) {
            window.open("http://172.20.13.230:8090"+data+"&phone=13923456789","_blank");
            _this.unCompleteList();
        });
    }

    editPayAccount() {
        this.commonModel();

    }
    handleEdit(payAccount) {
        var _this = this;
        let rows = this.getSelectedRow(this.state.selectedRowsObj);
        let param = this.getSelectedParam(this.state.selectedRowsObj);
        param.paybankacc = payAccount;
        param.pk_paybankacc = rows[0].pk_paybankacc.pk;
        this.sendAjax("http://172.20.4.88:8088/nodebillpay/dealbillpaybankacc?phone=13923456789", param, function () {
            _this.unCompleteList();
            alert("操作成功");
        });
    }

    commonModel() {
        var content, message, _this = this;
        content = (
            <div>
                <p>请输入支付账户：</p>
                <input id="payAccount" className="form-control" placeholder="请输入支付账户"></input>
            </div>
        );
        message = {
            'showModal': true,
            'title': "支付账户",
            'message': content,
            'sureTxt': '保存',
            'cancelTxt': '取消',
            'hasSureFn': function () {
                _this.handleEdit($("#payAccount").val());
            },
            'hasCancelFn': function () {

            }
        };
        this.refs.dialog.showAlert(message)
    }


    setGrid() {
        var _this = this;
        var tabIndex = this.state.tabIndex;
        var tableData = [];
        if (tabIndex == 0) {
            tableData = this.state.unCompleteList;
        } else {
            tableData = this.state.completeList;
        }

        const mockColumnsData = [
            { type: 'string', id: 'id', label: '单据id' },
            { type: 'ref', id: 'pk_billtype', label: '单据类型' },
            { type: 'string', id: 'descript', label: '事由' },
            { type: 'double', id: 'money', label: '金额' },
            { type: 'date', id: 'expense_date', label: '报账日期' },
            { type: 'ref', id: 'billuserid', label: '报账人' },
            { type: 'ref', id: 'deptid', label: '部门' },
            { type: 'ref', id: 'pk_paybankacc', label: '银行账号' },
            { type: 'string', id: 'exportstatus', label: '导出状态' },
            { type: 'string', id: 'paystatus', label: '支付状态' }
        ];

        return (
            <Grid tableData={tableData} columnsModel={mockColumnsData} className="ssc-grid"
                selectRow={{
                    mode: 'checkbox',
                    onSelect: this.handleSelect.bind(this),
                    onSelectAll: this.handleSelectAll.bind(this)
                }}
            />
        );
    }

    render() {
        var _this = this;
        return (
            <div className="to-balance">
                <ul className="nav nav-tabs">
                    <li role="presentation" className="active" onClick={_this.changeTab.bind(this, 0)}>
                        <a href="javascript:;">待支付（5）</a>
                    </li>
                    <li role="presentation" onClick={_this.changeTab.bind(this, 1)}>
                        <a href="javascript:;">已支付（1）</a>
                    </li>
                    {
                        /*<span className="active" onClick={_this.changeExportStatus.bind(this)}><a href="javascript:;">导出支付文件</a></span>*/
                    }
                </ul>

                <div className="input-group">
                    <ul className="nav nav-pills">
                        <li className="active" onClick={_this.editPayAccount.bind(this)}>
                            <a href="javascript:;">支付账户</a>
                        </li>
                        <li onClick={_this.changePayStatus.bind(this)}><a href="javascript:;">支付成功</a></li>
                        <li onClick={_this.changeExportStatus.bind(this)}><a href="javascript:;">导出支付文件</a></li>
                    </ul>
                </div>
                <Dialog ref="dialog" />
                {_this.setGrid()}
            </div>
        );
    }
};
