import Spinner from './spinner';
import Gif from './gif';

export {
  Spinner,
  Gif,
}