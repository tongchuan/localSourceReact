/**
 * chenliw@yonyou.com
 */
import React from 'react';
import { Grid } from 'ssc-grid';
import * as expense  from  '../actions/expense';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import Config from '../config';
import {Alert} from "react-bootstrap" ;
import Spinner  from './spinner/spinner';
import  Dialog   from '../../common/components/StaticModel';

class ToBillListTest extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading :true ,
            alertVisible:false,
            errorMessage:"error" ,
            tableData:{},
            flag:0 ,  // 0未完成 1 已完成
            billCategory:"",
            firstNav:[],
            firstNavActive:0,
            isShow:true
        }
    }

    componentWillMount =() =>{
        this.props.getExpenseJSON(Config.NODE.listBillType,{},"",(json)=>{
            if(!json.data){return;}
            let billCategory = "";
            $.each(json.data , (i , obj )=>{
                if( i==0 && obj.total == 0 ){
                    this.setState({
                        isShow:false
                    })
                }

                if(obj.total >0 ){
                    billCategory = obj.type;
                    return false;
                }
            })

            if(json.code == 0 ){
                this.setState({
                    firstNav:json.data,
                    billCategory:billCategory  //初始化数据
                },()=>{
                    this.getBillData();
                })
            }

        })

        // let json = {"data":[{"total":"2","name":"报销类","type":"bx"},{"total":"0","name":"借款类","type":"jk"},{"total":"1","name":"申请类","type":"sq"},{"total":"0","name":"还款类","type":"hk"}],"information":"成功","ismapping":false,"code":"0"}


    }

    //
    getTwoNav =( type , index ,total )=>{

        this.setState({
            firstNavActive:index,
            flag:0 // 清空数据
        })

        if(total == 0){
            this.setState({
                billCategory:type,
                isShow:false
            });
            return ;
        }

        this.setState({
            billCategory:type,
            isShow:true
        } , ()=>{
            this.getBillData();
        });
    }

    setFlag = ( param )=>{
        this.setState({
            flag:param
        },()=>{
            this.getBillData();
        });
    }

    getBillData = ()=>{
        let state = this.state ;
        let param = {
            billCategory:state.billCategory ,
            start:1,
            pagesize:10,
            flag: ''+state.flag +''
        }
        this.props.getExpenseJSON(Config.NODE.LOADBILL , param , "", (data)=>{
            let isShow = true  ;
            if(!data.information||data.information.length==0 ){
                isShow = false ;
            }
            this.setState({
                isShow:isShow,
                tableData:data.information
            })
        })
    }

    setGrid = () => {
        const mockColumnsData = [
            { type: 'string', id: 'djlxmc', label: '单据类型名称' ,align: 'left'},
            { type: 'string', id: 'djlxbm', label: '单据类型编码' ,hidden:true ,align: 'left'},
            { type: 'string', id: 'icon', label: '图标',hidden:true ,align: 'left'},
            { type: 'string', id: 'pk', label: 'pk',hidden:true ,align: 'left'},
            { type: 'date', id: 'djrq', label: '单据日期',formatter: { format:"YYYY-MM-DD"} ,align: 'left'},
            { type: 'double', id: 'total', label: '金额',formatter: { format:"'$0,0.00"} },
            { type: 'string', id: 'descript', label: '事由' ,align: 'left'},
            { type: 'string', id: 'payStatus', label: '支付状态' ,align: 'left',formatter:{
                type: 'custom',
                callback:value => formatPayStatu(value)

            }},
            { type: 'string', id: 'spztshow', label: '审批状态' ,align: 'left'},
            { type: 'string', id: 'ybz_bill_status', label: '审批状态编码',hidden:true ,align: 'left'},
            { type: 'string', id: 'mark', label: '单据分类' ,align: 'left',hidden:true},
            { type: 'string', id: 'mark2', label: '单据分类' ,align: 'left',formatter:{
                type: 'custom',
                callback:value => this.billType(value)

            }},
            { type: 'string', id: 'errorMsg', label: '错误信息',hidden:true ,align: 'left'}
        ];

        var tableData = this.state.tableData;
        // var tableData =[{"djdl":"bx","spzt":"","djlxmc":"住宿","icon":null,"djrq":"2017-04-13","errorMsg":"","djlxbm":"","total":"77.0","sprshow":"","senddate":"2017-04-13 15:49:31","pk":"pJSCBJVOyz5W3dRUsGojh","time":"0小时22分","descript":"驳回","spztshow":"审批中","jkbxr":"报账人员002","ybz_bill_status":"4","payStatus":"notpay","mark":"0","tasks":[
        //     {"activitykey":null,"sprshow":"审批人员005","taskname":"审批005——加签","finished":false,"operatorCode":"17612345675","jkbxr":"报账人员002","taskid":"ee095a30-201d-11e7-9d92-0242ac110004","operator":"审批人员005","telno":"17612345675","email":"17612345675@qq.com"}]},{"djdl":"bx","spzt":"","djlxmc":"住宿","icon":null,"djrq":"2017-04-13","errorMsg":"","djlxbm":"","total":"66.0","sprshow":"","senddate":"2017-04-13 15:26:54","pk":"YASCQJoFrfvqwMXlN3I8h","time":"0小时44分","descript":"加签驳回","spztshow":"待提交","jkbxr":"报账人员002","ybz_bill_status":"0","payStatus":"notpay","mark":"0","tasks":[{"activitykey":"makeBillTask","sprshow":"报账人员002","taskname":"制单","finished":false,"operatorCode":"17612345672","jkbxr":"报账人员002","taskid":"ae4586a9-201a-11e7-ab82-0242ac110001","operator":"报账人员002","telno":"17612345672","email":"17612345672@qq.com"}]},{"djdl":"bx","spzt":"","djlxmc":"住宿","icon":null,"djrq":"2017-04-13","errorMsg":"","djlxbm":"","total":"55.0","sprshow":"","senddate":"2017-04-13 15:20:14","pk":"LtSCDUU5MvwmIs0xC7HlT","time":"0小时51分","descript":"加签test","spztshow":"审批中","jkbxr":"报账人员002","ybz_bill_status":"4","payStatus":"","mark":"0","tasks":[{"activitykey":null,"sprshow":"审批人员005","taskname":"审批005——加签","finished":false,"operatorCode":"17612345675","jkbxr":"报账人员002","taskid":"a342e254-2019-11e7-9d92-0242ac110004","operator":"审批人员005","telno":"17612345675","email":"17612345675@qq.com"}]},{"djdl":"sq","spzt":"","djlxmc":"出差申请单","icon":null,"djrq":"2017-04-12","errorMsg":"","djlxbm":"","total":"12.0","sprshow":"","senddate":"2017-04-12 21:04:40","pk":"dySC69ZZlfYwIRb0JKu6P","time":"19小时6分","descript":"全球","spztshow":"审批通过","jkbxr":"报账人员002","ybz_bill_status":"5","payStatus":"paysucess","mark":"1","tasks":[{"activitykey":null,"sprshow":"审批人员005","taskname":"审批","finished":false,"operatorCode":"17612345675","jkbxr":"报账人员002","taskid":"96e36801-1f80-11e7-a63d-0242ac110003","operator":"审批人员005","telno":"17612345675","email":"17612345675@qq.com"}]},{"djdl":"sq","spzt":"","djlxmc":"出差申请单","icon":null,"djrq":"2017-04-12","errorMsg":"","djlxbm":"","total":"11.0","sprshow":"","senddate":"2017-04-12 21:03:25","pk":"jJSC3x2WUUxyOJ0G2x7wW","time":"19小时8分","descript":"呃呃","spztshow":"审批通过","jkbxr":"报账人员002","ybz_bill_status":"5","payStatus":"notpay","mark":"1","tasks":[{"activitykey":null,"sprshow":"审批人员005","taskname":"审批","finished":false,"operatorCode":"17612345675","jkbxr":"报账人员002","taskid":"6a3543b6-1f80-11e7-a5a9-0242ac110002","operator":"审批人员005","telno":"17612345675","email":"17612345675@qq.com"}]},{"djdl":"sq","spzt":"","djlxmc":"出差申请单","icon":null,"djrq":"2017-04-12","errorMsg":"","djlxbm":"","total":"3.0","sprshow":"","senddate":"2017-04-12 20:47:25","pk":"VmSCXVwkbBpQEwq96T8SD","time":"19小时24分","descript":"去","spztshow":"审批通过","jkbxr":"报账人员002","ybz_bill_status":"5","payStatus":"notpay","mark":"1","tasks":[{"activitykey":null,"sprshow":"审批人员005","taskname":"审批","finished":false,"operatorCode":"17612345675","jkbxr":"报账人员002","taskid":"2daa5f33-1f7e-11e7-a63d-0242ac110003","operator":"审批人员005","telno":"17612345675","email":"17612345675@qq.com"}]},{"djdl":"bx","spzt":"","djlxmc":"出行","icon":null,"djrq":"2017-04-12","errorMsg":"","djlxbm":"","total":"1.0","sprshow":"","senddate":"2017-04-12 20:36:04","pk":"OISCtHTVZypwGslSNo7vV","time":"19小时35分","descript":"驳回","spztshow":"审批中","jkbxr":"报账人员002","ybz_bill_status":"4","payStatus":"notpay","mark":"0","tasks":[{"activitykey":null,"sprshow":"审批人员005","taskname":"审核005","finished":false,"operatorCode":"17612345675","jkbxr":"报账人员002","taskid":"c7b20dc5-1f7c-11e7-a5a9-0242ac110002","operator":"审批人员005","telno":"17612345675","email":"17612345675@qq.com"}]},{"djdl":"bx","spzt":"","djlxmc":"住宿","icon":null,"djrq":"2017-04-12","errorMsg":"","djlxbm":"","total":"3.0","sprshow":"","senddate":"2017-04-12 19:35:38","pk":"onSCbvkAuPZLjN6YnUCqM","time":"20小时35分","descript":"加签3","spztshow":"审批中","jkbxr":"报账人员002","ybz_bill_status":"4","payStatus":"notpay","mark":"0","tasks":[{"activitykey":null,"sprshow":"审批人员005","taskname":"审批005——加签","finished":false,"operatorCode":"17612345675","jkbxr":"报账人员002","taskid":"26668662-1f74-11e7-a5a9-0242ac110002","operator":"审批人员005","telno":"17612345675","email":"17612345675@qq.com"}]},{"djdl":"bx","spzt":"","djlxmc":"住宿","icon":null,"djrq":"2017-04-12","errorMsg":"","djlxbm":"","total":"2.0","sprshow":"","senddate":"2017-04-12 19:29:10","pk":"csSCL9bWIlbPpN9uCWo4j","time":"20小时42分","descript":"加签2","spztshow":"审批中","jkbxr":"报账人员002","ybz_bill_status":"4","payStatus":"notpay","mark":"0","tasks":[{"activitykey":null,"sprshow":"审批人员005","taskname":"审批005——加签","finished":false,"operatorCode":"17612345675","jkbxr":"报账人员002","taskid":"3f464840-1f73-11e7-a63d-0242ac110003","operator":"审批人员005","telno":"17612345675","email":"17612345675@qq.com"}]},{"djdl":"bx","spzt":"","djlxmc":"差旅报销","icon":null,"djrq":"2017-04-12","errorMsg":"","djlxbm":"","total":"32.0","sprshow":"","senddate":"2017-04-12 19:02:20","pk":"utSCbKdJnn4pEjlbAZ7NV","time":"21小时9分","descript":"32","spztshow":"待提交","jkbxr":"报账人员002","ybz_bill_status":"0","payStatus":"notpay","mark":"0","tasks":[{"activitykey":null,"sprshow":"报账人员002","taskname":"制单","finished":false,"operatorCode":"17612345672","jkbxr":"报账人员002","taskid":"a0b35f1f-1f6f-11e7-a5a9-0242ac110002","operator":"报账人员002","telno":"17612345672","email":"17612345672@qq.com"}]}]
        var flag = this.state.flag ;
        $.each(tableData , function(ind , obj ){
            for(let i=0,length =mockColumnsData.length;i<length;i++){
                let field = mockColumnsData[i].id;
                if(!obj[field])
                    obj[field] = "";
            }

        })


        function formatPayStatu( result ){
            if(flag == 0){
                result =="notpay"
            }
            if(result =="notpay"){
                result ="未支付";
            }else if(result =="paysucess" ){
                result ="已支付";
            }else{
                result ="未生成支付单";
            }
            return result ;
        }

        var _this = this ;
        var flag = this.state.flag ;
        if( tableData && tableData.length > 0 ){
            const CustomComponent = React.createClass({
                handleUpdate(event) {
                    event.preventDefault();
                    _this.printBill(this.props.rowObj);
                },
                historyEvent(event){  //查看历史
                    event.preventDefault();
                    _this.historyEventList(this.props.rowObj);
                },
                render() {
                    return (
                        <td>
                            <span onClick={this.handleUpdate}>打印</span>
                            <span onClick={this.historyEvent}>审批历史</span>
                        </td>
                    );

                    {/*
                     if(flag == 1  ){
                     return (
                     <td>
                     <span onClick={this.historyEvent}>审批历史</span>
                     </td>
                     );
                     }else{
                     return (
                     <td>
                     <span onClick={this.handleUpdate}>打印</span>
                     <span onClick={this.historyEvent}>审批历史</span>
                     <span onClick={this.billDetail}>查看</span>
                     </td>
                     );
                     }
                     */}
                }
            });
            return (
                <Grid columnsModel={mockColumnsData} tableData={tableData}
                      operationColumn={{}}  className="ssc-grid"
                      operationColumnClass={CustomComponent}
                      onRowDoubleClick ={_this.billDetail} />
            )

        }
    }

    billDetail = (e,param )=>{
        e.stopPropagation();
        if(param.djdl == "sq"){ //v2.1.3  版本不支持申请单
            var message = {
                'showModal':true,
                'title':"提示消息",
                'message':"功能开发中，敬请期待！"
            }
            this.refs.dialog.showAlert(message);
            return false;
        }
        let url = '/expenseybz/#/billdetails/' +  param.djdl+"/" +param.pk +"/2";
        // TODO  2017年9月7日 不在发布范围之内
     /*   if(param.ybz_bill_status== 0){
            url = '/expenseybz/#/billRecoveryEdit/'+param.pk+'/'+param.key;
        }*/
        var url2 = location.protocol+"//" +window.location.hostname+":"
            + window.location.port+ url ;

        window.top.document.location.hash ="#/ifr/" + encodeURIComponent(url2);
    }


    //获取流程历史列表
    historyEventList = (obj) =>{
        var _this = this ;
        var param ={
            "businessKey" : obj.pk
        };
        _this.setState({
            loading:true
        })
        this.props.getExpenseJSON(Config.BPM.WFHISBYBUSINESSKEY,param,"post",function(json){
            _this.setState({
                loading:false
            })
            if( json.code == 0 ){
                var historyList = json.data ;
                if(!historyList){return }
                const mockColumns = [
                    { type: 'string', id: 'taskname', label: '流程活动名称' ,align: 'left'},
                    { type: 'string', id: 'starttime', label: '发送时间' ,formatter: { format:"YYYY-MM-DD"} ,align: 'left'},
                    { type: 'string', id: 'procstarttime', label: '发送时间' ,hidden:true  ,align: 'left' },
                    { type: 'string', id: 'endtime', label: '完成时间' ,formatter: { format:"YYYY-MM-DD"} ,align: 'left'},
                    { type: 'string', id: 'finished', label: '完成状态'   ,align: 'left'},
                    { type: 'string', id: 'operator', label: '操作人'   ,align: 'left'},
                    { type: 'string', id: 'comments', label: '批语'   ,align: 'left'},
                    { type: 'string', id: 'activitykey', label: 'activitykey' ,hidden:true  ,align: 'left'},
                    { type: 'string', id: 'taskid', label: 'taskid' ,hidden:true  ,align: 'left'},
                ]
                $.each(historyList, function(idx , obj ){
                    if(obj.finished == true ){
                        obj.finished = "已完成";
                    }else if(obj.finished == false ){
                        obj.finished = "未完成";
                    }
                    for(let i=0,length =mockColumns.length;i<length;i++){
                        let field = mockColumns[i].id;
                        if(!obj[field])
                            obj[field] = "";
                    }
                })
                var content = (
                    <Grid className="ssc-grid" columnsModel={mockColumns} tableData={historyList} />
                )
                var message = {
                    'showModal':true,
                    'title':"流程历史",
                    'message': content
                }
                _this.refs.dialog.showAlert(message);
            }
        })
    }

    //单据打印
    printBill = ( obj ) =>{

        var _this  = this ;
        var param  ={
            'voucherPk': obj.pk ,
            'billtype':obj.djlxmc
        };
        _this.props.getExpenseJSON(Config.PRINT.GETPRINTDATA , param , "post", function( json ){
            if(json.code == 0 ) {
                var  res =  json.information ;
                var mate = "mb_"+res.typepk ;
                var infoList = res.templateInfo ;
                res.mate = "" ;
                $.each(infoList , function(ind  ,  obj ){
                    if( obj.templatecode == mate) {
                        res.mate =  obj.templatecode ;
                    }
                })

                if( res.mate =="" ){
                    var message = {
                        'showModal':true,
                        'title':"提示信息",
                        'message': "该单据没有配置打印模板"
                    }
                    _this.refs.dialog.showAlert(message);
                    return false ;
                }

                var port =document.location.protocol;  // https://
                var serverUrl = res.serverUrl ;       // http://
                if(port=="https:"){
                    serverUrl =  serverUrl.replace("http://", "https://")
                }
                window.open(Config.PRINT.GETPRINTDATAHTML
                    + "?tenantId=" + res.tenantid
                    + "&printcode=" + res.mate
                    + "&serverUrl=" + serverUrl
                    + "&params=" + res.params
                    + "&sendType=" + 2);
            }else{
                let message = {
                    'showModal':true,
                    'title':"提示信息",
                    'message': "该单据没有配置打印模板"
                }
                _this.refs.dialog.showAlert(message);
            }
        } )
    }

    //跳转到web报销标准
    goToBill = () =>{
        this.props.getExpenseJSON(Config.NODE.listbytype,{"type":this.state.billCategory},"post",(json)=>{
            if(!json.data||json.data.length <=0  ){
                return ;
            }
            let content = (
                <div className="tabs-all-bill">
                    <p className="tabs-bill-title">全部单据</p>
                    <div className="tabs-bill-content">
                        {json.data.map((value,index)=>{
                            return (<span onClick={this.toWeb.bind(this,value.pk)}>{value.billtype}</span>)
                        })}
                    </div>
                </div>
            )

            let message = {
                'showModal':true,
                'title':"请选择",
                'message': content
            }
            this.refs.dialog.showAlert(message);
        })


    }

    //uri解码
    encode_uri = (value) => {
      return encodeURI(value);
    }

    //uri编码
    decode_uri = (value) => {
      return decodeURI(value)
    }

    toWeb = (pk) => {
        let billCategory = this.state.billCategory;
        var url = '/expenseybz/#/billedit/' + pk;
        if(billCategory =="jk"){  //借款单
            url = '/expenseybz/#/loanBill/'+ billCategory + '/'+ pk
        }else if(billCategory =="hk"){ //还款单
            url = '/expenseybz/#/repaymentBill/'+ billCategory + '/'+pk
        }
        var url2 = location.protocol+"//" +window.location.hostname+":"
            + window.location.port+ url ;
        window.top.document.location.hash ="#/ifr/" + encodeURIComponent(url2);
    }


    render() {

        return (
            <div className="main-content">
                <div className="tabs-bar">
                    <div className = "nav-tabs-first">
                        <ul>
                            {this.state.firstNav.map((value ,index )=>{
                                return  (<li key={"firstNav-"+index} className={ (index == this.state.firstNavActive) ? "active":"" } onClick={this.getTwoNav.bind(this,value.type , index , value.total)}>{value.name}</li>)
                            })}
                        </ul>
                    </div>
                    <div className="">
                        <ul className="nav nav-tabs">
                            <li role="presentation" className={this.state.flag==0 ? "active":""} onClick={this.setFlag.bind(this,0)}>
                                <a href="javascript:;">未完成</a>
                            </li>
                            <li role="presentation" className={this.state.flag==1 ? "active":""} onClick={this.setFlag.bind(this,1)}>
                                <a href="javascript:;">已完成</a>
                            </li>
                        </ul>
                         <span className="fr tabs-bar-addBtn"  onClick={this.goToBill}>新增</span>
                    </div>
                    <div className={this.state.isShow?"":"hide"}>
                        {this.setGrid()}
                    </div>
                    <div className={this.state.isShow ? "hide":""}>
                        暂无数据
                    </div>
                </div>
                <Dialog ref="dialog" className="modal-grid"/>
            </div>
        );
    }
    billType = ( type ) =>{
        var name = "";
        switch ( type ){
            case "0"  :
                name ="报销单";
                break;
            case "1" :
                name ="申请单";
                break ;
            case "2" :
                name ="还款单";
                break ;
            case "3" :
                name ="申请单";
                break ;
            case "4" :
                name ="借款单";
                break ;
            default :
                break;
        }
        return name ;
    }


}

//影射Store的State到App的Props, 这里用做数据
function mapStateToProps(state) {
    return state.voucher;
}

//影射Store的dispath到App的Props,这里用做操作(事件)
function mapDispatchToProps(dispatch) {
    return bindActionCreators(expense, dispatch);
}

//练接是中间组件react-redux功能,用于把React的Props, State, Event和Redux的关联
export default connect(mapStateToProps, mapDispatchToProps)(ToBillListTest);
