/**
 * chenliw@yonyou.com
 */
import React from 'react';
import { Grid } from 'ssc-grid';
import  Dialog   from '../../common/components/StaticModel';
import * as expense  from  '../actions/expense';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import Config from '../config';
import {Alert} from "react-bootstrap" ;
import Spinner  from './spinner/spinner';

class MyWaitDealt extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading:true,
            tabIndex:0 ,
            unCompleteList:[],
            completeList:[] ,
            alertVisible:false,
            errorMessage:"错误信息",
            totalPage:1,
            activePage:0 ,
            pageSize:15,
            approvalActivityId:"",
            approvalactivityName:"",
            searchContent:""
        }
    }

    componentWillMount =() =>{
        this.unCompleteList();
    }

    //未审批列表
    unCompleteList =(  )=>{
        var _this = this;
        var param = {};
        if((/\d/g).test($.trim(this.state.searchContent))){
            param.data = {
                start:_this.state.activePage,
                pagesize:_this.state.pageSize,
                serialNo:_this.state.searchContent,
                query:""
            };
        }else{
            param.data = {
                start:_this.state.activePage,
                pagesize:_this.state.pageSize,
                serialNo:"",
                query:_this.state.searchContent
            };
        }

        _this.setState({
            loading:true,
            alertVisible:false
        })

        this.props.getExpenseJSON(Config.BPM.MYTODOSEARCH,param,"post",function(json){

            _this.setState({
                loading:false
            })
            if( json.code != 0 || !json.data){
                console.log("获取数据失败！")
                _this.setState({
                    alertVisible:true,
                    errorMessage : json.information
                })
                return false ;
            }

            var _data = [];
            $.each(json.data ,function( idx ,obj ){
                obj.billinfo.taskid = obj.taskinfo.taskid;
                obj.billinfo.procdefid = obj.taskinfo.procdefid;
                obj.billinfo.procinstanceid = obj.taskinfo.procinstanceid;
                _data.push(obj.billinfo) ;
            })
            _this.setState({
                unCompleteList:_data ,
                totalPage:Math.ceil ( json.total / _this.state.pageSize  )
            })
        })
    }

    //已审批列表
    completeList =()=>{
        var _this = this;
        var param = {};
        if((/\d/g).test($.trim(this.state.searchContent))){
            param.data = {
                start:_this.state.activePage,
                pagesize:_this.state.pageSize,
                serialNo:_this.state.searchContent,
                query:""
            };
        }else{
            param.data = {
                start:_this.state.activePage,
                pagesize:_this.state.pageSize,
                serialNo:"",
                query:_this.state.searchContent
            };
        }
        _this.setState({
            loading:true,
            alertVisible:false
        })
        this.props.getExpenseJSON(Config.BPM.MYHASDOSEARCH,param,"post",function(json){
            _this.setState({
                loading:false
            })
            if( json.code != 0 || !json.data){
                console.log("获取数据失败！");
                _this.setState({
                    alertVisible:true,
                    errorMessage : json.information
                })
                return false ;
            }
            var _data = [];
            $.each(json.data ,function( idx ,obj ){
                obj.billinfo.taskid = obj.taskinfo.taskid;
                obj.billinfo.procdefid = obj.taskinfo.procdefid;
                obj.billinfo.procinstanceid = obj.taskinfo.procinstanceid;
                _data.push(obj.billinfo) ;
            })
            _this.setState({
                completeList:_data,
                totalPage:Math.ceil ( json.total / _this.state.pageSize  )
            })
        })
    }

    /**
        审批  action: 0 批准 1 驳回 2 不批准
             taskid: 任务id (action为0、2时传入值)
    **/
    approvalEvent = ( action , obj  ) =>{
        var _this = this;
        var taskid ="", activityid ="" , activityName="",procinstanceid ="" , isrejectcommiter ="" ,
            comment = "" ,executionid ="" ,assigninfoName ="", assigninfoCode="" , assigninfoId="";
        if(action == 0 ){           // 批准
            taskid=obj.taskid;
            executionid= obj.executionid ;
            comment =$.trim( $("#passConent").val() );

            //获取加签人员
            let approval = $('.approvalSelect option:selected');
            assigninfoName = approval.val();
            assigninfoCode = approval.data("code") || approval.attr("data-code");
            assigninfoId = approval.data("id") || approval.attr("data-id");
            // activityid = _this.state.approvalActivityId ;
            activityName = _this.state.approvalactivityName ;


        }else if(action == 2){      //不批准
            taskid=obj.taskid;
            executionid =obj.executionid ;
            comment =$.trim( $("#passConent").val() );

        }else if(action == 1 ){     //  驳回
            activityid = obj.activityid;
            taskid=obj.taskid;
            procinstanceid =obj.procinstanceid ;
            isrejectcommiter =obj.isFirstActivity;
            comment = $.trim( $("#rejectContent").val() ) ;
        }

        var param = {
            data:{
                taskid:taskid,     //任务id
                action:action,     //流程动作
                comment:comment,    // 审批批语
                otherinfo:{
                    activityid:activityid,     //驳回到的活动id
                    procinstanceid:procinstanceid,   //流程实例id
                    isrejectcommiter:isrejectcommiter,  //是否驳回制单人true/false
                    endactivityflag:"processEndTask",//批准最后环节
                    assignees:[ ],                   //加签人员
                    executionid:executionid,//执行id,指派时传入
                    assigninfo:[
                        {
                            activityId:_this.state.approvalActivityId,         //活动ID
                            activityName: activityName,      //活动NAME
                            participants:[       //指派的用户
                                {
                                    id:assigninfoId, //用户id
                                    name:assigninfoName,//用户名
                                    code:assigninfoCode//用户编码
                                }
                            ]
                        }
                    ]
                },
                billinfo:obj
            }
       }
        _this.setState({
            loading:true
        })

        this.props.getExpenseJSON(Config.BPM.APPROVE,param,"post",function(param) {
            _this.setState({
                loading:false
            })
            var content="";
            if(!param){return ; }
            if(param.code == 0){
                content ="操作成功！";
            }else {
                content = param.information || "操作失败！";
                console.log(param.information);
            }
            _this.unCompleteList() ;
            var message = {
                'showModal':true,
                'title':"提示",
                "bsSize":"sm",
                'authHide':true,
                'message': content
            }
            _this.refs.dialog.showAlert(message);
        })

    }

    //审批 弹出框
    approvalModal = (obj ) =>{
        var content , message ,_this =this ;
        var param =
        {
            data:{
                taskid:obj.taskid      //任务id
            }
        }
        _this.setState({
            loading:true
        })
        this.props.getExpenseJSON(Config.BPM.ASSIGNCHECK,param,"post",function(param) {
            _this.setState({
                loading:false
            })
            if(param.code != 0 ||  !param.data ) {return false};
            // 加签时处理逻辑，影响范围审批下拉功能
            if(param.data[0]){
                _this.setState({
                    approvalActivityId:param.data[0].activityId ,
                    approvalactivityName:param.data[0].activityName
                })
            }
            obj.executionid = param.executionid ;
            let opt = "";
            if(param.data[0] && param.data[0].length != 0 ){
                opt = (
                    <select className="form-control approvalSelect">
                        {param.data[0].participants.map(function(val ,inx ){
                            return(
                                <option key={"approval-"+inx} data-code={val.code} data-id ={val.id}>{val.name}</option>
                            )
                        })}
                    </select>
                )
            }
            content = (
                <div>
                    {opt}
                    <p>请输入审批意见：</p>
                    <textarea className="form-control" rows="3" id="passConent"></textarea>
                </div>
            );
            message = {
                'showModal':true,
                'title':"审批",
                'message': content,
                'sureTxt':'批准',
                'cancelTxt':'不批准',
                'hasSureFn':function(){
                    _this.approvalEvent(0,obj);
                },
                'hasCancelFn':function(){
                    _this.approvalEvent(2,obj);
                }
            }
            _this.refs.dialog.showAlert(message);
            $("#passConent").focus();
            $(".btn-default").hide();
        })
    }

    //驳回活动列表 && 驳回弹出框
    rejectActivities = (obj) =>{
        var _this = this ;
        var param ={
            data:{
                taskid: obj.taskid
            }
        };
        _this.setState({
            loading:true
        })
        this.props.getExpenseJSON(Config.BPM.REJECTACTIVITIES,param,"post",function(json) {
            _this.setState({
                loading:false
            })
            //rejectable:true/false //是否有驳回列表
            if(json.code == 0 ){
                var opt  ="";
                if( json.data || json.data.length > 0 ){
                    opt =(
                        <select className="form-control">
                            {json.data.map(function (val, idx) {
                                return (
                                    <option key={"activity"+idx } data-id={val.activityid} data-act={val.isFirstActivity}>{val.activityname}</option>
                                )
                            })
                            }
                        </select>
                    )
                }
                var content = (
                    <div className="w-reject">
                         {opt}
                        <p>请输入驳回意见：</p>
                        <textarea className="form-control" rows="3" id="rejectContent"></textarea>
                    </div>
                );
                var message = {
                    'showModal':true,
                    'title':"驳回",
                    'message': content,
                    'sureTxt':'驳回',
                    'cancelTxt':'取消',
                    'hasSureFn':function(){
                        var opt = $(".w-reject .form-control").find("option:selected") ;
                        obj.activityid = opt.attr("data-id") ;
                        obj.isFirstActivity =opt.attr("data-act") ;
                        _this.approvalEvent( 1 , obj )
                    }
                }
                _this.refs.dialog.showAlert(message);
                $("#rejectContent").focus();
            }
        })
    }

    //获取流程历史列表
    historyEventList = (obj) =>{
        var _this = this ;
        var param ={
            data:{
                procdefid:obj.procdefid,    //流程定义id
                procinstanceid:obj.procinstanceid    // 流程实例id
            }
        };
        _this.setState({
            loading:true
        })
        this.props.getExpenseJSON(Config.BPM.WFHIS,param,"post",function(json){
            _this.setState({
                loading:false
            })
            if( json.code == 0 ){
                var historyList = json.data ;
                if(!historyList){return }
                const mockColumns = [
                    { type: 'string', id: 'taskname', label: '流程活动名称' ,align: 'left'},
                    { type: 'string', id: 'starttime', label: '发送时间' ,formatter: { format:"YYYY-MM-DD"} ,align: 'left'},
                    { type: 'string', id: 'procstarttime', label: '发送时间' ,hidden:true  ,align: 'left' },
                    { type: 'string', id: 'endtime', label: '完成时间' ,formatter: { format:"YYYY-MM-DD"} ,align: 'left'},
                    { type: 'string', id: 'finished', label: '完成状态'   ,align: 'left'},
                    { type: 'string', id: 'operator', label: '操作人'   ,align: 'left'},
                    { type: 'string', id: 'comments', label: '批语'   ,align: 'left'},
                    { type: 'string', id: 'activitykey', label: 'activitykey' ,hidden:true  ,align: 'left'},
                    { type: 'string', id: 'taskid', label: 'taskid' ,hidden:true  ,align: 'left'}
                ]
                $.each(historyList, function(idx , obj ){
                    if(obj.finished == true ){
                        obj.finished = "已完成";
                    }else if(obj.finished == false ){
                        obj.finished = "未完成";
                    }
                    for(let i=0,length =mockColumns.length;i<length;i++){
                        let field = mockColumns[i].id;
                        if(!obj[field])
                            obj[field] = "";
                    }
                })

                var content = (
                     <Grid className="ssc-grid" columnsModel={mockColumns} tableData={historyList} />
                )
                var message = {
                    'showModal':true,
                    'title':"流程历史",
                    'message': content
                }
                _this.refs.dialog.showAlert(message);
            }
        })
    }

  //单据打印
  printBill = ( obj ) =>{

    var _this  = this ;
    var param  ={
      'voucherPk': obj.billid ,
      'billtype':obj.billtypename
    };
    _this.props.getExpenseJSON(Config.PRINT.GETPRINTDATA , param , "post", function( json ){
      if(json.code == 0 ) {
        var  res =  json.information ;
        var mate = "mb_"+res.typepk ;
        var infoList = res.templateInfo ;
        res.mate = "" ;
        $.each(infoList , function(ind  ,  obj ){
          if( obj.templatecode == mate) {
            res.mate =  obj.templatecode ;
          }
        })

        if( res.mate =="" ){
          var message = {
            'showModal':true,
            'title':"提示信息",
            'message': "该单据没有配置打印模板"
          }
          _this.refs.dialog.showAlert(message);
          return false ;
        }

        var port =document.location.protocol;  // https://
        var serverUrl = res.serverUrl ;       // http://
        if(port=="https:"){
          serverUrl =  serverUrl.replace("http://", "https://")
        }
        window.open(Config.PRINT.GETPRINTDATAHTML
          + "?tenantId=" + res.tenantid
          + "&printcode=" + res.mate
          + "&serverUrl=" + serverUrl
          + "&params=" + res.params
          + "&sendType=" + 2);
      }else{
        let message = {
          'showModal':true,
          'title':"提示信息",
          'message': "该单据没有配置打印模板"
        };
        _this.refs.dialog.showAlert(message);
      }
    })
  };

    exitEventList =(param)=>{
        var _this = this ;
        this.props.getExpenseJSON(Config.BPM.WITHDRAW ,{'taskId':param.taskid},"get",(data)=>{
            let content =(<span>操作成功！</span>)
            if(data.code != 0 ){
                content =(<span>操作失败！</span>)
            }
            _this.completeList();
            var message = {
                'showModal':true,
                'title':"提示",
                "bsSize":"sm",
                'authHide':true,
                'message': content
            }
            _this.refs.dialog.showAlert(message);

        } )
    }

    changeTab =( index )=>{
        this.setState({
            tabIndex:index,
            activePage:0,
            loading:true
        },()=>{
            if(index == 0 ){
                this.unCompleteList();
            }else{
                this.completeList();
            }
        });

    }

    handlePagination =( page ) =>{
        var _this = this  ;
        var _tabIndex = this.state.tabIndex ;
        this.setState({
          activePage:page-1
       }, function(){
            if(_tabIndex == 0 ){
                 _this.unCompleteList();
            }else{
                _this.completeList();
            }
        })
    }


    //待审批传1   已审批传2   tableIndex  从0 开始的
    billDetail= (e , param) => {
        e.preventDefault();
        if(param.pbilltype == "sq"){ //v2.1.3  版本不支持申请单
            var message = {
                'showModal':true,
                'title':"提示消息",
                'message':"功能开发中，敬请期待！"
            }
            this.refs.dialog.showAlert(message);
            return false;
        }

        let tabIndex = this.tabIndex() + 1;
        //TODO  2017年9月7日 不在发布范围之内
        /* let url2 = location.protocol+"//" +window.location.hostname+":"
         + window.location.port+ '/expenseybz/#/billdetailsedit/' +
         param.pbilltype+"/" + param.billid+"/"+tabIndex ;
         */

        let url2 = '/expenseybz/#/billdetails/' ;
        let type = this.props.params.type ;  //  type:1  调到核减页面   type不存在保持不变
        if(type == 1 ){
            url2 = '/expenseybz/#/billdetailsedit/';
        }
        window.top.document.location.hash ="#/ifr/" + encodeURIComponent( location.protocol+"//" +window.location.hostname+":"
            + window.location.port + url2 + param.pbilltype+"/" + param.billid+"/"+tabIndex );
    }

    tabIndex =()=>{
        return this.state.tabIndex;
    }

    setGrid = () => {
        var tabIndex = this.state.tabIndex ;
        var tableData = [];
        var _this = this ;
        const mockColumnsData = [
            { type: 'string', id: 'billid', label: '单据id' ,hidden:true ,align: 'left' },
            { type: 'string', id: 'billtype', label: '单据类型编码' ,hidden:true ,align: 'left'},
            { type: 'string', id: 'billtypename', label: '单据类型' ,align: 'left'},
            { type: 'string', id: 'billNum', label: '单据编号' ,align: 'left'},
            { type: 'string', id: 'reason', label: '事由' ,align: 'left'},
            { type: 'date', id: 'commitdate', label: '单据日期',formatter: { format:"YYYY-MM-DD"} ,align: 'left'},
            { type: 'object', id: 'originalCurrency', label: '币种',formatter: {
                type: 'custom',
                callback: value => transformCurrency(value)
              } ,align: 'left'},
            { type: 'double', id: 'money', label: '金额',formatter: { format:"'$0,0.00"} },
            { type: 'string', id: 'commiter', label: '提交人' ,align: 'left'},
            { type: 'string', id: 'depart', label: '部门' ,align: 'left'},
            { type: 'string', id: 'pbilltype', label: '其他',hidden:true ,align: 'left'},
            { type: 'string', id: 'taskid', label: 'taskid',hidden:true ,align: 'left'}
        ];

        // 转换币种
        function transformCurrency( result ){
          return result ? result.name :'';
        }

        //未审批
        if(tabIndex==0){
            tableData = this.state.unCompleteList ;
            $.each(tableData , function(ind , obj ){
                for(let i=0,length =mockColumnsData.length;i<length;i++){
                    let field = mockColumnsData[i].id;
                    if(!obj[field])
                        obj[field] = "";
                }
            })
            let CustomComponent = React.createClass({
                passEvent(event) {    // 审批
                    event.preventDefault();
                    _this.approvalModal(this.props.rowObj);
                    _this.setState({
                        rowObj:this.props.rowObj
                    })
                },
                failEvent(event){  // 驳回
                    event.preventDefault();
                    _this.rejectActivities(this.props.rowObj)
                },
                historyEvent(event){  //查看历史
                    event.preventDefault();
                    _this.historyEventList(this.props.rowObj);
                },
                printEvent(event) {  // 打印
                    event.preventDefault();
                    _this.printBill(this.props.rowObj);
                },
                render() {
                    return (
                        <td>
                            <span onClick={this.passEvent}>审批</span>
                            <span onClick={this.failEvent}>驳回</span>
                            <span onClick={this.historyEvent}>流程历史</span>
                            <span onClick={this.printEvent}>打印</span>
                        </td>
                    );
                }
            });
            return (
                <Grid columnsModel={mockColumnsData} tableData={tableData} className="ssc-grid"
                      operationColumn={{}}
                      operationColumnClass={CustomComponent}
                      paging
                      totalPage={this.state.totalPage}
                      activePage={this.state.activePage + 1}
                      onPagination={this.handlePagination}
                      onRowDoubleClick ={this.billDetail}
                />
            );
        }else{ // 已审批
            tableData = this.state.completeList ;
            $.each(tableData , function(ind , obj ){
                for(let i=0,length =mockColumnsData.length;i<length;i++){
                    let field = mockColumnsData[i].id;
                    if(!obj[field])
                        obj[field] = "";
                }
            })
            let CustomComponent = React.createClass({
                historyEvent(event){  //查看历史
                    event.preventDefault();
                    _this.historyEventList(this.props.rowObj);
                },

                exitEvent(event){ //取消审批
                    event.preventDefault();
                    _this.exitEventList(this.props.rowObj)
                },
                printEvent(event) { // 打印
                    event.preventDefault();
                    _this.printBill(this.props.rowObj);
                },
                render() {
                    return (
                        <td>
                            {/*<span onClick={this.exitEvent}>取消审批</span>*/}
                            <span onClick={this.historyEvent}>审批历史</span>
                            <span onClick={this.printEvent}>打印</span>
                        </td>
                    );
                }
            });
            return (
                <Grid columnsModel={mockColumnsData} tableData={tableData} className="ssc-grid"
                      operationColumn={{}}
                      operationColumnClass={CustomComponent}
                      paging
                      totalPage={this.state.totalPage}
                      activePage={this.state.activePage + 1 }
                      onPagination={this.handlePagination}
                      onRowDoubleClick ={this.billDetail}
                />
            );
        }
    }
    disMiss = () =>{
        this.setState({
            alertVisible:false
        })
    }

    render() {
        var _this = this , tips = "";
        var sign = this.state.alertVisible ;
        if(sign){
            tips = (
                <Alert bsStyle="danger" onDismiss={_this.disMiss}>
                    {_this.state.errorMessage}
                </Alert>
            )
        }
        return (
            <div className="main-content">
                {tips}
                <Spinner show={this.state.loading} text="努力加载中..."></Spinner>
                <div className="tabs-bar">
                    <ul className="nav nav-tabs fl">
                        <li role="presentation" className={this.state.tabIndex==0 ? "active":""} onClick={_this.changeTab.bind(this,0)}>
                            <a href="javascript:;">待审批</a>
                        </li>
                        <li role="presentation" className={this.state.tabIndex==1 ? "active":""} onClick={_this.changeTab.bind(this,1)}>
                            <a href="javascript:;">已审批</a>
                        </li>
                    </ul>
                    <div className="input-group fl">
                        <input type="text" id="searchContent" className="form-control" onKeyDown = {_this.searchAllBlur.bind(this)} value={_this.state.searchvalue} placeholder="单据编号/提交人" />
                        <span className="input-group-btn" onClick={_this.searchAll.bind(this)}   >
                            <button className="btn btn-default" type="button">
                                <span className="glyphicon glyphicon-search"></span>
                            </button>
                        </span>
                    </div>
                </div>

                <Dialog  ref="dialog"/>
                {_this.setGrid()}
            </div>
        );
    }

    // 查询内容
    searchAll = () =>{
        var _this = this ;
        var tabIndex = this.state.tabIndex ;
        var searchContent =$.trim( $("#searchContent").val() ) ;
        this.setState({
            loading:true,
            searchContent:searchContent
        },function () {
            if(tabIndex == 1 ){   //已审批
                _this.completeList() ;
            }else{
                _this.unCompleteList()
            }

        })


    }

    //支持 回车键搜索
    searchAllBlur = ( event  ) => {
        if( event.keyCode == 13){
            this.searchAll();
        }
    }

};

//影射Store的State到App的Props, 这里用做数据
function mapStateToProps(state) {
    return state.voucher;
}

//影射Store的dispath到App的Props,这里用做操作(事件)
function mapDispatchToProps(dispatch) {
    return bindActionCreators(expense, dispatch);
}

//练接是中间组件react-redux功能,用于把React的Props, State, Event和Redux的关联
export default connect(mapStateToProps, mapDispatchToProps)(MyWaitDealt);
