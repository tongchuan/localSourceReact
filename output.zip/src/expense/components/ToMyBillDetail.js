/**
 * chenliw@yonyou.com
 */
import React from 'react';
import { Grid } from 'ssc-grid';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import * as expense from '../actions/expense';
import _  from 'lodash' ;

class ToMyBillDetail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        }
    }

    componentWillMount = ()=>{
    }

    billTable  =()=>{
        return (

            <table className="table-striped">
                <th>
                    <td>住宿</td>
                    <td>2次</td>
                    <td>金额</td>
                    <td>6000.00</td>
                </th>
                <tr>
                    <td>北京</td>
                    <td>如家莫泰酒店</td>
                    <td>300</td>
                    <td>2017年2月24日 -  2017年2月24日 </td>
                </tr>
                <tr>
                    <td>北京</td>
                    <td>如家莫泰酒店</td>
                    <td>300</td>
                    <td>2017年2月24日 -  2017年2月24日 </td>
                </tr>
            </table>
        )
    }

    render() {
        return (
            <div>
                <h1>差旅费报销单</h1>
                <div className ="row">
                    <div className="col-sm-4">
                        <div className="form-group">
                            <input type="text" className="form-control" id="" placeholder="金额"/>
                        </div>
                    </div>
                    <div className="col-sm-4">
                        <div className="form-group">
                            <input type="text" className="form-control" id="" placeholder="日期"/>
                        </div>
                    </div>
                    <div className="col-sm-4">
                        <div className="form-group">
                            <input type="text" className="form-control" id="" placeholder="事由"/>
                        </div>
                    </div>
                    <div className="col-sm-4">
                        <div className="form-group">
                            <input type="text" className="form-control" id="" placeholder="事由"/>
                        </div>
                    </div>
                </div>

                {this.billTable()}

            </div>
        );
    }
}
//影射Store的State到App的Props, 这里用做数据
function mapStateToProps(state) {
    return state.voucher;
}

//影射Store的dispath到App的Props,这里用做操作(事件)
function mapDispatchToProps(dispatch) {
    return bindActionCreators(expense, dispatch);
}

//练接是中间组件react-redux功能,用于把React的Props, State, Event和Redux的关联
export default connect(mapStateToProps, mapDispatchToProps)(ToMyBillDetail);
