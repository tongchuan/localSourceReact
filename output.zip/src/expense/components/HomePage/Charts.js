import React from 'react';
import * as expense  from  '../../actions/expense';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import echarts from "echarts";
import moment from "moment";
import Config from "../../config";
import numeral from "numeral";

class Charts extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            echarts: [
                {value:0, name:'出行',count: 0},
                {value:0, name:'住宿',count: 0},
                {value:0, name:'餐饮',count: 0},
                {value:0, name:'通讯',count: 0},
                {value:0, name:'其他',count: 0}
            ]
        }
    }

    getData=()=>{
        var _this = this;
        var myData = {};
        this.props.getExpenseJSON(Config.HOMEPAGE.CONSUMPTIONANALYSIS,{"month":moment().format("YYYYMM")},"",function(data){
            if (data.code==0) {
                _this.setState({echarts:data.data});
                myData=data.data;
            }
        },false);
        return myData;
    }

    paintingEcharts = () => {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('main'));
        let chartData = this.state.echarts;
// 绘制图表
        myChart.setOption({
            title: {
                text: '消费分析',
                textStyle: {
                    fontSize: 14,
                    fontWeight: 'normal'
                },
                top: 15,
                left: 15
            },
            type: 'pie',
            color:[ '#03c0ff','#f8347b', '#ffbb2f','#79d079','#3cf2e3','#dd49db','#0080ff','#ec5c59','#cff352'],
            // color:['#2aafef', '#f8347b', '#f19f42', '#0bacfa','#ec5c59',  '#79d079','#dd49db', '#28dccf','#ffbb2f'],
            // tooltip: {
            //     show: false
            // },
            tooltip: {
                trigger: 'item',
                // position: function (pos, params, dom, rect, size) {
                //     // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                //     var obj = {top: pos[1]};
                //     obj[['right', 'left'][+(pos[0] < size.viewSize[0] / 2)]] = 80;
                //     //   obj[['bottom', 'top'][+(pos[1] < size.viewSize[1] / 2)]] = 100;
                //     return obj;
                // },
                //饼图、仪表盘、漏斗图: {a}（系列名称），{b}（数据项名称），{c}（数值）, {d}（百分比）
                formatter: (a)=>{
                    let data = a.data;
                    let res = '<span style="font-weight: 600">'+data.name +'</span>'+ '&nbsp;&nbsp;共 ';
                    res += numeral(data.count).format('0,0')+' 笔 <br/><span style="font-size: 14px;font-weight: 600">￥ '+numeral(data.value).format('0,0.00')+'</span>';
                    return res;
                },//"{b}&nbsp;共{data.count}笔 <br/>￥{c}",
                textStyle: {
                    color: '#fff',
                    fontStyle: 'normal',
                    fontWeight: 'normal',
                    // fontFamily: 'sans-serif',
                    fontSize: 12
                }
                // backgroundColor: 'rgba(250,250,250,0)'
            },
            legend: {
                orient: 'vertical',
                left: 30,
                top: 80,
                itemWidth:3,
                itemHeight:15,
                itemGap : 3,
                // data:['出行','住宿','餐饮','通讯','销售','付款','收款','采购','其他']
                data:['出行','住宿','餐饮','通讯','其他']
            },
            series: [
                {
                    name:'0',
                    type:'pie',
                    radius: ['40%', '70%'],
                    avoidLabelOverlap: false,
                    label: {
                        normal: {
                            show: false,
                            position: 'center'
                            // formatter:function(a){
                            //     let data = a.data;
                            //     let res = data.name + ' 共 ';
                            //     res += numeral(data.count).format('0,0')+' 笔\n￥ '+numeral(data.value).format('0,0.00')+"";
                            //     return res;
                            // },
                            // textStyle: {
                            //     color: '#566172',
                            //     fontStyle: 'normal',
                            //     fontWeight: 'normal',
                            //     fontSize: 14
                            // }
                        },
                        emphasis: {
                            show: true,
                            textStyle: {
                                fontSize: 24,
                                fontWeight: 'bold'
                            }
                        }
                    },
                    // labelLine: {
                    //     normal: {
                    //         show: true,
                    //         length: 20,
                    //         length2: 15,
                    //         lineStyle: {
                    //             color: "#566172"
                    //         }
                    //     }
                    // },
                    // selectedMode: 'single',
                    minAngle: 5,
                    data:chartData
                }
            ]
        });
        // myChart.dispatchAction({
        //     type: 'showTip',
        //     seriesIndex: 0,
        //     dataIndex: 0
        // });
    }

    componentDidMount(){
        let myData=this.getData();
        // let myData={
        //     "travelMoney":799.99,		//金额	//出行
        //     "travelCount":8999.99,			//数量
        //     "eatingMoney":890.62,		//餐饮
        //     "eatingCount":0,
        //     "hotelMoney":1000,		//住宿
        //     "hotelCount":0,
        //     "payMoney":2000.88,		//付款
        //     "payCount":0,
        //     "buyMoney":1000,		//收款
        //     "buyCount":0,
        //     "gatherMoney":1000,		//采购
        //     "gatherCount":0,
        //     "communicateMoney":1000.88,	//通讯
        //     "communicateCount":0,
        //     "otherMoney":1000.00,		//其他
        //     "otherCount":0,
        //     "saleMoney":1000.00,		//其他
        //     "saleCount":0
        // }
        let chartData=[
            {value:myData.travelMoney, name:'出行',count: myData.travelCount},
            {value:myData.hotelMoney, name:'住宿',count: myData.hotelCount},
            {value:myData.eatingMoney, name:'餐饮',count: myData.eatingCount},
            {value:myData.communicateMoney, name:'通讯',count: myData.communicateCount},
            {value:myData.otherMoney, name:'其他',count: myData.otherCount}
        ];
        this.setState({echarts:chartData},()=>{
            this.paintingEcharts();
        })
        window.addEventListener("resize",this.paintingEcharts)
    }
    componentWillUnmount = () => {
        window.removeEventListener("resize",this.paintingEcharts)
    }

    render() {
        let _this = this;
        return (
            <section>
                <div id="main" className="" style={{"width":"100%","height":"280px"}}></div>
            </section>
        );
    }
}
//影射Store的State到App的Props, 这里用做数据
function mapStateToProps(state) {
    return state.voucher;
}

//影射Store的dispath到App的Props,这里用做操作(事件)
function mapDispatchToProps(dispatch) {
    return bindActionCreators(expense, dispatch);
}

//练接是中间组件react-redux功能,用于把React的Props, State, Event和Redux的关联
export default connect(mapStateToProps, mapDispatchToProps)(Charts);


