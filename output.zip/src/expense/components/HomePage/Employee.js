/**
 * Created by liuyyg on 2017/4/13.
 */
import React from 'react';
import * as expense  from  '../../actions/expense';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import Money from './Money';
import MyBill from './MyBill';
import Charts from './Charts';

class Employee extends React.Component{
    constructor (props) {
        super(props);
        this.state = {

        }
    }

    part1 = () => {
        return (
            <div className="part part1 col-md-6">
                <div className="part-head">
                    我的关注
                </div>
                <div className="part-body">
                    <Charts/>
                </div>
            </div>
        )
    }
    part2 = () => {
        return (
            <div className="part part2 col-md-6">
                <div className="part-head"></div>
                <div className="part-body">
                    <Money />
                </div>
            </div>
        )
    }

    part4 = () => {
        return (
            <div className="part col-md-12">
                <MyBill isLength = { true }/>
            </div>
        )
    }

    render (){
        var _this = this;
        return (
            <div className="employee">
                <div className="row">
                    {_this.part1()}
                    {_this.part2()}
                </div>
                <div className="row">
                    {_this.part4()}
                </div>
            </div>
        )
    }
}

export default Employee ;

