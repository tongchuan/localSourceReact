//待审批列表
import React from 'react';
import * as expense  from  '../../actions/expense';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import { Grid } from 'ssc-grid';
import Config from '../../config' ;

class MyWait extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            tableData:[],
            count:0
        }
    }
    componentWillMount(){
        this.getTableData() ;
    }

     getTableData (){
         var _this = this ;
         this.props.getExpenseJSON(Config.HOMEPAGE.MYTODOLIST,{},"",function(json){
            if(json.code != 0 ){return ;}
            _this.setState({tableData:json.data,count:json.count})
        })
    }

    setGrid(){
         const mockColumnsData =[
            {type: 'string', id: 'billtypename', label: '单据类型'},
            {type: 'string', id: 'descript',label: '描述'},
            {type: 'date', id: 'expensedate', label: '日期',formatter: { format:"YYYY-MM-DD"} },
            {type: 'double', id: 'money', label: '金额',formatter: { format: '$0,0.00' }}
        ];
        var tableData =this.state.tableData ;
        //容错处理 。 取前五条，避免越界
        if(tableData.length>5){
            tableData= tableData.splice(0,5);
        }
        if(tableData.length<=0 ){return ;}
        return (<Grid columnsModel={mockColumnsData} tableData={tableData} />)
    }
    
    encodeURL ( param ){
        var url2 = location.protocol+"//" + process.env.PROD_SERVER + '/expense/#/' + param  ;
        // var url = location.protocol+"//" + process.env.PROD_SERVER  + "/workbench/#/ifr/" + encodeURIComponent(url2) ;
        window.top.document.location.hash ="#/ifr/" + encodeURIComponent(url2);

    }

    render () {
       var _this = this ;
       return (
           <section>
               <div className="part-head">
                   待办事项
               </div>
               <div className="part-body">
                   <div className="table-top">
                       <span className="mr15">待审批</span>
                       <span>共 {_this.state.count} 条</span>
                       <span className="fr glyphicon glyphicon-option-horizontal" onClick={_this.encodeURL.bind(this,"waitDealt")} title="更多"></span>
                   </div>
                   {_this.setGrid()}
              </div>
           </section>

       );
    }
}

//影射Store的State到App的Props, 这里用做数据
function mapStateToProps(state) {
    return state.voucher;
}

//影射Store的dispath到App的Props,这里用做操作(事件)
function mapDispatchToProps(dispatch) {
    return bindActionCreators(expense, dispatch);
}

//练接是中间组件react-redux功能,用于把React的Props, State, Event和Redux的关联
export default connect(mapStateToProps, mapDispatchToProps)(MyWait);
