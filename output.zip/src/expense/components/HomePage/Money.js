import React from 'react';
import * as expense  from  '../../actions/expense';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import Config from '../../config';
import numeral from 'numeral';

class Money extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            data: {
                "myborrow": 0.00,
                "expense": 0.00,
                "toexpense": 0.00,
                "errorexpense": 0.00
            }
        }
    }

    componentDidMount(){
    }

    componentWillMount() {
        this.getFourNumber();
    }

    getFourNumber = () => {
        var jsonData = {}, _this = this;
        $.ajax({
            type: "post",
            url: Config.HOMEPAGE.FOURNUMBER,
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify(jsonData),
            success: function (json) {
                if (json.code == 0) {
                    let data = json.data;
                    _this.setState({
                        data: data
                    })
                }
            }
        })
    }

    render() {
        let _this = this;
        return (
            <div className="money">
                <div className="mb20">
                    <div className="money-head">我的借款</div>
                    <div className="money-body">{numeral(this.state.data.myborrow).format('0,0.00')}</div>
                    <div className="money-foot">当前余额</div>
                </div>
                <div className="mb20">
                    <div className="money-head">报账中</div>
                    <div className="money-body">{numeral(this.state.data.expense).format('0,0.00')}</div>
                    <div className="money-foot">已经提报</div>
                </div>
                <div className="">
                    <div className="money-head">正在发生</div>
                    <div className="money-body">{numeral(this.state.data.toexpense).format('0,0.00')}</div>
                    <div className="money-foot">未提报的消费</div>
                </div>
                <div className="">
                    <div className="money-head">异常报账</div>
                    <div className="money-body">{numeral(this.state.data.errorexpense).format('0,0.00')}</div>
                    <div className="money-foot">需要我关注的报账</div>
                </div>
            </div>
        );
    }
}

export default Money ;

