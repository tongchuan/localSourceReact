//支付列表
import React from 'react';
import * as expense  from  '../../actions/expense';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import { Grid } from 'ssc-grid';
import Config from '../../config' ;

class MyPay extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            tableData:[],
            count:0
        }
    }

    componentDidMount(){
        this.getTableData() ;
    }

    getTableData (){
         var _this = this ;
         this.props.getExpenseJSON(Config.HOMEPAGE.MYTOBEPAIDLIST,{},"",function(json){
            if(json.code != 0 ){return ;}
            _this.setState({tableData:json.data,count:json.count})
        })


    }

    setGrid (){
        var tableData =this.state.tableData ;
        if(tableData.length<=0 ){return ;}
        //容错处理 。 取前五条，避免越界
        if(tableData.length>5){
            tableData= tableData.splice(0,5);
        }
        const mockColumnsData =[
            {type: 'string', id: 'billtypename', label: '单据类型'},
            {type: 'string', id: 'descript',label: '描述'},
            {type: 'date', id: 'expensedate', label: '日期',formatter: { format:"YYYY-MM-DD"} ,},
            {type: 'double', id: 'money', label: '金额',formatter: { format: '$0,0.00' }}
        ];
        return (
            <Grid columnsModel={mockColumnsData} tableData={tableData} />
        )
    }

    encodeURL ( param ){
        var url2 = location.protocol+"//" + process.env.PROD_SERVER + '/expense/#/' + param  ;
        // var url = location.protocol+"//" + process.env.PROD_SERVER  + "/workbench/#/ifr/" + encodeURIComponent(url2) ;
        window.top.document.location.hash ="#/ifr/" + encodeURIComponent(url2);
    }

    render () {
        var _this = this ;
        return (
            <section>
                <div className="part-head">
                    待办事项
                </div>
                <div className="part-body">
                    <div className="table-top">
                        <span className="mr15">待支付</span>
                        <span>共 {_this.state.count} 条</span>
                        <span className="glyphicon glyphicon-option-horizontal fr" onClick={_this.encodeURL.bind(this,"toBalance")} title="更多"></span>
                    </div>
                    {_this.setGrid()}
                </div>
            </section>

        );
    }
}
//影射Store的State到App的Props, 这里用做数据
function mapStateToProps(state) {
    return state.voucher;
}

//影射Store的dispath到App的Props,这里用做操作(事件)
function mapDispatchToProps(dispatch) {
    return bindActionCreators(expense, dispatch);
}

//练接是中间组件react-redux功能,用于把React的Props, State, Event和Redux的关联
export default connect(mapStateToProps, mapDispatchToProps)(MyPay);



