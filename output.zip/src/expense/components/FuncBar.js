import React from 'react';


export default class FuncBar extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    render() {
        return (
            <div>
                <span>未支付</span>
                <span>未支付</span>
                {/** <div>导出支付文件</div>**/}
            </div>

        );
    }
};
