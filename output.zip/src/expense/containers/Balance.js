/**
 * author:zhangtongchuan
 * date: 2017-00-03
 * mail: zhangtch@yonyou.com
 */
import React from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import * as actionBalance from '../actions/actionBalance';
import Dialog from '../../common/components/StaticModel';
import {Grid} from 'ssc-grid';
import {Refers} from 'ssc-refer';
import {Alert, Button, Modal} from "react-bootstrap" ;
import Spinner from '../components/spinner/spinner';
import Config from '../config'

const PAYTYPE = {
  OFFLINE: 'offline',
  ONLINE: 'online'
};

class Balance extends React.Component {

  onlinePayRow;                // 在线支付所在行
  payType = '';               // 支付方式
  oper = '';                  // 操作员
  serialNumber =  '';       // 序列号
  cert = null;              // 证书
  isTCAConfig = false;      // TCA是否已经执行了TCA.config方法

  constructor(props) {
    super(props);
    this.state = {
      tabIndex: 0,
      tableData: [],
      tableColumn: [],
      selectedData: [],
      selectedRowsObj: {},
      payModalShow: false,  // 支付对话框
      payModalState: false,
      count: 0,
      countcheck: 0,
      totalPage: 1,
      activePage: 1,
      pagenum: 15,
      selectedPayAcc: [], // 从列表带回的银行账号
      paybankacc: '',//code
      pk_paybankacc: '',//id
      paybankname: '', //name
      searchvalue: '',
      vaguequeryparam: '', //模糊搜素
      errorMessage: "数据请求错误",   // 头部提示文字
      alertVisible: false,     // 头部提示状态
      loading: true,      // 加载图

      ExePath: "common/download/topCertKit.exe",
      CSP: "Longmai GM3000 for itrus CSP V1.1",
      License: "MIIFawYJKoZIhvcNAQcCoIIFXDCCBVgCAQExDjAMBggqgRzPVQGDEQUAMIGxBgkqhkiG9w0BBwGggaMEgaB7Iklzc3VlciI6IigoLipPPeWkqeWogeivmuS/oea1i+ivleezu+e7ny4qKXsxfSkiLCJ2ZXJzaW9uIjoiMS4wLjAuMSIsInNvZnRWZXJzaW9uIjoiMy4xLjAuMCIsIm5vdGFmdGVyIjoiMjAyNS0wOC0wNyIsIm5vdGJlZm9yZSI6IjIwMTUtMDgtMDciLCJub0FsZXJ0IjoidHJ1ZSJ9oIIDRDCCA0AwggLloAMCAQICFF8lnNrMgrt+8wWzAHuLjsm9+bXyMAwGCCqBHM9VAYN1BQAwVTEmMCQGA1UEAwwd5aSp6K+a5a6J5L+h5rWL6K+VU00y55So5oi3Q0ExDjAMBgNVBAsMBVRPUENBMQ4wDAYDVQQKDAVUT1BDQTELMAkGA1UEBhMCQ04wHhcNMTQwOTI2MDc0NjA4WhcNMTUwOTI2MDc0NjA4WjAxMRgwFgYDVQQDDA9TaWduRVNBMjAxNDA5MjcxFTATBgNVBAoMDOWkqeivmuWuieS/oTBZMBMGByqGSM49AgEGCCqBHM9VAYItA0IABJYWeFLmIy9mTud+ai0LBeLoxhgnO6HcQGbsQhl4fveJzoVx0Cyzt/xvWY5y7l3qAwd59AbI+Im6Ftl/wAOShYmjggGzMIIBrzAJBgNVHRMEAjAAMAsGA1UdDwQEAwIGwDCBigYIKwYBBQUHAQEEfjB8MHoGCCsGAQUFBzAChm5odHRwOi8vWW91cl9TZXJ2ZXJfTmFtZTpQb3J0L1RvcENBL3VzZXJFbnJvbGwvY2FDZXJ0P2NlcnRTZXJpYWxOdW1iZXI9NUE0N0VDRjEwNTgwNEE1QzZBNUIyMjkyOUI3NURGMERGQkMwRDc5NjBXBgNVHS4EUDBOMEygSqBIhkZQb3J0L1RvcENBL3B1YmxpYy9pdHJ1c2NybD9DQT01QTQ3RUNGMTA1ODA0QTVDNkE1QjIyOTI5Qjc1REYwREZCQzBENzk2MG8GA1UdHwRoMGYwZKBioGCGXmh0dHA6Ly9Zb3VyX1NlcnZlcl9OYW1lOlBvcnQvVG9wQ0EvcHVibGljL2l0cnVzY3JsP0NBPTVBNDdFQ0YxMDU4MDRBNUM2QTVCMjI5MjlCNzVERjBERkJDMEQ3OTYwHwYDVR0jBBgwFoAUPYnGR8txhbDZO9ZIsInZ5/7v2tkwHQYDVR0OBBYEFEs77X+HgoaHoBKSsS7mACXYtREAMAwGCCqBHM9VAYN1BQADRwAwRAIgvbTXF8yNH5jsbG6r7XL5LEupJd8l8x9akz8rhO5XYYICIOg+hxn5F44N5+waqG+1Dbs6m9xiID83VkHnmptdMoR7MYIBRTCCAUECAQEwbTBVMSYwJAYDVQQDDB3lpKnor5rlronkv6HmtYvor5VTTTLnlKjmiLdDQTEOMAwGA1UECwwFVE9QQ0ExDjAMBgNVBAoMBVRPUENBMQswCQYDVQQGEwJDTgIUXyWc2syCu37zBbMAe4uOyb35tfIwDAYIKoEcz1UBgxEFAKBpMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTE1MDgwNzE3MzAyM1owLwYJKoZIhvcNAQkEMSIEIBJeyebFtFcougN8kN5ifp/xrvvpdpJHPpvMi7oR2OSzMAwGCCqBHM9VAYItBQAERjBEAiD+AQLvSOXePUd9WHU5k8G3erod8GhQodK+GkEbvHh0vgIg4LEj7wpevBgJ88qrf/5HNTAeQP482Jb33xoGPFuj2Mw="

    };


    this.queryPayResult = this.queryPayResult.bind(this);                         // 更新支付状态
    this.closePayAccountModal = this.closePayAccountModal.bind(this);             // 关闭支付窗口
    this.checkCouldPay = this.checkCouldPay.bind(this);                           // 检查是否可以点击“付款”
    this.payModalSubmit = this.payModalSubmit.bind(this);                         // 点击付款
    this.closePayAccountModal = this.closePayAccountModal.bind(this);             // 关闭“支付对话框”
    this.changeExportStatus = this.changeExportStatus.bind(this);                 // 导出支付文件
    this.checkOper = this.checkOper.bind(this);                                   // 检查、获取操作员
    this.checkOnlinePayDrivers = this.checkOnlinePayDrivers.bind(this);           // 检查驱动是否安装
    this.checkOnlinePayCerts = this.checkOnlinePayCerts.bind(this);               // 检查证书是否正常
    this.checkHardwareSupport = this.checkHardwareSupport.bind(this);             // 统一检查驱动、证书等
    this.getOperSign = this.getOperSign.bind(this);                               // 根据流水号获取签名

  }

  componentWillMount() {
    let that = this;
    that.props.getTableColumnOld((data) => {
      that.setState({
        tableColumn: data
      });
    });
    this.getTableDataList(0);

  }

  getTestData() {
    this.setState({
      tableData: [{
        "exportuserid": {
          "name": null,
          "pk": null
        },
        "pkBanktype": {
          "name": null,
          "pk": null
        },
        "deptid": {
          "name": "总裁办",
          "pk": "07CCB953-3F4F-4C33-9879-4E70C53A2F59"
        },
        "paystatuscode": "payfail",
        "billtypecode": "jk",
        "billuserid": {
          "name": "王磊",
          "pk": "0f791baa-144f-4e53-a91c-60568564edb0"
        },
        "def10": null,
        "exporttimes": 0,
        "exportstatus": "未导出",
        "pkSourcebill": "RgSCA1zL372yF0Q2Ndq8w",
        "id": "2kSCbyRcs0uyromsJQFRG",
        "paytypename": "在线支付",
        "def3": null,
        "def4": null,
        "def1": null,
        "def2": null,
        "recaccname": " 回归卡二",
        "banktypecode": null,
        "expenseDate": "2017-12-26",
        "serialNo": null,
        "pk_recacc": {
          "name": " 回归卡二",
          "pk": "bdee7e96dd594e41a4bc840f43f7fb63"
        },
        "money": 1000001.0,
        "paybankaccname": null,
        "paystatustime": "2017-12-26",
        "recacc": "62176053080552935",
        "paystatus": "支付失败",
        "pk_paybankacc": {
          "name": "692000035",
          "pk": "27c586684c044a089ef0c47bd029c90a"
        },
        "def9": null,
        "paybankacc": "692000035",
        "paystatususerid": {
          "name": "王磊",
          "pk": "0f791baa-144f-4e53-a91c-60568564edb0"
        },
        "descript": "test-jk33",
        "def7": null,
        "paytype": "online",
        "def8": null,
        "pk_billtype": {
          "name": "借款单-供应商",
          "pk": "MaSCh6CgBXiAby2fKBhng"
        },
        "def5": null,
        "ts": 1514427422000,
        "def6": null
      },
        {
          "exportuserid": {
            "name": null,
            "pk": null
          },
          "pkBanktype": {
            "name": null,
            "pk": null
          },
          "deptid": {
            "name": "总裁办",
            "pk": "07CCB953-3F4F-4C33-9879-4E70C53A2F59"
          },
          "paystatuscode": "payfail",
          "billtypecode": "jk",
          "billuserid": {
            "name": "王磊",
            "pk": "0f791baa-144f-4e53-a91c-60568564edb0"
          },
          "def10": null,
          "exporttimes": 0,
          "exportstatus": "未导出",
          "pkSourcebill": "GhSCuRds7FlhoeWhYSrx3",
          "id": "PZSCYTO2GVttbK8X0peun",
          "paytypename": "在线支付",
          "def3": null,
          "def4": null,
          "def1": null,
          "def2": null,
          "recaccname": "包商测试2200003073",
          "banktypecode": null,
          "expenseDate": "2017-12-26",
          "serialNo": null,
          "pk_recacc": {
            "name": "包商测试2200003073",
            "pk": "1bc0e3d573d14504be18798382fc310c"
          },
          "money": 100000.0,
          "paybankaccname": null,
          "paystatustime": "2017-12-28",
          "recacc": "600045860",
          "paystatus": "支付失败",
          "pk_paybankacc": {
            "name": "692000035",
            "pk": "27c586684c044a089ef0c47bd029c90a"
          },
          "def9": null,
          "paybankacc": "692000035",
          "paystatususerid": {
            "name": "王磊",
            "pk": "0f791baa-144f-4e53-a91c-60568564edb0"
          },
          "descript": "test-jk-kh",
          "def7": null,
          "paytype": "online",
          "def8": null,
          "pk_billtype": {
            "name": "借款单-客户",
            "pk": "IKSCc5gcGbcbRqYXtOzi3"
          },
          "def5": null,
          "ts": 1514427100000,
          "def6": null
        },
        {
          "exportuserid": {
            "name": null,
            "pk": null
          },
          "pkBanktype": {
            "name": null,
            "pk": null
          },
          "deptid": {
            "name": "总裁办",
            "pk": "07CCB953-3F4F-4C33-9879-4E70C53A2F59"
          },
          "paystatuscode": "paying",
          "billtypecode": "jk",
          "billuserid": {
            "name": "王磊",
            "pk": "0f791baa-144f-4e53-a91c-60568564edb0"
          },
          "def10": null,
          "exporttimes": 0,
          "exportstatus": "未导出",
          "pkSourcebill": "GhSCuRds7FlhoeWhYSrx3",
          "id": "PZSCYTO2GVttbK8X0peun",
          "paytypename": "在线支付",
          "def3": null,
          "def4": null,
          "def1": null,
          "def2": null,
          "recaccname": "包商测试2200003073",
          "banktypecode": null,
          "expenseDate": "2017-12-26",
          "serialNo": null,
          "pk_recacc": {
            "name": "包商测试2200003073",
            "pk": "1bc0e3d573d14504be18798382fc310c"
          },
          "money": 100000.0,
          "paybankaccname": null,
          "paystatustime": "2017-12-28",
          "recacc": "600045860",
          "paystatus": "支付中",
          "pk_paybankacc": {
            "name": "692000035",
            "pk": "27c586684c044a089ef0c47bd029c90a"
          },
          "def9": null,
          "paybankacc": "692000035",
          "paystatususerid": {
            "name": "王磊",
            "pk": "0f791baa-144f-4e53-a91c-60568564edb0"
          },
          "descript": "test-jk-kh",
          "def7": null,
          "paytype": "online",
          "def8": null,
          "pk_billtype": {
            "name": "借款单-客户",
            "pk": "IKSCc5gcGbcbRqYXtOzi3"
          },
          "def5": null,
          "ts": 1514427100000,
          "def6": null
        }]
    })
  }

  componentDidMount() {
    let that = this;
    that.getTableDataList(1);
  }

  showPrompt(title, content, confirmCB, closeCB) {
    let that = this;
    let params = $.extend({}, {
      title: title,
      children: <div>
        <ul>
          <li>{content}</li>
        </ul>
      </div>,
      confirmClick: confirmCB || {}
    }, closeCB ? {closeClick: closeCB} : {});
    that.setState({
      loading: false
    }, () => {
      $.msgShow(params);
    }); // 弹出框存在时不需要loading
  }

  getTableDataList = (tabIndex, count) => {
    let that = this;
    let data = {
      "condition": "",
      "paras": [],
      "fields": [],
      vaguequeryparam: that.state.vaguequeryparam,
      "page": that.state.activePage,
      "pagenum": that.state.pagenum
    }
    that.setState({
      loading: true
    })
    this.props.getTableData(tabIndex, data, (err, data) => {
      that.setState({
        loading: false
      })
      if (err === undefined) {
        if (data.success) {
          if (!count) {
            if (tabIndex == 0) {
              let totalPage = Math.ceil(data.totalnum / that.state.pagenum);

              that.setState({
                tableData: data.data != null ? data.data : [],
                count: data != null ? data.totalnum : 0,
                totalPage: totalPage
              })
            } else {
              that.setState({
                countcheck: data != null ? data.totalnum : 0
              })
            }
          } else {
            let totalPage = Math.ceil(data.totalnum / that.state.pagenum);
            if (tabIndex == 0) {
              that.setState({
                count: data != null ? data.totalnum : 0,
                tableData: data.data != null ? data.data : [],
                totalPage: totalPage
              })
            } else {
              that.setState({
                countcheck: data != null ? data.totalnum : 0,
                tableData: data.data != null ? data.data : [],
                totalPage: totalPage
              })
            }
          }
        } else {
          that.setState({
            alertVisible: true,
            errorMessage: data.message
          })
          // $.msgShow({title:'获取数据失败',children:<div><ul><li>{data.message}</li></ul></div>,confirmClick:{}});
        }
      } else {
        that.setState({
          alertVisible: true,
          errorMessage: err.toString()
        })
        // $.msgShow({title:'获取数据失败',children:<div><ul><li>{err.toString()}</li></ul></div>,confirmClick:{}});
      }
    })
  }

  tabPageUpdate(tabIndex) {
    let that = this;
    if (that.state.tabIndex != tabIndex) {
      that.setState({
        tabIndex: tabIndex,
        activePage: 1,
        selectedData: []
      }, () => {
        that.getTableDataList(tabIndex, true);
      })
    }
  }

  //单个选中
  handleSelect(rowIdx, rowObj, selected) {
    let selectedData = [].concat(this.state.selectedData);
    let i = -1;
    selectedData.map(function(item,index){
      if(item==rowObj){
        i = index;
      }
    })
    if(selected && i==-1){
      selectedData.push(rowObj);
    }
    if(!selected && i!=-1){
      selectedData.splice(i,1);
    }
    this.setState({
      selectedData:selectedData
    })
  }

  //选中所有
  handleSelectAll(tableData, selected, $event) {
    let selectedData = [];
    if(selected){
      selectedData=[].concat(tableData);
    }
    this.setState({
      selectedData:selectedData
    });
  }

  /**
   * 更新支付状态
   * @returns {boolean}
   */
  queryPayResult() {
    let that = this;
    let selectedData = [that.onlinePayRow];
    let securityParams = null;
    switch (selectedData[0].paytype) {
      case PAYTYPE.ONLINE:  // 在线支付需要校验硬件、获取操作员，然后先获取流水号，再使用流水号获取签名
        // 检查驱动等信息
        if(!that.checkHardwareSupport()) return;

        let payAccount = selectedData[0].paybankacc;
        if(!payAccount) {
          that.showPrompt('提示信息', '未查询到支付账户，更新支付状态失败');
          return false;
        }

        that.props.getReqSeqNO({payAccount: payAccount}, data => {
          let operSign1 = that.getOperSign(data.reqseqno1),
              operSign2 = that.getOperSign(data.reqseqno2);  // 使用流水号获取签名
          if (!operSign1 || !operSign2) {
            that.showPrompt('提示信息', '获取签名失败');
            return false;
          }
          securityParams = {
            oper: that.oper,
            operSign1: operSign1,
            operSign2: operSign2,
            reqSeqNo1: data.reqseqno1,
            reqSeqNo2: data.reqseqno2
          }
        }, err => {
          that.showPrompt('提示信息', err ? err.toString() : '获取流水号失败');
          return false;
        });
        break;
      default:
        securityParams = {
          oper: '',
          operSign1: '',
          operSign2: '',
          reqSeqNo1: '',
          reqSeqNo2: ''
        };
        break;
    }

    let queryPayResultParams = $.extend({}, {
      nodeBillPayIds: selectedData.map(function (item) {
        return item.id
      }),
    }, securityParams);
    this.props.queryPayResult(queryPayResultParams, data => {
      that.payDidEnd();
    }, err => {
      that.showPrompt('更新支付状态失败', err ? err.toString() : '更新支付状态时遇到未知错误');
    });
  }

  /**
   * 打开支付窗口
   */
  showPayAccountModal(payType) {
    let that = this;
    let selectedData, stateObj;
    switch (that.payType) {
      case PAYTYPE.ONLINE:
        selectedData = that.onlinePayRow;
        let selected_paybankacc = selectedData.paybankacc,
            selected_pk_paybankacc = selectedData.pk_paybankacc;

        // 如果支付失败且存在银行账号，则将银行账号带入
        if(selectedData.paystatuscode === 'payfail' && selected_paybankacc && selected_pk_paybankacc && selected_pk_paybankacc.pk) {
          stateObj = {
            paybankacc: selected_paybankacc,
            pk_paybankacc: selected_pk_paybankacc.pk,
            selectedPayAcc: [{
              id: selected_pk_paybankacc.pk,
              account: selected_paybankacc
            }],
          }
        } else {
          stateObj = {
            paybankacc: '',
            pk_paybankacc: '',
            selectedPayAcc: []
          }
        }
        break;
      default:
        selectedData = that.state.selectedData;
        stateObj = {
          paybankacc: '',
          pk_paybankacc: '',
          selectedPayAcc: []
        };
        if (selectedData.length < 1) {
          $.msgShow({
            title: '提示信息',
            children: <div>
              <ul>
                <li>请选择单据</li>
              </ul>
            </div>,
            confirmClick: {}
          });
          return false;
        }
        break;
    }
    // console.log(that.state.selectedData.length);

    that.setState($.extend({}, {
      payModalShow: true
    }, stateObj), () => {
      that.checkCouldPay();
    });
  }

  /**
   * 检查是否能够点击确定，进行支付
   */
  checkCouldPay() {
    let that = this;
    that.setState({
      payModalState: !!that.state.paybankacc
    });
  }

  /**
   * 关闭支付窗口
   */
  closePayAccountModal() {
    this.setState({
      payModalShow: false
    });
  }

  /**
   * 支付相关操作前需要执行TCA.config，但只能执行一次，多次执行会报错
   */
  configTCA() {
    let that = this;
    if (!that.isTCAConfig) {
      let config = {
        "license": that.state.License,
        "exepath": that.state.ExePath
      };
      try {
        TCA.config(config);
        that.isTCAConfig = true;
      } catch (e) {
        if (e instanceof TCACErr) {
          console.error(e.toStr() + "tiger");
        } else {
          console.error(e + "Here is Error !!!" + "p65");
        }
        return false;
      }
    }
    return true;
  }

  /**
   * 在线支付前确认驱动是否安装
   */
  checkOnlinePayDrivers() {
    let that = this;
    //获取服务器配置默认csp
    let flag = false;
    let serverCsp = that.state.CSP;
    try {
      let certstores = CertStore.listStore(); //获取系统安装csp
      let size = certstores.length;
      for (let i = 0; i < size; i++) {
        if (certstores[i] === serverCsp) {
          flag = true;
        }
      }
    } catch (e) {
      if (e instanceof TCACErr) {
        console.error(e.toStr());
      } else {
        console.error("Get CertStore is Error !!!");
      }
      flag = false;
    }
    return flag;
  };

  /**
   * 在线支付前确认是否有证书
   */
  checkOnlinePayCerts() {
    let that = this;

    let flag = false;
    let config = {
      "license": that.state.License,
      "exepath": that.state.ExePath
    };
    try {
      let certs = CertStore.byName(that.state.CSP).listCerts();
      if(certs.size() > 0) {
        flag = true;
        that.cert = certs.get(0);
        that.serialNumber = that.cert.serialNumber();
      } else {
        flag = false;
      }
    } catch (err) {
      if (err instanceof TCACErr) {
        console.error(err.toStr() + "tiger");
      } else {
        console.error(err + "Here is Error !!!" + "p65");
      }
      flag = false;
    }
    return flag;
  };

  /**
   * 根据证书检验操作员
   * @returns {*}
   */
  checkOper() {
    let that = this;

    let flag = false;
    try {
      let arr = that.cert.subject().match(/(S(?!N)|L|O(?!U)|OU|SN|CN|E)=([^=]+)(?=, |$)/g);
      for (let item of arr) {
        if (item.indexOf('CN=') === 0) {
          flag = true;
          that.oper = item.substr(3, item.length);
          break;
        }
      }
    } catch(e) {
      console.error(e.toString());
    }
    return flag;
  };

  /**
   * 根据“流水号”获取签名
   * @param reqSeqNo 流水号
   * @returns {string}
   */
  getOperSign(reqSeqNo) {
    let that = this;

    let plainCode = reqSeqNo + that.oper,
        operSign,
        serialNumber,
        certs,
        results,
        cert;
    try {
      serialNumber = that.serialNumber;
      certs = CertStore.listAllCerts(); // 此处可能会有性能问题
      results = certs.bySerialnumber(serialNumber);
      cert = results.get(0);
      operSign = cert.signMessage(plainCode, false);
    } catch(e) {
      console.error(e.toString());
    }
    return operSign;
  }

  /**
   * 在线支付检验驱动是否安装、获取操作员是否正常
   */
  checkHardwareSupport() {
    let that = this;
    if(!that.configTCA()) {
      alert('初始化支付环境失败，请确认安装驱动并插入uKey');
      return false;
    }
    if(!that.checkOnlinePayCerts()) {
      alert('获取证书失败，uKey未插入或者uKey中无证书');
      return false;
    }
    if (!that.checkOnlinePayDrivers()) {
      alert('获取驱动失败，请安装驱动后刷新页面再进行支付，此时不能进行在线支付！');
      return false;
    }
    if(!that.checkOper()) {
      alert('获取操作员失败');
      return false;
    }
    return true;
  }

  /**
   * 预付款，需要先获取单据流水号，再调用真正的onlinePay方法
   */
  payModalSubmit() {
    let that = this;

    that.setState({
      payModalShow: false,
      loading: true
    });

    let handlingData = null, securityParams = null;

    switch (that.payType) {
      case PAYTYPE.ONLINE:  // 在线支付需要校验硬件、获取操作员，然后先获取流水号，再使用流水号获取签名
        handlingData = [that.onlinePayRow];
        // 检查驱动等信息
        if(!that.checkHardwareSupport()) {
          that.setState({
            loading: false
          });
          return;
        }

        that.props.getReqSeqNO({payAccount: that.state.paybankacc}, data => {
          let operSign = that.getOperSign(data.reqseqno1);  // 使用流水号获取签名
          if (!operSign) {
            that.showPrompt('支付信息', '获取签名失败');
            that.setState({
              loading: false
            });
            return false;
          }
          securityParams = {
            oper: this.oper,
            operSign: operSign,
            reqSeqNo: data.reqseqno1
          }
        }, err => {
          that.showPrompt('支付信息', '获取流水号失败');
          that.setState({
            loading: false
          });
          return false;
        });
        break;
      case PAYTYPE.OFFLINE:
        handlingData = that.state.selectedData;
        securityParams = {
          oper: '',
          operSign: '',
          reqSeqNo: ''
        };
        break;
      default:
        break;
    }

    let nodeBillPayIds = handlingData.map(item => item.id);

    let onlinePayParams = $.extend({}, {
      nodeBillPayIds: nodeBillPayIds,
      payType: that.payType,
      payAccountId: that.state.pk_paybankacc, // 支付账号主键
      payAccount: that.state.paybankacc,
    }, securityParams);

    that.props.onlinePay(onlinePayParams, data => {
      that.payType === PAYTYPE.ONLINE ? that.showPrompt('支付提示', data.information || '预支付成功', () => that.porderConfirm(data, nodeBillPayIds), () => that.porderCancel(data, nodeBillPayIds)) : that.showPrompt('支付提示', data.information || '支付成功', () => that.payDidEnd());
    }, err => {
      that.showPrompt('支付提示', err ? err.toString() : '支付失败', () => that.payDidEnd());
    });
  }

  /**
   * 预下单成功，确认支付时的“取消”事件
   * @param porderResults 预下单成功后返回的数据
   */
  porderCancel(porderResults, nodeBillPayIds) {
    let that = this;
    that.props.porderCancel({
      nodeBillPayIds: nodeBillPayIds
    }, data => {
      that.payDidEnd();
    }, err => {
      that.showPrompt('支付信息', err ? err.toString() : '取消支付失败', () => that.payDidEnd());
      console.error('取消支付失败===>' + err.toString());
    });
  }

  /**
   * 预下单成功，确认支付时的“确认”事件
   * @param porderResults 预下单成功后返回的数据
   */
  porderConfirm(porderResults, nodeBillPayIds) {
    let that = this;
    that.setState({
      loading: true
    });
    let {porderid, porderStatus} = porderResults;
    that.props.getReqSeqNO({payAccount: that.state.paybankacc}, data => {
      let reqSeqNo = data.reqseqno1;
      let operSign = that.getOperSign(reqSeqNo);  // 使用流水号获取签名
      if (!operSign) {
        that.showPrompt('支付提示', '获取签名失败');
        return false;
      }

      that.props.porderConfirm({
        nodeBillPayIds: nodeBillPayIds,
        porderid: porderid,
        porderStatus: porderStatus,
        oper: that.oper,
        operSign: operSign,
        reqSeqNo: reqSeqNo
      }, data => {
        that.showPrompt('支付提示', data.information || '支付成功', () => that.payDidEnd());
      }, err => {
        that.showPrompt('支付提示', err.toString(), () => that.payDidEnd());
      });
    }, err => {
      that.showPrompt('支付提示', err.toString());
    });
  }

  /**
   * 支付结束后的收尾工作
   */
  payDidEnd() {
    let that = this;
    that.setState({
      selectedData: [],
      payModalShow: false,
      loading: false
    });
    that.getTableDataList(that.state.tabIndex, true);
  }

  //导出支付文件
  changeExportStatus() {
    let that = this;
    if (that.state.selectedData.length < 1) {
      $.msgShow({
        title: '提示信息',
        children: <div>
          <ul>
            <li>请选择单据</li>
          </ul>
        </div>,
        confirmClick: {}
      });
      return false;
    }
    let data = {
      nodebillpayids: that.state.selectedData.map(function (item) {
        return item.id
      }),
    }
    that.setState({
      loading: true
    })
    this.props.sendExport(data, (err, data) => {
      that.setState({
        loading: false
      })
      if (err === undefined) {
        if (data.success) {
          that.getTableDataList(that.state.tabIndex, true);
          that.setState({
            selectedData: []
          })
          window.open(data.dowbankfilenurl + "&phone=13923456789", "_blank");
        } else {
          $.msgShow({
            title: '导出支付文件失败',
            children: <div>
              <ul>
                <li>{data.message}</li>
              </ul>
            </div>,
            confirmClick: {}
          });
        }
      } else {
        $.msgShow({
          title: '导出支付文件失败',
          children: <div>
            <ul>
              <li>{err.toString()}</li>
            </ul>
          </div>,
          confirmClick: {}
        });
      }
    })
  }

  handlePagination = (nextPage) => {
    let that = this;
    this.setState({
      activePage: nextPage
    }, () => {
      that.getTableDataList(that.state.tabIndex, true);
    })

  }
  changeinput = () => {
    var val = this.refs.searchvalue.value
    this.setState({
      searchvalue: val
    })
  }

  searchClick = (event) => {
    event.preventDefault();
    let that = this;
    var val = this.refs.searchvalue.value
    this.setState({
      vaguequeryparam: val
    }, () => {
      that.getTableDataList(that.state.tabIndex, true);
    })


  }


  _handleChange = (selected) => {
    if (selected != null && selected.length > 0) {
      let paybankacc = selected[0].account;
      let pk_paybankacc = selected[0].id;
      this.setState({
        paybankacc: paybankacc,
        pk_paybankacc: pk_paybankacc,
      }, () => {
        this.checkCouldPay();
      });
    } else {
      this.setState({
        paybankacc: '',
        pk_paybankacc: '',
      })
    }
  }

  _handleBlur = (e) => {
    console.log(arguments);
    // console.log(JSON.stringify(e));
  }

  disMiss = () => {
    this.setState({
      alertVisible: false
    })
  }

  billDetail = (e, param) => {
    e.stopPropagation();
    var url2 = location.protocol + "//" + window.location.hostname + ":"
      + window.location.port + '/expenseybz/#/billdetails/' +
      param.billtypecode + "/" + param.pkSourcebill + "/0";

    window.top.document.location.hash = "#/ifr/" + encodeURIComponent(url2);
  }


  //初始化证书列表
  initCertList = () => {
    let that = this;
    console.debug("initcertList");
    try {

      var certs = CertStore.byName(that.state.CSP).listCerts();
      if (certs.size() > 0) {
        for (var i = 0; i < certs.size(); i++) {
          var cert = certs.get(i);
          var sn = cert.serialNumber();
          var cn = that.getCNFromSubject(cert);

          that.addOption(cert.serialNumber(), cn);
        }
      } else {
        $("#CertList").append("<option value='0'>查询结果为空");
      }
    } catch (e) {
      if (e instanceof TCACErr) {
        console.error(e.toStr());
      } else {
        console.error("Here is Error !!!" + "p89");
      }
    }

  };

  // 从Certificate对象中获取CN
  // cert : Certificate对象
  getCNFromSubject = (cert) => {
    try {
      var t = cert.subject().match(/(S(?!N)|L|O(?!U)|OU|SN|CN|E)=([^=]+)(?=, |$)/g);
      for (var i = 0; i < t.length; i++) {
        if (t[i].indexOf("CN=") === 0)
          return t[i].substr(3, t[i].length);
      }
      return null;
    } catch (e) {
      if (e instanceof TCACErr) {
        console.error(e.toStr());
      } else {
        console.error("Here is Error !!!" + "p109");
      }
    }

  };

  addOption = (oValue, oName) => {
    var sid = document.getElementById("CertList");
    var myOption = document.createElement("option");
    sid.appendChild(myOption);
    myOption.text = oName;
    myOption.value = oValue;

  };

  // 返回Certificate对象
  getSelectedCert = () => {
    try {
      var certs = CertStore.listAllCerts(); // 此处可能会有性能问题
      var selectedCertSN = $("[id=CertList]").attr("value");
      var r = certs.bySerialnumber(selectedCertSN);
      return r.get(0);
    } catch (e) {
      if (e instanceof TCACErr) {
        alert(e.toStr() + "p108");
      } else {
        alert("没有找到证书");
      }
    }

  };

  //动态更换用户名
  selectCert = () => {
    let that = this;
    var cert = that.getSelectedCert();
    var cn = that.getCNFromSubject(cert);
    console.debug('oper=>' + cn);
    document.getElementById("UserName").value = cn;
    that.setState({
      oper: cn
    });
  };

  //签名方法
  checkForm = (e) => {
    e.preventDefault();
    // alert("checkform")
    let that = this;
    try {
      var toSign = $("#ToSign").val();
      var cert = that.getSelectedCert();
      alert('openSign=>' + cert.signMessage(toSign, false))
      document.getElementById("SignedData").value = cert.signMessage(toSign, false);
    } catch (e) {
      if (e instanceof TCACErr) {
        alert(e.toStr() + "p130");
      } else {
        alert("Here is Error !!!" + "p158");
      }
    }
  }


  render() {
    var _this = this, tips = "";
    var sign = this.state.alertVisible;
    if (sign) {
      tips = (
        <Alert bsStyle="danger" onDismiss={_this.disMiss}>
          {_this.state.errorMessage}
        </Alert>
      )
    }

    let selectedData = _this.state.selectedData;

    let payBtnDisabled = selectedData.every((item) => {
      return ['notpay', 'payfail'].indexOf(item.paystatuscode) > -1;
    });

    let payAccountReferState = {
      disabled: false,
      dropup: false,
      minLength: 0,
      align: 'justify',
    };

    let CustomComponent;

    if(_this.state.tabIndex == 0) {
      CustomComponent = React.createClass({
        handleOnlinePay(event) {    // 在线支付
          event.preventDefault();
          _this.onlinePayRow = this.props.rowObj;
          _this.payType = PAYTYPE.ONLINE;
          _this.showPayAccountModal();
        },
        handleUpdatePayStatus(event){  // 更新支付状态
          event.preventDefault();
          _this.onlinePayRow = this.props.rowObj;
          _this.payType = PAYTYPE.ONLINE;
          _this.queryPayResult();
        },
        render() {
          let actionButton;
          switch(this.props.rowObj.paystatuscode) {
            case 'payfail':
            case 'notpay':
              // 更新失败/未支付时，显示“在线支付”
              actionButton = (
                <span onClick={this.handleOnlinePay}>在线支付</span>
              );
              break;
            case 'paying':
              // 支付中时，显示“更新支付状态”
              actionButton = (
                <span onClick={this.handleUpdatePayStatus}>更新支付状态</span>
              );
              break;
          }
          return (
            <td>{actionButton}</td>
          );
        }
      });
    }

    //var dtata ={"data":[{"exportuserid":{"name":null,"pk":null},"pkBanktype":{"name":null,"pk":null},"deptid":{"name":"财务部1","pk":"1EAF75F6-2C43-4E1F-9221-DE24D8926895"},"localCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"paystatuscode":"paysucess","billtypecode":"bx","billuserid":{"name":"王五","pk":"2fdb5469-3392-490f-ab69-e0f952bb3c5d"},"def10":null,"exporttimes":0,"exportstatus":"未导出","pkSourcebill":"qYSCC7GTctDBKc8yZchet","id":"HfSCCisljOkuCJp8tDLxU","paytypename":"线下支付","originalCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000003","code":"GBP","name":"英镑"},"localMoney":4898.985,"def3":null,"def4":null,"def1":null,"def2":null,"recaccname":null,"banktypecode":null,"expenseDate":"2018-03-15","serialNo":"test010326012018030122","pk_recacc":{"name":null,"pk":null},"money":546,"paybankaccname":"01","paystatustime":"2018-03-15","recacc":null,"paystatus":"支付成功","pk_paybankacc":{"name":"01","pk":"BF40A2EE-C5AB-4ABE-891F-DB8E01F3D37B"},"def9":null,"paybankacc":"01","paystatususerid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"descript":"测试","def7":null,"paytype":"offline","def8":null,"pk_billtype":{"name":"出差","pk":"4BSCdF3beVrZVwnsWcpzN"},"def5":null,"ts":1521118437000,"def6":null},{"exportuserid":{"name":null,"pk":null},"pkBanktype":{"name":null,"pk":null},"deptid":{"name":"财务部1","pk":"1EAF75F6-2C43-4E1F-9221-DE24D8926895"},"localCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"paystatuscode":"paysucess","billtypecode":"bx","billuserid":{"name":"王五","pk":"2fdb5469-3392-490f-ab69-e0f952bb3c5d"},"def10":null,"exporttimes":0,"exportstatus":"未导出","pkSourcebill":"jxSCnk4RkcfC5VQI0icwf","id":"DHSCL09GxCegiiNFUkGNg","paytypename":"线下支付","originalCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000003","code":"GBP","name":"英镑"},"localMoney":3283.935,"def3":null,"def4":null,"def1":null,"def2":null,"recaccname":null,"banktypecode":null,"expenseDate":"2018-03-15","serialNo":"test010326012018030121","pk_recacc":{"name":null,"pk":null},"money":366,"paybankaccname":"01","paystatustime":"2018-03-15","recacc":null,"paystatus":"支付成功","pk_paybankacc":{"name":"01","pk":"BF40A2EE-C5AB-4ABE-891F-DB8E01F3D37B"},"def9":null,"paybankacc":"01","paystatususerid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"descript":"b","def7":null,"paytype":"offline","def8":null,"pk_billtype":{"name":"出差","pk":"4BSCdF3beVrZVwnsWcpzN"},"def5":null,"ts":1521118088000,"def6":null},{"exportuserid":{"name":null,"pk":null},"pkBanktype":{"name":null,"pk":null},"deptid":{"name":"财务部1","pk":"1EAF75F6-2C43-4E1F-9221-DE24D8926895"},"localCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"paystatuscode":"paysucess","billtypecode":"bx","billuserid":{"name":"王五","pk":"2fdb5469-3392-490f-ab69-e0f952bb3c5d"},"def10":null,"exporttimes":0,"exportstatus":"未导出","pkSourcebill":"CSSChydj9mUQbHFQFCZ55","id":"JPSC8MEBYYQQDQSLyiNnQ","paytypename":"线下支付","originalCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000003","code":"GBP","name":"英镑"},"localMoney":7967.58,"def3":null,"def4":null,"def1":null,"def2":null,"recaccname":null,"banktypecode":null,"expenseDate":"2018-03-15","serialNo":"test010326012018030120","pk_recacc":{"name":null,"pk":null},"money":888,"paybankaccname":"01","paystatustime":"2018-03-15","recacc":null,"paystatus":"支付成功","pk_paybankacc":{"name":"01","pk":"BF40A2EE-C5AB-4ABE-891F-DB8E01F3D37B"},"def9":null,"paybankacc":"01","paystatususerid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"descript":"与","def7":null,"paytype":"offline","def8":null,"pk_billtype":{"name":"出差","pk":"4BSCdF3beVrZVwnsWcpzN"},"def5":null,"ts":1521116909000,"def6":null},{"exportuserid":{"name":null,"pk":null},"pkBanktype":{"name":null,"pk":null},"deptid":{"name":"财务部1","pk":"1EAF75F6-2C43-4E1F-9221-DE24D8926895"},"localCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"paystatuscode":"paysucess","billtypecode":"bx","billuserid":{"name":"王五","pk":"2fdb5469-3392-490f-ab69-e0f952bb3c5d"},"def10":null,"exporttimes":0,"exportstatus":"未导出","pkSourcebill":"tMSC2Si7rzW4et3Co7Bye","id":"0RSCtF5PBjHfjbD0vCQgT","paytypename":"线下支付","originalCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000002","code":"EUR","name":"欧元"},"localMoney":630.648,"def3":null,"def4":null,"def1":null,"def2":null,"recaccname":null,"banktypecode":null,"expenseDate":"2018-03-15","serialNo":"test010326012018030119","pk_recacc":{"name":null,"pk":null},"money":8E+1,"paybankaccname":"01","paystatustime":"2018-03-15","recacc":null,"paystatus":"支付成功","pk_paybankacc":{"name":"01","pk":"BF40A2EE-C5AB-4ABE-891F-DB8E01F3D37B"},"def9":null,"paybankacc":"01","paystatususerid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"descript":"与","def7":null,"paytype":"offline","def8":null,"pk_billtype":{"name":"出差","pk":"4BSCdF3beVrZVwnsWcpzN"},"def5":null,"ts":1521116135000,"def6":null},{"exportuserid":{"name":null,"pk":null},"pkBanktype":{"name":null,"pk":null},"deptid":{"name":"财务部1","pk":"1EAF75F6-2C43-4E1F-9221-DE24D8926895"},"localCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"paystatuscode":"paysucess","billtypecode":"bx","billuserid":{"name":"王五","pk":"2fdb5469-3392-490f-ab69-e0f952bb3c5d"},"def10":null,"exporttimes":0,"exportstatus":"未导出","pkSourcebill":"kdSCAepEwf5BNHuNY2UNT","id":"YbSCQj1iU8BGkttZtneLF","paytypename":"线下支付","originalCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000002","code":"EUR","name":"欧元"},"localMoney":1939.2426,"def3":null,"def4":null,"def1":null,"def2":null,"recaccname":null,"banktypecode":null,"expenseDate":"2018-03-15","serialNo":"test010326012018030116","pk_recacc":{"name":null,"pk":null},"money":246,"paybankaccname":"01","paystatustime":"2018-03-15","recacc":null,"paystatus":"支付成功","pk_paybankacc":{"name":"01","pk":"BF40A2EE-C5AB-4ABE-891F-DB8E01F3D37B"},"def9":null,"paybankacc":"01","paystatususerid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"descript":"测试","def7":null,"paytype":"offline","def8":null,"pk_billtype":{"name":"出差","pk":"4BSCdF3beVrZVwnsWcpzN"},"def5":null,"ts":1521115840000,"def6":null},{"exportuserid":{"name":null,"pk":null},"pkBanktype":{"name":null,"pk":null},"deptid":{"name":"财务部1","pk":"1EAF75F6-2C43-4E1F-9221-DE24D8926895"},"localCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"paystatuscode":"paysucess","billtypecode":"bx","billuserid":{"name":"王五","pk":"2fdb5469-3392-490f-ab69-e0f952bb3c5d"},"def10":null,"exporttimes":0,"exportstatus":"未导出","pkSourcebill":"wQSCnyey5p7OWow4V8WzP","id":"b1SCM7W1pXn9zgFGityr2","paytypename":"线下支付","originalCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000002","code":"EUR","name":"欧元"},"localMoney":6148.818,"def3":null,"def4":null,"def1":null,"def2":null,"recaccname":null,"banktypecode":null,"expenseDate":"2018-03-15","serialNo":"test010326012018030118","pk_recacc":{"name":null,"pk":null},"money":7.8E+2,"paybankaccname":"01","paystatustime":"2018-03-15","recacc":null,"paystatus":"支付成功","pk_paybankacc":{"name":"01","pk":"BF40A2EE-C5AB-4ABE-891F-DB8E01F3D37B"},"def9":null,"paybankacc":"01","paystatususerid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"descript":"测试","def7":null,"paytype":"offline","def8":null,"pk_billtype":{"name":"出差","pk":"4BSCdF3beVrZVwnsWcpzN"},"def5":null,"ts":1521115778000,"def6":null},{"exportuserid":{"name":null,"pk":null},"pkBanktype":{"name":null,"pk":null},"deptid":{"name":"财务部1","pk":"1EAF75F6-2C43-4E1F-9221-DE24D8926895"},"localCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"paystatuscode":"paysucess","billtypecode":"bx","billuserid":{"name":"王五","pk":"2fdb5469-3392-490f-ab69-e0f952bb3c5d"},"def10":null,"exporttimes":0,"exportstatus":"未导出","pkSourcebill":"sKSC7pimpecyllz2LuMSI","id":"bZSCQDUfI17oB3pzEiF0d","paytypename":"线下支付","originalCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000002","code":"EUR","name":"欧元"},"localMoney":472.986,"def3":null,"def4":null,"def1":null,"def2":null,"recaccname":null,"banktypecode":null,"expenseDate":"2018-03-15","serialNo":"test010326012018030073","pk_recacc":{"name":null,"pk":null},"money":6E+1,"paybankaccname":"01","paystatustime":"2018-03-15","recacc":null,"paystatus":"支付成功","pk_paybankacc":{"name":"01","pk":"BF40A2EE-C5AB-4ABE-891F-DB8E01F3D37B"},"def9":null,"paybankacc":"01","paystatususerid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"descript":"测试","def7":null,"paytype":"offline","def8":null,"pk_billtype":{"name":"出差","pk":"4BSCdF3beVrZVwnsWcpzN"},"def5":null,"ts":1521115692000,"def6":null},{"exportuserid":{"name":null,"pk":null},"pkBanktype":{"name":null,"pk":null},"deptid":{"name":"财务部门","pk":"BD40313A-3513-48AA-B41C-D283BECC296A"},"localCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"paystatuscode":"paysucess","billtypecode":"jk","billuserid":{"name":"张林","pk":"77756ae9-9cda-481c-8a60-6451dbaf307c"},"def10":null,"exporttimes":0,"exportstatus":"未导出","pkSourcebill":"HQSC57UXfcv8Prx3uUD95","id":"XhSCy4DHlpMV0iu25RrAj","paytypename":"线下支付","originalCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000002","code":"EUR","name":"欧元"},"localMoney":7.8831,"def3":null,"def4":null,"def1":null,"def2":null,"recaccname":null,"banktypecode":null,"expenseDate":"2018-03-15","serialNo":"test010324012018030013","pk_recacc":{"name":null,"pk":null},"money":1,"paybankaccname":"01","paystatustime":"2018-03-15","recacc":null,"paystatus":"支付成功","pk_paybankacc":{"name":"01","pk":"BF40A2EE-C5AB-4ABE-891F-DB8E01F3D37B"},"def9":null,"paybankacc":"01","paystatususerid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"descript":"的","def7":null,"paytype":"offline","def8":null,"pk_billtype":{"name":"借款单-姜","pk":"73SCKgTo58kURMmWe2I0d"},"def5":null,"ts":1521100711000,"def6":null},{"exportuserid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"pkBanktype":{"name":null,"pk":null},"deptid":{"name":"财务部","pk":"D1961E20-2FF1-4DA6-95C6-E176538351D9"},"localCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"paystatuscode":"paysucess","billtypecode":"bx","billuserid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"def10":null,"exporttimes":1,"exportstatus":"已导出","pkSourcebill":"a0SCCH0u7YA0ZOji8PdBR","id":"uUSCDawfIqYaiv1uZ2VSb","paytypename":"线下支付","originalCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000004","code":"HKD","name":"港元"},"localMoney":0.637416,"def3":null,"def4":null,"def1":null,"def2":null,"recaccname":null,"banktypecode":null,"expenseDate":"2018-03-10","serialNo":"test010326012018030070","pk_recacc":{"name":null,"pk":null},"money":0.78,"paybankaccname":"01","paystatustime":"2018-03-10","recacc":null,"paystatus":"支付成功","pk_paybankacc":{"name":"01","pk":"BF40A2EE-C5AB-4ABE-891F-DB8E01F3D37B"},"def9":null,"paybankacc":"01","paystatususerid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"descript":"测试冲借款","def7":null,"paytype":"offline","def8":null,"pk_billtype":{"name":"报销-姜","pk":"RoSCvJKd7D1BZmkrXl0Z8"},"def5":null,"ts":1520925957000,"def6":null},{"exportuserid":{"name":null,"pk":null},"pkBanktype":{"name":null,"pk":null},"deptid":{"name":"财务部","pk":"D1961E20-2FF1-4DA6-95C6-E176538351D9"},"localCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"paystatuscode":"paysucess","billtypecode":"jk","billuserid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"def10":null,"exporttimes":0,"exportstatus":"未导出","pkSourcebill":"9cSCnX5IZkaBjpwhW8PzX","id":"liSCux6BthcFDnX5GAi5F","paytypename":"线下支付","originalCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000004","code":"HKD","name":"港元"},"localMoney":16.344,"def3":null,"def4":null,"def1":null,"def2":null,"recaccname":null,"banktypecode":null,"expenseDate":"2018-03-10","serialNo":"test010324012018030011","pk_recacc":{"name":null,"pk":null},"money":2E+1,"paybankaccname":"01","paystatustime":"2018-03-10","recacc":null,"paystatus":"支付成功","pk_paybankacc":{"name":"01","pk":"BF40A2EE-C5AB-4ABE-891F-DB8E01F3D37B"},"def9":null,"paybankacc":"01","paystatususerid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"descript":"吧","def7":null,"paytype":"offline","def8":null,"pk_billtype":{"name":"借款单-姜","pk":"73SCKgTo58kURMmWe2I0d"},"def5":null,"ts":1520652090000,"def6":null},{"exportuserid":{"name":null,"pk":null},"pkBanktype":{"name":null,"pk":null},"deptid":{"name":"财务部","pk":"D1961E20-2FF1-4DA6-95C6-E176538351D9"},"localCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"paystatuscode":"paysucess","billtypecode":"bx","billuserid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"def10":null,"exporttimes":0,"exportstatus":"未导出","pkSourcebill":"UiSCmmaSbdiVxgCyyYPv6","id":"CBSCINydTIy0v8PcRnYMQ","paytypename":"线下支付","originalCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"localMoney":21493,"def3":null,"def4":null,"def1":null,"def2":null,"recaccname":"系统管理员","banktypecode":null,"expenseDate":"2018-03-07","serialNo":"test010326012018030035","pk_recacc":{"name":"系统管理员","pk":"62c6731ee4c540deb4270253e00cf7d4"},"money":21493,"paybankaccname":"01","paystatustime":"2018-03-09","recacc":"61111670030747901","paystatus":"支付成功","pk_paybankacc":{"name":"01","pk":"BF40A2EE-C5AB-4ABE-891F-DB8E01F3D37B"},"def9":null,"paybankacc":"01","paystatususerid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"descript":"2113123","def7":null,"paytype":"offline","def8":null,"pk_billtype":{"name":"差旅费报销单1","pk":"6PSCjvQuCscKVFXTMIdtV"},"def5":null,"ts":1520564670000,"def6":null},{"exportuserid":{"name":null,"pk":null},"pkBanktype":{"name":null,"pk":null},"deptid":{"name":"财务部","pk":"D1961E20-2FF1-4DA6-95C6-E176538351D9"},"localCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"paystatuscode":"paysucess","billtypecode":"bx","billuserid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"def10":null,"exporttimes":0,"exportstatus":"未导出","pkSourcebill":"8SSCbCr1DiSG1JNmUILke","id":"ZISCtCln3jnEflj2bXAAc","paytypename":"免支付","originalCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000002","code":"EUR","name":"欧元"},"localMoney":969.6213,"def3":null,"def4":null,"def1":null,"def2":null,"recaccname":null,"banktypecode":null,"expenseDate":"2018-03-07","serialNo":"test010326012018030042","pk_recacc":{"name":null,"pk":null},"money":123,"paybankaccname":null,"paystatustime":null,"recacc":null,"paystatus":"支付成功","pk_paybankacc":{"name":null,"pk":null},"def9":null,"paybankacc":null,"paystatususerid":{"name":null,"pk":null},"descript":"123456798","def7":null,"paytype":"nopay","def8":null,"pk_billtype":{"name":"报销-陈","pk":"EdSCHExcWDINUgPRPhUOi"},"def5":null,"ts":1520405355000,"def6":null},{"exportuserid":{"name":null,"pk":null},"pkBanktype":{"name":null,"pk":null},"deptid":{"name":"财务部","pk":"D1961E20-2FF1-4DA6-95C6-E176538351D9"},"localCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"paystatuscode":"paysucess","billtypecode":"bx","billuserid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"def10":null,"exporttimes":0,"exportstatus":"未导出","pkSourcebill":"S6SCWtuiNLUoRHDXQCOJ6","id":"jVSCfLGsq8abcVgKpHyfk","paytypename":"免支付","originalCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"localMoney":1E+1,"def3":null,"def4":null,"def1":null,"def2":null,"recaccname":null,"banktypecode":null,"expenseDate":"2018-03-06","serialNo":"test010326012018030028","pk_recacc":{"name":null,"pk":null},"money":1E+1,"paybankaccname":null,"paystatustime":null,"recacc":null,"paystatus":"支付成功","pk_paybankacc":{"name":null,"pk":null},"def9":null,"paybankacc":null,"paystatususerid":{"name":null,"pk":null},"descript":"123654","def7":null,"paytype":"nopay","def8":null,"pk_billtype":{"name":"报销-陈","pk":"EdSCHExcWDINUgPRPhUOi"},"def5":null,"ts":1520321298000,"def6":null},{"exportuserid":{"name":null,"pk":null},"pkBanktype":{"name":null,"pk":null},"deptid":{"name":"财务部","pk":"D1961E20-2FF1-4DA6-95C6-E176538351D9"},"localCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"paystatuscode":"paysucess","billtypecode":"jk","billuserid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"def10":null,"exporttimes":0,"exportstatus":"未导出","pkSourcebill":"aOSCYtaUfLiAVpd1iHNfK","id":"GkSCuelwlTdZStZxSDQHL","paytypename":"免支付","originalCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"localMoney":123,"def3":null,"def4":null,"def1":null,"def2":null,"recaccname":null,"banktypecode":null,"expenseDate":"2018-03-05","serialNo":"test010324012018030006","pk_recacc":{"name":null,"pk":null},"money":123,"paybankaccname":null,"paystatustime":null,"recacc":null,"paystatus":"支付成功","pk_paybankacc":{"name":null,"pk":null},"def9":null,"paybankacc":null,"paystatususerid":{"name":null,"pk":null},"descript":"12","def7":null,"paytype":"nopay","def8":null,"pk_billtype":{"name":"借款-陈","pk":"4ySC8VRunQt0JFDtdkV64"},"def5":null,"ts":1520233225000,"def6":null},{"exportuserid":{"name":null,"pk":null},"pkBanktype":{"name":null,"pk":null},"deptid":{"name":"财务部","pk":"D1961E20-2FF1-4DA6-95C6-E176538351D9"},"localCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"paystatuscode":"paysucess","billtypecode":"bx","billuserid":{"name":"系统管理员","pk":"5dbb8df8-0956-4cd1-9da3-43b180069f0f"},"def10":null,"exporttimes":0,"exportstatus":"未导出","pkSourcebill":"5BSC7HfVmCuD5nFqN4XG9","id":"PLSCA5mbhl8WHzixuyvb3","paytypename":"免支付","originalCurrency":{"id":"G001ZM0000DEFAULTCURRENCT00000000001","code":"CNY","name":"人民币"},"localMoney":1E+1,"def3":null,"def4":null,"def1":null,"def2":null,"recaccname":null,"banktypecode":null,"expenseDate":"2018-03-05","serialNo":"test010326012018030017","pk_recacc":{"name":null,"pk":null},"money":1E+1,"paybankaccname":null,"paystatustime":null,"recacc":null,"paystatus":"支付成功","pk_paybankacc":{"name":null,"pk":null},"def9":null,"paybankacc":null,"paystatususerid":{"name":null,"pk":null},"descript":"12","def7":null,"paytype":"nopay","def8":null,"pk_billtype":{"name":"报销-陈","pk":"EdSCHExcWDINUgPRPhUOi"},"def5":null,"ts":1520233092000,"def6":null}],"totalnum":61,"success":true,"page":1,"pagenum":15};


    return (
      <div className="balance">
        {tips}
        <div className="tabs-bar">
          <ul className="nav nav-tabs fl">
            <li role="presentation" className={this.state.tabIndex == 0 ? "active" : ""}
                onClick={this.tabPageUpdate.bind(this, 0)}>
              <a href="javascript:;">待支付({this.state.count})</a>
            </li>
            <li role="presentation" className={this.state.tabIndex == 1 ? "active" : ""}
                onClick={this.tabPageUpdate.bind(this, 1)}>
              <a href="javascript:;">已支付({this.state.countcheck})</a>
            </li>
          </ul>

          <div className="input-group fl">
            <input type="text" className="form-control" ref="searchvalue" onChange={this.changeinput}
                   value={this.state.searchvalue} placeholder="单据编号/报账人/金额"/>
            <span className="input-group-btn">
                   <button className="btn btn-default" onClick={this.searchClick} type="button">
                     <span className="glyphicon glyphicon-search"></span>
                   </button>
                 </span>
          </div>
        </div>
        <Spinner show={this.state.loading} text="努力加载中..."></Spinner>
        <Grid tableData={this.state.tableData} columnsModel={this.state.tableColumn} className="ssc-grid"
              ref={(c) => {
                _this.gridUserlist = c;
              }}
              selectRow={{
                mode: 'checkbox',
                onSelect: this.handleSelect.bind(this),
                onSelectAll: this.handleSelectAll.bind(this)
              }}
              operationColumn={_this.state.tabIndex == 0 ? {} : null}
              operationColumnClass={CustomComponent}
              paging
              totalPage={this.state.totalPage}
              activePage={this.state.activePage}
              onPagination={this.handlePagination}
              onRowDoubleClick={_this.billDetail}
        />
        <div className="btn-bottom-fixed">
          <div className="row btn-bottom">
            <div className="col-sm-12">
              {this.state.tabIndex == 0 ? <button type="button"
                                                  className={(selectedData.length && payBtnDisabled ) > 0 ? 'btn btn-primary fr' : 'btn btn-primary fr disabled'}
                                                  onClick={(selectedData.length > 0 && payBtnDisabled) ? () => {_this.payType = PAYTYPE.OFFLINE; _this.showPayAccountModal();} : ''}>
                线下支付</button> : ''}
              <button type="button" className="btn btn-default fr" onClick={_this.changeExportStatus.bind(this)}>导出
              </button>
            </div>
          </div>
        </div>
        <Dialog ref="dialog"/>
        <Modal
          show={_this.state.payModalShow}
          onHide={_this.closePayAccountModal}
          container={this}
          aria-labelledby="contained-modal-title">
          <Modal.Header closeButton>
            <Modal.Title id="contained-modal-title">支付</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <ul>
              <li>支付账户编辑</li>
              <li><Refers
                placeholder={'请选择支付账户'}
                referDataUrl={Config.BABLANCE.payAccountRefer}
                labelKey="account"
                onChange={_this._handleChange}
                onBlur={_this._handleBlur}
                selected={_this.state.selectedPayAcc}
                emptyLabel={'暂无数据'}
                tableColumns={[{"field": "acctname", "label": "账户名"}, {"field": "account", "label": "账户号"}]}
                referConditions={{"refCode": "data", "refType": "list", "fields": ["account", "acctname", "id"]}}/></li>
            </ul>
          </Modal.Body>
          <Modal.Footer>
            <Button onClick={_this.closePayAccountModal}>取消</Button>
            <Button onClick={_this.state.payModalState ? _this.payModalSubmit : void(0)}
                    className={_this.state.payModalState ? "btn btn-primary" : 'btn btn-primary disabled'}>确认</Button>
          </Modal.Footer>
        </Modal>

        {/*<div>
          <h2>天威诚信-CAdemo</h2>
          <h4>证书登录</h4>
          <hr/>
          <form name="LogonForm" onSubmit={_this.checkForm}>
            用户名：
            <input id="UserName" name="UserName" type="text"/>
            <br/>
            密 码：
            <input id="Password" name="Password" type="password" value="password"/>
            <br/>
            请选择证书：
            <select id="CertList" name="CertList" style={{"width": "150px"}} onChange={_this.selectCert}>

            </select>
            <br/>
            <input type="button" value="checkSupoort" onClick={_this.checkHardwareSupport} />
            <input ref="login" name="Submit" type="submit" value="登陆"/>
            <input id="ToSign" name="ToSign" type="hidden" value="1513256292553"/>
            <input id="SignedData" name="SignedData" type="hidden"/>
          </form>
        </div>*/}
      </div>
    );
  }
}

//影射Store的State到App的Props, 这里用做数据
function mapStateToProps(state) {
  return state.balance;
}

//影射Store的dispath到App的Props,这里用做操作(事件)
function mapDispatchToProps(dispatch) {
  return bindActionCreators(actionBalance, dispatch);
}

//练接是中间组件react-redux功能,用于把React的Props, State, Event和Redux的关联
export default connect(mapStateToProps, mapDispatchToProps)(Balance);
