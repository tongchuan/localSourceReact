import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as actionBalance from '../actions/actionBalance';
import Accountant from "../components/HomePage/Accountant";
import Cashier from "../components/HomePage/Cashier";
import Employee from "../components/HomePage/Employee";
import Manager from "../components/HomePage/Manager";

class HomePage extends React.Component {
    constructor (props) {
        super(props);
        this.state = {
            role:""
        }
    }
    componentDidMount(){
        this.setState({role:$.cookie("_A_P_rolecode")}) ;
    }
    render() {
        let role = this.state.role;
        let body = (<div></div>)
        if(role==="accountant")
            body=(<Accountant />)
        else if(role==="cashier")
            body=(<Cashier />)
        else if(role==="manager")
            body=(<Manager />)
        else
            body=(<Employee />)
        return (
            <div>
                {body}
            </div>
        );
    }
}

//影射Store的State到App的Props, 这里用做数据
function mapStateToProps(state) {
    return state.balance;
}

//影射Store的dispath到App的Props,这里用做操作(事件)
function mapDispatchToProps(dispatch) {
    return bindActionCreators(actionBalance, dispatch);
}

//练接是中间组件react-redux功能,用于把React的Props, State, Event和Redux的关联
export default connect(mapStateToProps, mapDispatchToProps)(HomePage);
