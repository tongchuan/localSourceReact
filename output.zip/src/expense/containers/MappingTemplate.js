import React, { Component, PropTypes } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Link } from 'react-router';

import { ButtonToolbar, Button, DropdownButton, MenuItem } from 'react-bootstrap';
import { Grid, Row, Col, Modal } from 'react-bootstrap';

import * as Actions from '../actions/mappingTemplate';

// Constants for table
const itemsPerPage = 5;
const startIndex = 1;

class MappingTemplate extends Component {
  static PropTypes = {
    //dispatch: PropTypes.func.isRequired
  }

  constructor(props) {
    super(props);
  }

  componentWillMount() {
    this.props.fetchTableData(itemsPerPage, startIndex);
    this.props.fetchConfigData();
  }

  // admin card actions
  handleCreate(event) {
    this.props.showCreateDialog();
  }
  handleUpdate(event) {
  }
  handleDelete(event) {
    this.props.deleteTableData();
  }

  closeEditDialog() {
    this.props.hideEditDialog();
  }

  closeCreateDialog() {
    this.props.hideCreateDialog();
  }

  // create form
  handleCreateFormBlur(label, value) {
    this.props.updateCreateFormFieldValue(label, value);
  }
  handleCreateFormSubmit() {
    this.props.submitCreateForm();
  }

  // edit form
  handleEditFormBlur(label, value) {
    this.props.updateEditFormFieldValue(label, value);
  }
  handleEditFormSubmit() {
    this.props.submitEditForm();
  }

  handleAlertDismiss(){
    this.props.hideAdminAlert();
  }

  // http://git.yonyou.com/sscplatform/ssc_web/commit/767e39de04b1182d8ba6ad55636e959a04b99d2b#note_3528
  //handlePagination(event, selectedEvent) {
  handlePagination(eventKey) {
    const { tableData } = this.props;

    //let page = selectedEvent.eventKey;
    let page = eventKey;

    //if (page == this.state.activePage) return;

    let startIndex = (page-1) * itemsPerPage + 1;
    //this.props.changePage(startIndex);
    this.props.fetchTableData(itemsPerPage, startIndex);
  }

  handleSelectOne(rowId, checked) {
    var rows = this.state.selectedRows;
    rows[rowId] = checked;
    this.setState({
      selectedRow: rows
    });

    this.props.changeSelectedRows(rowId, checked);
  }

  handleEdit(rowId, rowData) {
    this.props.showEditDialog(rowId, rowData);
    this.props.initEditFormData(rowData.cols);
  }

  // 保存按钮
  handleSaveButtonClick(event) {
  }

  // 取消按钮
  handleCancelButtonClick(event) {
  }

  // 预览按钮
  handlePreviewButtonClick(event) {
  }

  // +按钮（添加）
  handleAddMapping(event) {
  }

  render() {
    const {
      tableData,
      editDialog, editFormData,
      createDialog, createFormData,
      adminAlert, config
    } = this.props;

    const titleStyle = {
      border: '1px solid',
      backgroundColor: '#d3b8fd'
    };
    const fiBodyStyle = {
      border: '1px solid',
      height: '40px'
    };
    const ncBodyStyle = {
      border: '1px dashed #cccccc',
      height: '40px'
    };
    const mappingHeaderStyle = {
      backgroundColor: '#f2f2f2',
      width: '99px',
      height: '30px',
      margin: '0 auto',
      padding: '5px',
      textAlign: 'center'
    };
    const mappingBodyStyle = {
      height: '40px'
    };

    const columnsSize = {
      fi: 3,
      arrow: 3,
      nc: 3,
      button: 3
    }

    const data = [
      {fi: '基本信息', nc: '基本信息', head: true},
      {fi: '日期', nc: '单据日期'},
      {fi: '报账金额', nc: '报账金额'},
      {fi: '备注', nc: '备注'},
      {fi: '交通', nc: '交通', head: true},
      {fi: '出发日期', nc: '出发日期'},
      {fi: '出发地', nc: '出发地'},
      {fi: '目的地', nc: '目的地'},
      {fi: '交通工具', nc: '交通工具'},
      {fi: '金额', nc: '金额'},
      {fi: '备注', nc: '备注'}
    ];

    return (
      <div>
        <Grid>
          <Row className="action-buttons">
            <Col md={12}>
              <ButtonToolbar>
                <Button onClick={::this.handleSaveButtonClick}>保存</Button>
                <Button onClick={::this.handleCancelButtonClick}>取消</Button>
                <Button onClick={::this.handlePreviewButtonClick}>预览</Button>
                <DropdownButton bsStyle="default" title="14" id="dropdown-basic-0">
                  <MenuItem eventKey="1">Action</MenuItem>
                  <MenuItem eventKey="2">Another action</MenuItem>
                  <MenuItem eventKey="3" active>Active Item</MenuItem>
                  <MenuItem divider />
                  <MenuItem eventKey="4">Separated link</MenuItem>
                </DropdownButton>
              </ButtonToolbar>
            </Col>
          </Row>
          <Row className="mapping-header">
            <Col md={columnsSize.fi} className="text-center">
              <div style={mappingHeaderStyle}>报账单数据</div>
            </Col>
            <Col md={columnsSize.arrow}></Col>
            <Col md={columnsSize.nc}>
              <div style={mappingHeaderStyle}>NC数据</div>
            </Col>
            <Col md={columnsSize.button}></Col>
          </Row>
          {data.map((meta, i) => (
            meta.head ? <Row key={i} className="mapping-body-title show-grid">
              <Col md={columnsSize.fi} className="text-center" style={titleStyle}>{meta.fi}</Col>
              <Col md={columnsSize.arrow}></Col>
              <Col md={columnsSize.nc}>{meta.nc}</Col>
            </Row> :
            <Row key={i} className="mapping-body" style={mappingBodyStyle}>
              <Col md={columnsSize.fi} style={fiBodyStyle}>{meta.fi}</Col>
              <Col md={columnsSize.arrow}>-------------------></Col>
              <Col md={columnsSize.nc} style={ncBodyStyle}>{meta.nc}</Col>
              <Col md={columnsSize.button}><Button onClick={::this.handleAddMapping}>+</Button></Col>
            </Row>
          ))}
        </Grid>
      </div>
    );
  }
};

function mapStateToProps(state, ownProps) {
  return { ...state.ncSync };
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators(Actions, dispatch);
}

// The component will subscribe to Redux store updates.
export default connect(mapStateToProps, mapDispatchToProps)(MappingTemplate);
