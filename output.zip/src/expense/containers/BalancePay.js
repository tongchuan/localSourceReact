/**
 * author:zhangtongchuan
 * date: 2017-00-03
 * mail: zhangtch@yonyou.com
 */
import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as actionBalance from '../actions/actionBalance';
import Dialog from '../../common/components/StaticModel';
import { Grid } from 'ssc-grid';
import { Refers } from 'ssc-refer';
import {Alert} from "react-bootstrap" ;
import Spinner  from '../components/spinner/spinner';
import Config from '../config'
import {Button,Modal} from 'react-bootstrap';

// Config.BABLANCE.blankRefer='http://10.6.241.20:88/nodebillpay/referJSON'

class BalancePay extends React.Component {
  constructor(props){
    super(props);
    this.state={
      tabIndex:0,
      tableData:[],
      tableColumn:[],
      selectedData:[],
      count:0,
      countcheck:0,
      totalPage:1,
      activePage:1,
      pagenum:15,
      paybankacc:'',//code
      pk_paybankacc:'',//id
      paybankname:'', //name
      searchvalue:'',
      vaguequeryparam:'', //模糊搜素
      errorMessage:"数据请求错误",   // 头部提示文字
      alertVisible:false,     // 头部提示状态
      loading:true,      // 加载图
      payModalShow:false,
      payModalState:false,
      payType:'',
      defaultSelected:[{
        id:"",
        code:'',
        name:'',
        pid:"",
        isLeaf:"true"
      }] //默认值
    }
    this.getTableDataList(1);
    this.onClickPayStatus = this.onClickPayStatus.bind(this);

    this.changePayStatus=this.changePayStatus.bind(this)
    this.changeExportStatus=this.changeExportStatus.bind(this);
    this.renderMenuItemChildren=this.renderMenuItemChildren.bind(this);
    this.sendBillPayQueryStatues = this.sendBillPayQueryStatues.bind(this);
    this.payModalClose = this.payModalClose.bind(this);
    this.payTypeClick = this.payTypeClick.bind(this);
    this.payModalSubmit = this.payModalSubmit.bind(this);
    this.handleBeforeSelect = this.handleBeforeSelect.bind(this);
    this.handleBeforeSelectAll = this.handleBeforeSelectAll.bind(this);
  }
  componentWillMount(){
    let that = this;
    that.props.getTableColumn((data)=>{
      that.setState({
        tableColumn:data
      });
    });
    this.getTableDataList(0);
  }
  getTableDataList=(tabIndex,count)=>{
    let that = this;
    let data = {
      "condition": "",
      "paras": [],
      "fields": [],
      vaguequeryparam:that.state.vaguequeryparam,
      "page":that.state.activePage,
      "pagenum": that.state.pagenum
    }
    if(!that.state.loading){
      that.setState({
        loading:true
      })
    }

    this.props.getTableData(tabIndex,data,(err,data)=>{
      that.setState({
        loading:false
      })
      if(err===undefined){
        if(data.success){
          if(!count){
            if(tabIndex==0){
              let totalPage = Math.ceil(data.totalnum / that.state.pagenum);
              that.setState({
                tableData:data.data!=null ? data.data: [],
                count:data!=null ? data.totalnum : 0,
                totalPage:totalPage
              })
            }else{
              that.setState({
                countcheck:data!=null ? data.totalnum : 0
              })
            }
          }else{
            let totalPage = Math.ceil(data.totalnum / that.state.pagenum);
            if(tabIndex==0){
              that.setState({
                count:data!=null ? data.totalnum : 0,
                tableData:data.data!=null ? data.data: [],
                totalPage:totalPage
              })
            }else{
              that.setState({
                countcheck:data!=null ? data.totalnum : 0,
                tableData:data.data!=null ? data.data: [],
                totalPage:totalPage
              })
            }
          }
        }else{
          that.setState({
            alertVisible:true ,
            errorMessage:data.message
          })
          // $.msgShow({title:'获取数据失败',children:<div><ul><li>{data.message}</li></ul></div>,confirmClick:{}});
        }
      }else{
        that.setState({
          alertVisible:true ,
          errorMessage:err.toString()
        })
        // $.msgShow({title:'获取数据失败',children:<div><ul><li>{err.toString()}</li></ul></div>,confirmClick:{}});
      }
    })
  }
  tabPageUpdate(tabIndex){
    let that = this;
    if(that.state.tabIndex!=tabIndex){
      that.setState({
        tabIndex:tabIndex,
        activePage:1,
        selectedData:[]
      })
    }
    this.getTableDataList(tabIndex,true);
  }
  handleBeforeSelect(rowIdx, rowObj , selected, event, selectedRows ){
    // console.log(selected);
    let that = this;
    if(that.state.tabIndex == 0&& selected){
      let selectedData = that.state.selectedData;
      let isFlag = false;
      selectedData.forEach((item,index)=>{
        if(item.paystatuscode != rowObj.paystatuscode){
          isFlag=true;
        }
      });
      if(isFlag){
        $.msgShow({title:'提示信息',children:<div><ul><li>单据支付类型不同，不能选择不同类型的单据！</li></ul></div>,confirmClick:{}});
        return false;
      }
    }
    return true;

  }
  handleBeforeSelectAll(tableData, selected){
    // console.log('333');
    let that = this;
    if(that.state.tabIndex == 0&& selected){
      let selectedData=[].concat(tableData);
      let isFlag = false;
      selectedData.reduce((previousValue,currentValue,index)=>{
        if(previousValue.paystatuscode != currentValue.paystatuscode){
          isFlag=true;
        }
        return currentValue;
      });
      if(isFlag){
        $.msgShow({title:'提示信息',children:<div><ul><li>单据支付类型不同，不能选择不同类型的单据！</li></ul></div>,confirmClick:{}});
        return false;
      }
    }
    return true;
  }
  //单个选中
  handleSelect(rowIdx, rowObj, selected){
    // console.log(arguments);
    let selectedData = [].concat(this.state.selectedData);
    let i = -1;
    selectedData.map(function(item,index){
      if(item==rowObj){
        i = index;
      }
    })
    if(selected && i==-1){
      selectedData.push(rowObj);
    }
    if(!selected && i!=-1){
      selectedData.splice(i,1);
    }
    this.setState({
      selectedData:selectedData
    })

  }
  //选中所有
  handleSelectAll(tableData, selected){
    let selectedData = [];
    if(selected){
      selectedData=[].concat(tableData);
    }
    this.setState({
      selectedData:selectedData
    })
    // console.log(selectedData);
  }
  renderMenuItemChildren(option,props,index){
    return (
      <div>
        <span>{option.code}:{option.name}</span>
      </div>
    )
  }

  //支付成功
  changePayStatus(){
    let that = this;
    // console.log(that.state.selectedData.length);
    if(that.state.selectedData.length<1){
      $.msgShow({title:'提示信息',children:<div><ul><li>请选择单据</li></ul></div>,confirmClick:{}});
      return false;
    }
    let data = {
      nodebillpayids:that.state.selectedData.map(function(item){return item.id}),
    }
    that.setState({
      loading :true
    })
    this.props.sendPlaySuccess(data,(err,data)=>{
      that.setState({
        loading :false
      })
      if(err===undefined) {
        that.getTableDataList(that.state.tabIndex,true);
        that.setState({
          selectedData:[]
        })
        if(data.success){
          $.msgShow({title:'支付账户',children:<div><ul><li>操作成功</li></ul></div>,confirmClick:{}});
        }else{
          $.msgShow({title:'支付失败',children:<div><ul><li>{data.message}</li></ul></div>,confirmClick:{}});
        }
      }else{
        $.msgShow({title:'支付失败',children:<div><ul><li>{err.toString()}</li></ul></div>,confirmClick:{}});
      }
    })
  }
  //导出支付文件
  changeExportStatus(){
    let that = this;
    // console.log(that.state.selectedData.length);
    if(that.state.selectedData.length<1){
      $.msgShow({title:'提示信息',children:<div><ul><li>请选择单据</li></ul></div>,confirmClick:{}});
      return false;
    }
    let data = {
      nodebillpayids:that.state.selectedData.map(function(item){return item.id}),
    }
    that.setState({
      loading :true
    })
    this.props.sendExport(data,(err,data)=>{
      that.setState({
        loading :false
      })
      if(err===undefined) {
        if(data.success){
          that.setState({
            selectedData:[]
          });
          that.getTableDataList(that.state.tabIndex,true);
          window.open(data.dowbankfilenurl+"&phone=13923456789","_blank");
        }else{
          $.msgShow({title:'导出支付文件失败',children:<div><ul><li>{data.message}</li></ul></div>,confirmClick:{}});
        }
      }else{
        $.msgShow({title:'导出支付文件失败',children:<div><ul><li>{err.toString()}</li></ul></div>,confirmClick:{}});
      }
    })
  }
  //支付
  onClickPayStatus(event){
    let that = this;
    // console.log(that.state.selectedData.length);
    if(that.state.selectedData.length<1){
      $.msgShow({title:'提示信息',children:<div><ul><li>请选择单据</li></ul></div>,confirmClick:{}});
      return false;
    }
    let defaultSelected={
      id:"",
      code:'',
      name:'',
      pid:"",
      isLeaf:"true"
    };
    let payType = '';
    let flag = false;
    that.state.selectedData.forEach((item,index)=>{
      if(!flag && item.paybankacc){
        flag = true;
        defaultSelected.id = item.pk_paybankacc.pk;//"02EDD0F9-F384-43BF-9398-5E5781DAC5D0";
        defaultSelected.code = item.paybankacc;
        defaultSelected.name = item.pk_paybankacc.name;
        defaultSelected.pid = "";
        defaultSelected.isLeaf = "true";
        payType=item.paytype;
      }
    })
    // console.log(defaultSelected);
    that.setState({
      paybankacc:defaultSelected.code,
      pk_paybankacc:defaultSelected.id,
      paybankname:defaultSelected.name,
      defaultSelected:[defaultSelected],
      payType:payType,
      payModalShow:true
    },()=>{
      that.payTypeState();
    })

// sendBillPaySend
  }
  payModalClose(){
    let that = this;
    that.setState({
      payModalShow:false,
      // selectedData:[],
      payType:''
    })
  }
  //支付确认按钮点击
  payModalSubmit(){
    let that = this;
    let paybankacc=that.state.paybankacc;
    let pk_paybankacc=that.state.pk_paybankacc;
    let paybankname = that.state.paybankname;
    let nodebillpayids = that.state.selectedData.map(function(item){return item.id});
    let payType = that.state.payType;
    let replacePK = false;

    that.state.selectedData.map(function(item){
      if(item.pk_paybankacc.pk!=null && item.pk_paybankacc.pk!=pk_paybankacc){
        replacePK=true;
      }
    })
    //如果现有账户与选中账户不同进行提示或取消
    if(replacePK){
      $.msgShow({title:'支付账户替换',children:<div><ul><li>支付账户替换为：</li><li>{paybankacc+':'+paybankname}</li></ul></div>,closeClick:function(){
        // sState();
        that.setState({
          // selectedData:[],
          paybankacc:'',
          pk_paybankacc:'',
          paybankname:'',
          payModalShow:false,
          payModalState:false,
          payType:''
        })
      },confirmClick:function(){
        sendPay()
      }});
    }else{
      sendPay()
    }
    function sState(){
      that.setState({
        selectedData:[],
        paybankacc:'',
        pk_paybankacc:'',
        paybankname:'',
        payModalShow:false,
        payModalState:false,
        payType:''
      })
    }
    function sendPay(){
      sState()
      that.props.sendBillPaySend({
        paybankacc:paybankacc,
        paytype:payType,
        nodebillpayids:nodebillpayids,
        pk_paybankacc:pk_paybankacc
      },(err,d)=>{
        if(err===undefined){
          that.getTableDataList(that.state.tabIndex,true);
          that.setState({
            selectedData:[]
          })
          if(d.success){
            if(payType=='online'){
              window.open(d.url,'_blank')
            }

          }else{
            $.msgShow({title:'提示信息',children:<div><ul><li>{d.message}</li></ul></div>,confirmClick:{}});
          }
        }else{
          $.msgShow({title:'提示信息',children:<div><ul><li>{err.toString()}</li></ul></div>,confirmClick:{}});
        }
      })


    /*  that.props.sendPaybankacc({
        paybankacc:paybankacc,
        nodebillpayids:nodebillpayids,
        pk_paybankacc:pk_paybankacc
      },(err,data)=>{
        if(err===undefined) {
          if(data.success){
            that.props.sendBillPaySend({
              paybankacc:paybankacc,
              paytype:payType,
              nodebillpayids:nodebillpayids
            },(err,d)=>{
              if(err===undefined){
                that.getTableDataList(that.state.tabIndex,true);
                that.setState({
                  selectedData:[]
                })
                if(d.success){
                  if(payType=='online'){
                    window.open(d.url,'_blank')
                  }

                }else{
                  $.msgShow({title:'提示信息',children:<div><ul><li>{d.message}</li></ul></div>,confirmClick:{}});
                }
              }else{
                $.msgShow({title:'提示信息',children:<div><ul><li>{err.toString()}</li></ul></div>,confirmClick:{}});
              }
            })
          }else{
            that.getTableDataList(that.state.tabIndex,true);
            that.setState({
              selectedData:[]
            })
            $.msgShow({title:'提示信息',children:<div><ul><li>{data.message}</li></ul></div>,confirmClick:{}});
          }
        }else{
          $.msgShow({title:'提示信息',children:<div><ul><li>{err.toString()}</li></ul></div>,confirmClick:{}});
        }
      })
      */
    }
  }
  //支付弹出框单选按钮
  payTypeClick(event){
    let that = this;
    let value = event.target.value;
    that.setState({
      payType:value
    },()=>{
      that.payTypeState();
    })
  }
  //更新弹出看确认按钮
  payTypeState(){
    let that = this;
    let state = false;
    if(this.state.payType!='' && this.state.paybankacc!=''){
      state=true;
    }
    that.setState({
      payModalState:state
    })
  }
  // 更新支付状态
  sendBillPayQueryStatues(){
    let that = this;
    if(that.state.selectedData.length<1){
      $.msgShow({title:'提示信息',children:<div><ul><li>请选择单据</li></ul></div>,confirmClick:{}});
      return false;
    }
    that.setState({
      loading :true
    })
    let data = {
      nodebillpayids:that.state.selectedData.map(function(item){return item.id})
    }
    that.props.sendBillPayQueryStatues(data,(err,data)=>{
      that.setState({
        loading :false
      })
      if(err==undefined){
        if(data.success){
          that.setState({
            selectedData:[]
          })
          that.getTableDataList(that.state.tabIndex,true);
        }else{
          $.msgShow({title:'更新支付状态失败',children:<div><ul><li>{data.message}</li></ul></div>,confirmClick:{}});
        }
      }else{
        $.msgShow({title:'更新支付状态失败',children:<div><ul><li>{err.toString()}</li></ul></div>,confirmClick:{}});
      }




    })
  }
  handlePagination=(nextPage)=>{
    let that = this;
    this.setState({
      activePage:nextPage,
      selectedData:[]
    },()=>{
      that.getTableDataList(that.state.tabIndex,true);
    })

  }
  changeinput=()=>{
    var val = this.refs.searchvalue.value
    this.setState({
      searchvalue:val
    })
  }
  searchClick=(event)=>{
    event.preventDefault();
    let that = this;
    var val = this.refs.searchvalue.value
    this.setState({
      selectedData:[],
      vaguequeryparam:val
    },()=>{
      // console.log(that.state.vaguequeryparam);
      // console.log(val)
      that.getTableDataList(that.state.tabIndex,true);
    })


  }
  _handleChange=(selected)=> {
    // console.log(selected);
    let that = this;
    if(selected!=null && selected.length>0){
      let paybankacc=selected[0].code
      let pk_paybankacc=selected[0].id
      let paybankname = selected[0].name
      this.setState({
        paybankacc:paybankacc,
        pk_paybankacc:pk_paybankacc,
        paybankname:paybankname
      },()=>{
        that.payTypeState();
      })
    }else{
      // console.log('dddd');
      this.setState({
        paybankacc:'',
        pk_paybankacc:'',
        paybankname:''
      },()=>{
        that.payTypeState();
      })
    }
  }
  _handleBlur=(e)=> {
    console.log(arguments);
    // console.log(JSON.stringify(e));
  }
  disMiss = () =>{
    this.setState({
      alertVisible:false
    })
  }

  render() {
    let that = this;
    var _this = this , tips = "";
    var sign = this.state.alertVisible ;
    if(sign){
      tips = (
          <Alert bsStyle="danger" onDismiss={_this.disMiss}>
            {_this.state.errorMessage}
          </Alert>
      )
    }
    const CustomComponent = React.createClass({
        itemClick(type,event) {
          event.preventDefault();
          switch (type) {
            case 1: //支付
              that.setState({
                selectedData:[this.props.rowObj]
              },()=>{
                that.onClickPayStatus()
              })
              break;
            case 2: //确认支付
              that.setState({
                selectedData:[this.props.rowObj]
              },()=>{
                that.changePayStatus()
              })
              break;
            case 3: //导出
              that.setState({
                selectedData:[this.props.rowObj]
              },()=>{
                  that.changeExportStatus();
              })
              break;
            default:
              break;
          }
        },

        render() {
          return (
            <td>
        {/**未支付*/this.props.rowObj.paystatuscode=="notpay" ? [<a href="javascript:void(0);" key={'1notpay'} onClick={this.itemClick.bind(this,1)}>支付</a>,<a href="javascript:void(0);"  key={'2notpay'} onClick={this.itemClick.bind(this,3)}>导出</a>] : ''}
        {/**支付中*/ this.props.rowObj.paystatuscode=="paying" ? [<a href="javascript:void(0);" key={'1paying'}  onClick={this.itemClick.bind(this,2)}>确认支付</a>,<a href="javascript:void(0);"  key={'2paying'} onClick={this.itemClick.bind(this,3)}>导出</a>] : '' }
        {/**支付失败*/this.props.rowObj.paystatuscode=="payfail" ? <a href="javascript:void(0);" onClick={this.itemClick.bind(this,3)}>导出</a> : ''}
        {/**支付成功*/this.props.rowObj.paystatuscode=="paysucess" ? <a href="javascript:void(0);" onClick={this.itemClick.bind(this,3)}>导出</a> : ''}
            </td>
          );
        }
      });
    let butDisabled =   that.state.selectedData.every((item)=>{
        return item.paystatuscode=="notpay"
      })
    return (
      <div className="balance">
          {tips}
          <div className="tabs-bar">
            <ul className="nav nav-tabs fl">
              <li role="presentation" className={this.state.tabIndex==0 ? "active":""} onClick={this.tabPageUpdate.bind(this,0)}>
                <a href="javascript:;">待支付({this.state.count})</a>
              </li>
              <li role="presentation" className={this.state.tabIndex==1 ? "active":""} onClick={this.tabPageUpdate.bind(this,1)}>
                <a href="javascript:;">已支付({this.state.countcheck})</a>
              </li>
            </ul>

            <div className="input-group fl">
              <input type="text" className="form-control" ref="searchvalue" onChange={this.changeinput} value={this.state.searchvalue} placeholder="金额和报账人" />
              <span className="input-group-btn">
                <button className="btn btn-default" onClick={this.searchClick} type="button">
                  <span className="glyphicon glyphicon-search"></span>
                </button>
              </span>
            </div>
            <a href="javascript:;" onClick={that.sendBillPayQueryStatues} className={this.state.tabIndex==0 ?　"fr":"hide"}>更新在线支付状态</a>
          </div>
           <Spinner show={this.state.loading} text="努力加载中..."></Spinner>
          <Grid tableData={this.state.tableData} columnsModel={this.state.tableColumn} className="ssc-grid"
              selectRow={{
                  mode: 'checkbox',
                  onBeforeSelect: this.handleBeforeSelect,
                  onBeforeSelectAll: this.handleBeforeSelectAll,
                  onSelect: this.handleSelect.bind(this),
                  onSelectAll: this.handleSelectAll.bind(this)
              }}
              paging
              totalPage={this.state.totalPage}
              activePage={this.state.activePage}
              onPagination={this.handlePagination}
              operationColumn={{className: 'operation',text: ' '}}
              operationColumnClass={CustomComponent}
          />
          <div className="btn-bottom-fixed">
            <div className="row btn-bottom">
              <div className="col-sm-12">
                {/**this.state.tabIndex==0 ? <button type="button" className="btn btn-primary fr" onClick={this.changePayStatus}>支付成功</button> : ''*/}
                {/**this.state.tabIndex==0 ? <button type="button" className="btn btn-primary fr" onClick={this.editPayAccount}>支付账户</button>:''*/}
                {/**<button type="button" className="btn btn-primary fr" onClick={this.changeExportStatus}>导出支付文件</button>*/}
                {this.state.tabIndex==0 ? <button type="button" className={(that.state.selectedData.length  && butDisabled )>0 ? 'btn btn-primary fr':'btn btn-primary fr disabled'} onClick={(that.state.selectedData.length>0 && butDisabled) ? this.onClickPayStatus : ''}>支付</button> : ''}
                {this.state.tabIndex==1 ? <button type="button" className={that.state.selectedData.length>0 ? 'btn btn-primary fr':'btn btn-primary fr disabled'} onClick={that.state.selectedData.length>0 ? this.changeExportStatus : ''}>导出支付文件</button> : ''}
              </div>
            </div>
          </div>
        <Dialog ref="dialog" />
        <Modal
            show={that.state.payModalShow}
            onHide={that.payModalClose}
            container={this}
            aria-labelledby="contained-modal-title">
            <Modal.Header closeButton>
              <Modal.Title id="contained-modal-title">选择支付方式</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <ul>
                  <li>已经选择{that.state.selectedData.length}条数据</li>
                  <li>支付账户：</li>
                  <li><Refers
                        referDataUrl={ Config.BABLANCE.blankRefer }
                        labelKey="name"
                        onChange={that._handleChange}
                        onBlur={that._handleBlur}
                        emptyLabel={'暂无数据'}
                        filterBy={['name', 'code']}
                        defaultSelected={that.state.defaultSelected}
                        renderMenuItemChildren={that.renderMenuItemChildren}
                        tableColumns={[{"field":"code","label":"编码"},{"field":"name", "label":"名称"}]}
                        referConditions={{"refCode":"bankaccount","refType":"tree"}} /></li>
                  <li>支付方式：</li>
                  <li>
                      <label className="radio-inline"><input type="radio" onClick={that.payTypeClick} checked={that.state.payType=='online'? true: false} name="playtype" value="online" /> 在线支付</label>
                      <label className="radio-inline"><input type="radio" onClick={that.payTypeClick} checked={that.state.payType=='export'? true: false} name="playtype" value="export" /> 线下支付(导出)</label>
                      <label className="radio-inline"><input type="radio" onClick={that.payTypeClick} checked={that.state.payType=='offline'? true: false} name="playtype" value="offline" /> 线下支付(手工支付)</label>
                  </li>
                </ul>
            </Modal.Body>
            <Modal.Footer>
              <Button onClick={that.payModalClose}>取消</Button>
              <Button onClick={that.state.payModalState ? that.payModalSubmit : void(0)} className={that.state.payModalState?"btn btn-primary":'btn btn-primary disabled'}>确定</Button>
            </Modal.Footer>
          </Modal>
      </div>
    );
  }
}

//影射Store的State到App的Props, 这里用做数据
function mapStateToProps(state) {
    return state.balance;
}

//影射Store的dispath到App的Props,这里用做操作(事件)
function mapDispatchToProps(dispatch) {
    return bindActionCreators(actionBalance, dispatch);
}

//练接是中间组件react-redux功能,用于把React的Props, State, Event和Redux的关联
export default connect(mapStateToProps, mapDispatchToProps)(BalancePay);
