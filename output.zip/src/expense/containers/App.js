import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Link } from 'react-router';

import Top from '../components/Top';
import Left from '../components/Left';
import Footer from '../components/Footer';
import Modal from '../components/Modal';
//Redux去除了React的Props和State的差别,还有事件,统一都是Props,也就是Provider Store
//Store组件,给下层的App创建映射的属性
class App extends React.Component {

    componentWillMount = () => {

    }
    componentDidMount = () => {
        // let h = document.documentElement.clientHeight;
        let w = $(window).height();
        var dom = $(".content");
        dom.height( w - $(".top-nav").height() );
        $(window).resize(
            function(){
                let w = $(window).height();
                var dom = $(".content");
                dom.height( w - $(".top-nav").height() );
            }
        );


        var that = this;
        $.extend({
          msgShow:function(options){
            that.refs.modal.show(options)
          }
        })
    }

    render() {
        return (
            <div>
                {/* <Top />*/}
                <div className="main">
                    {/*<Left />*/}
                    <div className = "content">
                        {this.props.children}
                        {/* <Footer />*/}
                    </div>
                </div>
                <Modal ref="modal" />
            </div>
        );
    }
}

export default App;
