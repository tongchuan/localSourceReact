import React from 'react';
import ReactDom from 'react-dom';
import { Router, Route, Link, IndexRoute } from 'react-router';

import App from './containers/App';

import NoMatch from './components/NoMatch';
import MyWork from './containers/mywork/MyWork';

import Account from './containers/account/Account';
import AccountBalance from './containers/account/AccountBalance';
import AccountGeneral from './containers/account/AccountGeneral';
import AccountSubsidiary from './containers/account/AccountSubsidiary';

import Ufoe from './containers/ufoe/Ufoe';
import UfoeIncome from './containers/ufoe/UfoeIncome';
import UfoeBalance from './containers/ufoe/UfoeBalance';

import Setting from './containers/setting/Setting';
import SettingAccount from './containers/setting/SettingAccount';
import SettingSubject from './containers/setting/SettingSubject';
import SettingBasic from './containers/setting/SettingBasic';

import Voucher from './containers/voucher/Voucher';
import VoucherEdit from './containers/voucher/VoucherEdit';
import VoucherList from './containers/voucher/VoucherList';
import VoucherDetail from './containers/voucher/VoucherDetail';

ReactDom.render(
        <Router>
            <Route path="/" component={App}>
                <IndexRoute component={MyWork}/>
                <Route path="/mywork" component={MyWork}>
                </Route>
                <Route path="/voucher" component={Voucher}>
                    <Route path="edit" component={VoucherEdit} />
                    <Route path="detail/:id" component={VoucherDetail} />
                    <Route path="list" component={VoucherList} />
                </Route>
                <Route path="/ufoe" component={Ufoe}>
                    <Route path="balance" component={UfoeBalance} />
                    <Route path="income" component={UfoeIncome} />
                </Route>
                <Route path="/setting" component={Setting}>
                    <Route path="subjects" component={SettingSubject} />
                    <Route path="basic" component={SettingBasic} />
                    <Route path="account" component={SettingAccount} />
                </Route>
                <Route path="/account" component={Account}>
                    <Route path="general" component={AccountGeneral} />
                    <Route path="subsidiary" component={AccountSubsidiary} />
                    <Route path="balance" component={AccountBalance} />
                </Route>
                <Route path="*" component={NoMatch}/>
            </Route>
        </Router>,
    document.getElementById('root')
);


