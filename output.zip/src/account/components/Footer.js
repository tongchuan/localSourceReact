import React from 'react';

export default class Footer extends React.Component {
    render() {
        return (
            <div id="footer"  style={{margin:"0 auto",textAlign:"center"}}>
                <a href="#" target="_blank">帮助中心 </a>
                <a href="#" target="_blank">说明</a>
            </div>
        );
    }
};
