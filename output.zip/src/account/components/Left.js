/**
 * Created by liuyyg on 2017/1/20.
 */
import React from 'react';
import {Link} from 'react-router';
// import cx from 'classnames';

export default class Left extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            active: null,
            tree: {}
        }
    }

    renderNode = (node) => {

    };
    onClickNode = (node) => {
        this.setState({
            active: node
        });
    };
    handleChange = (tree) => {
        this.setState({
            tree: tree
        });
    };

    // 左边栏 上移 下移
    toUp = () => {}
    toDown = () => {}

    render() {
        let _this = this;
        return (
            <section className="sidenav sidenav-container" id="sidenav">

                <div className="sidenav-body">
                    <ul className="nav">
                        <li className="nav-item">
                            <a href="#/mywork">
                                <div className="nav-icon">
                                    <i aria-hidden="true" className="glyphicon glyphicon-user"></i>
                                </div>
                                <div className="nav-text">
                                    <span>工作台</span>
                                </div>
                            </a>
                        </li>
                        <li className="nav-item">
                            <div className="nav-icon">
                                <i aria-hidden="true" className="glyphicon glyphicon-th-large"></i>
                            </div>
                            <div className="nav-text">
                                <span>账务处理</span>
                            </div>
                            <ul className="menu-child-list">
                                <li>
                                    <Link to={"/voucher/edit"}>制单</Link>
                                </li>
                                <li>
                                    <Link to={"/voucher/list"}>查看凭证</Link>
                                </li>
                            </ul>
                        </li>
                        <li className="nav-item">
                            <div className="nav-icon">
                                <i aria-hidden="true" className="glyphicon glyphicon-search"></i>
                            </div>
                            <div className="nav-text">
                                <span>账簿</span>
                            </div>
                            <ul className="menu-child-list">
                                <li>
                                    <Link to={"/account/general"}>总账</Link>
                                </li>
                                <li>
                                    <Link to={"/account/subsidiary"}>明细账</Link>
                                </li>
                                <li>
                                    <Link to={"/account/balance"}>余额表</Link>
                                </li>
                            </ul>
                        </li>
                        <li className="nav-item">
                            <div className="nav-icon">
                                <i aria-hidden="true" className="glyphicon glyphicon-eject"></i>
                            </div>
                            <div className="nav-text">
                                <span>会计报表</span>
                            </div>
                            <ul className="menu-child-list">
                                <li>
                                    <Link to={"/ufoe/balance"}>资产负债表</Link>
                                </li>
                                <li>
                                    <Link to={"/ufoe/income"}>利润表</Link>
                                </li>
                            </ul>
                        </li>
                        <li className="nav-item">
                            <div className="nav-icon">
                                <i aria-hidden="true" className="glyphicon glyphicon-asterisk"></i>
                            </div>
                            <div className="nav-text">
                                <span>基础设置</span>
                            </div>
                            <ul className="menu-child-list">
                                <li>
                                    <Link to={"/setting/account"}>账套设置</Link>
                                </li>
                            </ul>
                        </li>
                        {
                        //     <li className="nav-item">
                        //         <div className="nav-icon">
                        //             <i aria-hidden="true" ></i>
                        //         </div>
                        //         <div className="nav-text">
                        //             <span>结转结账</span>
                        //         </div>
                        //         <ul className="menu-child-list">
                        //             <li>
                        //                 <a href="/voucher/carryover/final" >期末结转</a>
                        //             </li><li>
                        //             <a href="/voucher/carryover/checkout">结账</a>
                        //         </li>
                        //         </ul>
                        // </li>
                        }
                    </ul>
                </div>
                {
                    // <div className="sidenav-footer">
                    //     <div className="sidenav-setting-container">
                    //         <div className="setting-icon">
                    //             <span className="glyphicon glyphicon-asterisk"></span>
                    //         </div>
                    //         <div className="setting-title">
                    //             <span>基础设置</span>
                    //         </div>
                    //         <ul className="menu-child-list">
                    //             <li>
                    //                 <Link to={"/setting/subjects"}>科目期初</Link>
                    //             </li>
                    //             <li>
                    //                 <Link to={"/setting/basic-data"}>辅助核算</Link>
                    //             </li>
                    //             <li>
                    //                 <Link to={"/setting/account"}>账套设置</Link>
                    //             </li>
                    //         </ul>
                    //     </div>
                    // </div>
                }
                <div className="sidenav-scroll-btn">
                    <div className="up-btn" onClick={_this.toUp.bind(this)}>
                        <i className="glyphicon glyphicon-menu-up"></i>
                    </div>
                    <div className="down-btn" onClick={_this.toDown.bind(this)}>
                        <i className="glyphicon glyphicon-menu-down"></i>
                    </div>
                </div>
            </section>
        );
    }
};
