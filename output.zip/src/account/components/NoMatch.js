import React from 'react';

export default class NoMatch extends React.Component {
    render() {

        return (
            <div>404, 你要请求的内容未找到...</div>
        );
    }
};
