//var serverUrl = 'http://20.1.78.13:3000';  // 服务器地址
//var localUrl = "http://127.0.0.1:8080";      // Tomcat

//调用java api的url
var serverUrl = "http://10.3.14.237/ficloud";

//portal的url
var localUrl = "http://" + location.host;


var Config = {

    serverUrl:serverUrl,
    localUrl: localUrl ,

    account:{
        voucherList:serverUrl+'/voucher/list',    //查询凭证列表
        voucherDetail:serverUrl+'/voucher/query',   //查询凭证详情
        voucherDel:serverUrl+'/voucher/delete',    //删除
        voucherEnable:serverUrl+'/voucher/enable',
        voucherDisable:serverUrl+'/voucher/disable',
        voucherSave:serverUrl+'/voucher/save'
    }

};

export default Config;
