/**
 * 账簿页面组件
 */
import React from 'react';
import TabStore from '../../stores/TabStore';
import Tab from '../common/Tab';

const tabStore = new TabStore();

class Demo extends React.Component {
    render() {
        return (
            <div>
                账簿
                查询+列表组件
              <Tab tabStore={tabStore}/>
            </div>
        );
    }
}

export default Demo;
