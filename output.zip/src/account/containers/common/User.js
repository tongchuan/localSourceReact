import React, { Component } from 'react';
import { observer } from 'mobx-react';
import DevTools from 'mobx-react-devtools';

@observer
class User extends Component {
  render() {
    return (
      <div>
          <p>{JSON.stringify(this.props.userAjaxStore.user)}</p>

        <button onClick={this.onLoad}>
          获取用户信息
        </button>
        <DevTools />
      </div>
    );
  }

  onLoad = () => {
    this.props.userAjaxStore.getUser();
  }
};

export default User;
