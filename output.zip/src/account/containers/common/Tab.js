import React, { Component } from 'react';
import { observer } from 'mobx-react';
import DevTools from 'mobx-react-devtools';

@observer
class Tab extends Component {
  render() {
    return (
      <div>
          <p>{this.props.tabStore.name}</p>
          <p>{this.props.tabStore.age}</p>

        <button onClick={this.onReset}>
          Seconds passed: {this.props.tabStore.timer}
        </button>
          name:
          <input type="text" value={this.props.tabStore.name} onChange={ this.nameChange }/>
        <DevTools />
      </div>
    );
  }

    nameChange = (event) => {
        console.log(event.target.value);
        this.props.tabStore.name = event.target.value;
        console.log(this.props.tabStore.name);
    }

  onReset = () => {
    this.props.tabStore.resetTimer();
  }
};

export default Tab;
