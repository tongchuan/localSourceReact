/**
 * Created by liuyyg on 2017/2/8.
 */

import React from 'react';

export default class UfoeBalance extends React.Component {
    render() {
        return (
            <div>
                负债表
                <img src="/images/demo/demofzb.png"/>
            </div>
        );
    }
};