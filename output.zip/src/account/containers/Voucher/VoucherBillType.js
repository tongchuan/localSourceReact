/**
 * Created by Administrator on 2017/2/10.
 */

import React from 'react';
import { Link } from 'react-router';

export default class VoucherBillType extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            billTypeInfo:[],
            currentIndex: '',
            completeStaus: this.props.completeStatus
        };
    }

    componentDidMount() {

    }

    tabChoiced=(id)=>{
        //tab切换方法
        this.setState({
            currentIndex:id
        });

        let obj = {};
        obj.value = id;
        obj.key = "expBillQueryType";
        this.props.updateFilter(obj,true,this.props.currentPageSize);
    }
    getCurrentIndexId(){
        return this.state.currentIndex;
    }

    updateBillTypeInfo =(data) => {
        this.setState({
            billTypeInfo: data
        })
    }

    render() {
        var _this = this;
        var billTypeInfo = this.state.billTypeInfo.map(function(res,index) {
            var classStyle =res.tradetype==this.state.currentIndex ? 'portal-table-search-statu active' : 'portal-table-search-statu';
            return <span  key={'tab-' + index} onClick={this.tabChoiced.bind(_this,res.tradetype)}  className={classStyle} >{res.name+" "+res.num}</span>
        }.bind(_this));

        return (
            <li  style={{display: 'block'}}>
                <span className="portal-table-search-span">单据类型</span>
                {billTypeInfo}
            </li>
        )
    }
};
