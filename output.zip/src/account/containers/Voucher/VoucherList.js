/**
 *
 */
import React from 'react';
import * as voucher from '../../stores/voucher';

import VoucherQuery from './VoucherQuery';
import VoucherTable from './VoucherTable';

export default class VoucherList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    render() {
        return (
              <div className="voucher-content">
                <div className="head">
                  <div className="head-l">
                    <span className="books">账簿</span>
                    <span className="books-link">用友网络科技股份有限公司</span>
                  </div>
                  <div className="head-m">
                    <span>凭证列表</span>
                  </div>
                  <div className="head-r">
                    <div className="button active mr">新增</div>
                    <div className="button mr">修改</div>
                    <div className="button mr">审核</div>
                    <div className="button mr">打印</div>
                    <div className="button">更多</div>
                    <input type="image" src="/account/images/button.jpg" />
                  </div>
                </div>
                <div className="nav">
                  <div className="select select-1">
                    <select name="科目">
                      <option value="科目" selected="selected">查询方案</option>
                      <option value="期间">期间</option>
                      <option value="币种">币种</option>
                      <option value="更多条件">更多条件</option>
                    </select>
                  </div>
                  <div className="select">
                    <select name="">
                      <option value="科目" >科目</option>
                      <option value="期间" selected="selected">会计期间</option>
                      <option value="币种">币种</option>
                      <option value="更多条件">更多条件</option>
                    </select>
                  </div>
                  <div className="select">
                    <select name="">
                      <option value="科目" >科目</option>
                      <option value="期间">期间</option>
                      <option value="币种" selected="selected">日期</option>
                      <option value="更多条件">更多条件</option>
                    </select>
                  </div>
                  <div className="select">
                    <select name="">
                      <option value="科目" >科目</option>
                      <option value="期间">期间</option>
                      <option value="币种" selected="selected">凭证状态</option>
                      <option value="更多条件">更多条件</option>
                    </select>
                  </div>
                  <div className="select">
                    <select name="">
                      <option value="科目">科目</option>
                      <option value="期间">期间</option>
                      <option value="币种">币种</option>
                      <option value="更多条件" selected="selected">更多条件</option>
                    </select>
                  </div>
                  <div className="button active">搜索</div>
                </div>
                <div className="grid">
                  <table>
                    <thead>
                    <tr>
                      <th><input type="checkbox" /></th>
                      <th>期间</th>
                      <th>凭证字号</th>
                      <th>摘要</th>
                      <th>科目编码</th>
                      <th>科目名称</th>
                      <th>借方金额</th>
                      <th>贷方金额</th>
                      <th>制单人</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                      <td><input type="checkbox" /></td>
                      <td>2017年1月</td>
                      <td>记-01</td>
                      <td>个人现金</td>
                      <td>1001</td>
                      <td>库存现金</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td>王会计</td>
                    </tr>
                    <tr>
                      <td><input type="checkbox" /></td>
                      <td>2017年1月</td>
                      <td>记-01</td>
                      <td>个人现金</td>
                      <td>1001</td>
                      <td>库存现金</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td>王会计</td>
                    </tr>
                    <tr>
                      <td><input type="checkbox" /></td>
                      <td>2017年1月</td>
                      <td>记-01</td>
                      <td>个人现金</td>
                      <td>1001</td>
                      <td>库存现金</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td>王会计</td>
                    </tr>
                    <tr>
                      <td><input type="checkbox" /></td>
                      <td>2017年1月</td>
                      <td>记-01</td>
                      <td>个人现金</td>
                      <td>1001</td>
                      <td>库存现金</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td>王会计</td>
                    </tr>
                    <tr>
                      <td><input type="checkbox" /></td>
                      <td>2017年1月</td>
                      <td>记-01</td>
                      <td>个人现金</td>
                      <td>1001</td>
                      <td>库存现金</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td>王会计</td>
                    </tr>
                    <tr>
                      <td><input type="checkbox" /></td>
                      <td>2017年1月</td>
                      <td>记-01</td>
                      <td>个人现金</td>
                      <td>1001</td>
                      <td>库存现金</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td>王会计</td>
                    </tr>
                    <tr>
                      <td><input type="checkbox" /></td>
                      <td>2017年1月</td>
                      <td>记-01</td>
                      <td>个人现金</td>
                      <td>1001</td>
                      <td>库存现金</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td>王会计</td>
                    </tr>
                    <tr>
                      <td><input type="checkbox" /></td>
                      <td>2017年1月</td>
                      <td>记-01</td>
                      <td>个人现金</td>
                      <td>1001</td>
                      <td>库存现金</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td>王会计</td>
                    </tr>
                    <tr>
                      <td><input type="checkbox" /></td>
                      <td>2017年1月</td>
                      <td>记-01</td>
                      <td>个人现金</td>
                      <td>1001</td>
                      <td>库存现金</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td>王会计</td>
                    </tr>
                    <tr>
                      <td><input type="checkbox" /></td>
                      <td>2017年1月</td>
                      <td>记-01</td>
                      <td>个人现金</td>
                      <td>1001</td>
                      <td>库存现金</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td>王会计</td>
                    </tr><tr>
                      <td><input type="checkbox" /></td>
                      <td>2017年1月</td>
                      <td>记-01</td>
                      <td>个人现金</td>
                      <td>1001</td>
                      <td>库存现金</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td>王会计</td>
                    </tr>
                    <tr>
                      <td><input type="checkbox" /></td>
                      <td>2017年1月</td>
                      <td>记-01</td>
                      <td>个人现金</td>
                      <td>1001</td>
                      <td>库存现金</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td>王会计</td>
                    </tr>
                    <tr>
                      <td><input type="checkbox" /></td>
                      <td>2017年1月</td>
                      <td>记-01</td>
                      <td>个人现金</td>
                      <td>1001</td>
                      <td>库存现金</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td>王会计</td>
                    </tr>
                    </tbody>
                  </table>
                </div>
                <div className="grid-page">
                  <img src="/account/images/nav-page.jpg" alt="" />
                </div>

              </div>
        );
    }
};
