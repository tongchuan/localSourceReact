/**
 * 
 */
import React from 'react';
import * as voucher from '../../stores/voucher';

class VoucherDetail extends React.Component {
    constructor(props) {
        super(props);
        props;
        this.state = {
            cols: [
                {"field":"description","dataType":"String","title":"摘要","editType":"ncReferEditType","renderType":"ncReferRender","width":240,"sumRenderType": "certiGridComp.summarySumRender"},
                {"field":"account","dataType":"String","title":"会计科目","editType":"ncReferEditType","renderType":"ncReferRender","width":240,"sumRenderType": "certiGridComp.accountSumRender"},
                {"field":"debit_original","dataType":"float","title":"借方金额","editType":"float","width":218,"sumCol":true,"renderType":"certiGridComp.localamountRender","sumRenderType":"certiGridComp.amountSumRender"},
                {"field":"credit_original","dataType":"float","title":"贷方金额","editType":"float","width":218,"sumCol":true,"renderType":"certiGridComp.localamountRender","sumRenderType":"certiGridComp.amountSumRender"}
            ],
            rowsLength: 4,
            fileNum:" ",
            makeTime:"",
            rows:[]
        }
    }

    componentDidMount = ()=>{
        this.setVoucher();
    }

    insertRows = (rows) => {
        let _this = this;
        for (let i = 0, length = rows.length; i < length; i++) {
            return (
                <tr>
                    {
                        _this.state.cols.map(function (val, index) {
                            return (<td key={val.field+index}><span className="form-text">rows[i][val.field]</span></td>);
                        })
                    }
                </tr>);
        }
    }


    setVoucher= ()=>{
        let _this = this;
        var para = {};
        let pathname = this.props.location.pathname.split('/');
        if(pathname.length>1)
            para={"condition":"id='"+pathname[pathname.length-1]+"'"};
        _this.props.getVoucherDetail(data =>{
            if (data.success) {
                var result= data.data[0];
                _this.setState({
                    makeTime : result.maketime,
                    fileNum:result.attachedbill,
                    rows:result.bodies
                });
            } else {
                let para = {
                    message: data.message,
                    autoClose:false
                };
                // _this.handlerAlert(para);
                alert(data.messages);
            }

        },para);

    }
    formatMoney=(money)=>{
        console.log(money);
        if(money != null)
            money = parseFloat(money).toFixed(2).replace(".","");
        return money;
    }

    render() {
        let _this= this;
        let cols = _this.state.cols;
        let rows = _this.state.rows;
        // if(rows.length<=0){
        //     return(<div>测试</div>);
        // }else{
            return (
                <div>
                    <div className="certificate_wrap">
                        <span  className="tip" id="tip1"></span>
                        <div id="voucher_grid" className="voucher-grid">

                            <div className="v-header">
                                <label>账簿</label>

                                <div className="input-group v-header-input">
                                    <input type="text" className="form-control" placeholder="Search"/>
                                <span className="input-group-btn">
                                    <button className="btn btn-default  " type="button">
                                        <i className="glyphicon glyphicon-search"></i>
                                    </button>
                                </span>
                                </div>

                                <div className="v-header-page">
                                    <span className="glyphicon glyphicon-chevron-left"></span>
                                    <span className="glyphicon glyphicon-chevron-right"></span>
                                </div>
                            </div>


                            {/**table 部分 */}

                            <div className = "v-table">
                                <div className ="v-table-header">
                                    <div className="form-group fl">
                                        记字
                                        <input type="text" className="form-control v-table-input30"  placeholder="" disabled/>
                                        号
                                    </div>

                                    <div className="form-group fl ml50">
                                        <span className="fl v-table-header-font">制单日期：</span>
                                        <div className="input-group">
                                            <span ref ="makeTime">{this.state.makeTime }</span>
                                        </div>
                                    </div>


                                    <div className="form-group fr">
                                        附单据
                                        <span >{this.state.fileNum }</span>
                                        张
                                    </div>

                                </div>
                                <table id="voucher_table" className="table table-hover table-bordered">
                                    <thead>
                                    <tr>
                                        <th>摘要</th>
                                        <th>会计科目</th>
                                        <th className="v-table-th">
                                            <p>借方金额</p>
                                            <div className ="v-table-th-bg">

                                            </div>
                                        </th>
                                        <th className="v-table-th">
                                            <p>贷方金额</p>
                                            <div className ="v-table-th-bg">

                                            </div>
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody id="voucher_tbody">
                                    {
                                        _this.state.rows.map((row, idx) => {
                                            return(<tr key={"tr-"+idx}>
                                                {
                                                    _this.state.cols.map(function (item, i) {
                                                        if(item.dataType =="float"){
                                                            return (<td className = "v-table-td-bg" key={"td-"+idx+"-"+i}>{
                                                                _this.formatMoney(row[item.field])}</td>);
                                                        }else{
                                                            return (<td key={"td-"+idx+"-"+i}>{row[item.field]}</td>);
                                                        }
                                                    })
                                                }
                                            </tr>)

                                        })
                                    }

                                    <tr>
                                        <td colSpan="2">合计：</td>
                                        <td><input className="form-control" data-type ="float" /></td>
                                        <td><input className="form-control" data-type ="float" /></td>
                                    </tr>
                                    </tbody>
                                </table>




                            </div>



                        </div>
                        <div className="maker">
                            <span id="certi-username"></span>
                        </div>
                    </div>




                </div>
            );
        }

    // }
};

export default VoucherDetail;
