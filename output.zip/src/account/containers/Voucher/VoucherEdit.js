/**
 *
 */
import React from 'react';
import * as voucher from '../../stores/voucher';

class VoucherEdit extends React.Component {
    constructor(props) {
        super(props);
        props;
        this.state = {
        }
    }

    componentWillMount = ()=>{
    }

    render() {
        return (
          <div className="certificate">
              <div className="head">
                  <div className="head-l">
                      <div className="button active mr button-new">保存并新增</div>
                      <div className="button mr">保存</div>
                      <div className="upload">
                          <div className="button">上传</div>
                          <input type="image" src="/account/images/button.jpg" />
                      </div>
                      <div className="button">模板</div>
                      <input type="image" src="/account/images/button.jpg" />
                  </div>
                  <div className="head-m"><span>记账凭证</span></div>
                  <div className="head-r">
                      <div className="voucheright mr"><img src="/account/images/voucher-right.jpg" alt="" /></div>
                      <div className="button vouncher-more">更多凭证</div>
                  </div>
              </div>
              <div className="voucher-grid">
                  <div className="voucher-grid-head">
                      <div className="grid-select">
                          <select>
                              <option value="" selected="selected">记</option>
                              <option value="">期间</option>
                              <option value="">币种</option>
                              <option value="">更多条件</option>
                          </select>
                      </div>
                      <div className="grid-input">
                              <input type="text" id="exampleInputName2" placeholder="" />
                              <span className="grid-input-span">号</span>
                      </div>
                      <div className="grid-date">
                          <span className="grid-date-left">日期</span><input type="date" placeholder="" />
                      </div>
                      <div className="grid-bill">
                          <div className="gird-bill-center">
                              <span>单据</span> <span className="span">0</span><span>张</span>
                          </div>
                      </div>

                  </div>

                  <table className="table table-bordered table-hover add-proof">
                      <thead>
                   <tr>
                      <th>摘要</th>
                      <th>会计科目</th>
                      <th>
                          借方金额
                      </th>
                      <th>
                          贷方金额
                      </th>
                  </tr>
                   </thead>
                  <tbody>
                  <tr>
                      <td>北京银行存款单</td>
                      <td>1002 北京银行 涉及到部分的参照类型</td>
                      <td className ="add-proof-m">8888.00</td>
                      <td className ="add-proof-m">127.00</td>
                  </tr>
                  <tr>
                      <td>北京银行存款单</td>
                      <td>1002 北京银行 涉及到部分的参照类型</td>
                      <td className ="add-proof-m">8888.00</td>
                      <td className ="add-proof-m">127.00</td>
                  </tr>
                  <tr>
                      <td>北京银行存款单</td>
                      <td>1002 北京银行 涉及到部分的参照类型</td>
                      <td className ="add-proof-m">8888.00</td>
                      <td className ="add-proof-m">127.00</td>
                  </tr>
                  <tr>
                      <td>北京银行存款单</td>
                      <td>1002 北京银行 涉及到部分的参照类型</td>
                      <td className ="add-proof-m">8888.00</td>
                      <td className ="add-proof-m">127.00</td>
                  </tr>
                  <tr>
                      <td>北京银行存款单</td>
                      <td>1002 北京银行 涉及到部分的参照类型</td>
                      <td className ="add-proof-m">8888.00</td>
                      <td className ="add-proof-m">127.00</td>
                  </tr>
                  <tr>
                      <td>北京银行存款单</td>
                      <td>1002 北京银行 涉及到部分的参照类型</td>
                      <td className ="add-proof-m">8888.00</td>
                      <td className ="add-proof-m">127.00</td>
                  </tr>
                  <tr>
                      <td colSpan="2">合计</td>
                      <td className ="add-proof-m">8888.00</td>
                      <td className ="add-proof-m">127.00</td>
                  </tr>
                  </tbody>
              </table>
              <div className="voucher-grid-bottom">
                  <div className="bottom-div">记账人: <span>王会计</span></div>
                  <div className="bottom-div">审核人: <span>王会计</span></div>
                  <div className="bottom-div">出纳: <span>王会计</span></div>
                  <div className="bottom-div">制单人: <span>王会计</span></div>
              </div>
          </div>
        </div>
          
       );
    }
};

export default VoucherEdit;
