/**
 *
 */
import React from 'react';
import * as voucher from '../../stores/voucher';
import { Link } from 'react-router';

import VoucherQueryState from './VoucherQueryState';
import VoucherBillType from './VoucherBillType';
import VoucherBooks from './VoucherBooks';
import VoucherTimeRange from './VoucherTimeRange';
import VoucherQueryFuzzySearch from './VoucherQueryFuzzySearch';

export default class VoucherQuery extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            data: {
                "isHasComplete": this.props.isHasComplete,
                "isHasCompletePortlet":this.props.isHasCompletePortlet,
                "expBillQueryType": "",
                "billStateQuery": "",
                "likeQueryValue": "",
                "index": this.props.index,
                "size": this.props.pageSize,
                "EALINKID":"oneWeek"
            }
        };
    }

    handleFilterUpdate = (obj,isGoPageAction,pageSize) => {
        let currentData = this.state.data;
        currentData[obj.key] = obj.value;
        this.query(currentData,isGoPageAction,pageSize);
    }

    resetTheIndexOfState = () => {
        this.setState({
            index: 0
        });
    }

    componentDidMount() {
        this.query(this.state.data,true,this.state.data.size);
    }

    query = (data,isGoPageAction,pageSize) => {
        //获取数据(Ajax)
        $.ajax({
            type:"post",
            url: this.props.queryUrl,
            dataType: "json",
            headers: {
                "Content-Type": "application/json; charset=utf-8"
            },
            //headers: {
            //    "Accept": "application/json; charset=utf-8"
            //},
            data: JSON.stringify(data),
            //data: data,
            success: data => {
                //触发事件
                this.props.onQuery(data,isGoPageAction,pageSize);
                this.refs.billtype.updateBillTypeInfo(data.countData);
            },
            error: (xhr, status, err) => {
                console.log(err.toString());
            }
        });
    }

    render() {

        if(this.state.data.isHasCompletePortlet=="true"){
            return (
                <ul className="portal-table-search">
                    <VoucherTimeRange currentPageSize={this.state.data.size}  updateFilter={this.handleFilterUpdate}/>
                    <VoucherBillType ref="billtype" completeStatus="true" currentPageSize={this.state.data.size}   updateFilter={this.handleFilterUpdate}/>
                    <VoucherQueryFuzzySearch ref="billLikeQuery" updateFilter={this.handleFilterUpdate}  />
                </ul>
            )
        }else {
            return (
                <ul className="portal-table-search">
                    {/**
                    <VoucherQueryState currentPageSize={this.state.data.size} updateFilter={this.handleFilterUpdate}/>
                    <VoucherBillType ref="billtype" completeStatus="false" currentPageSize={this.state.data.size} updateFilter={this.handleFilterUpdate}/>
                    **/}
                    <VoucherBooks ref="billLikeQuery" updateFilter={this.handleFilterUpdate} />
                    <VoucherTimeRange currentPageSize={this.state.data.size}  updateFilter={this.handleFilterUpdate}/>
                    <VoucherQueryFuzzySearch ref="billLikeQuery" updateFilter={this.handleFilterUpdate} />
                </ul>
            )
        }
    }
};
