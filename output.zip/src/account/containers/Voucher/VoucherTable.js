/**
 *
 */
import React from 'react';
import * as voucher from '../../stores/voucher';
import { Grid } from 'ssc-comp';

class VoucherTable extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            voucherList:''
        };
    }

    componentWillMount =() =>{
    }

    // 查询凭证列表
    queryVoucherData =() =>{
        var param ={
            condition:''
        };
        var _this = this ;
        this.props.getVoucherDetail(json =>{
            var _list = [];
            $.each (json.data , function(idx,obj){
                _list.push({
                    "creationtime":obj.creationtime
                })
            })
            _this.setState({
                voucherList:_list
            })
        },param )
    }

   renderTable = ()=>{
       this.queryVoucherData() ;
       const tableData = this.state.voucherList ;
       if( !tableData ){return false };
       // 每个分页显示三行数据
       const ItemsPerPage = 3;
       const mockColumnsData = [
           {key: 'date', id:'creationtime','label': '创建日期'}

           /*{key: 'enum', 'label': '单据类型',
               data: [
                   {key: '2631', value: '差旅费借款单'},
                   {key: '2632', value: '会议费借款单'},
                   {key: 'D3', value: '付款单'}
               ]
           },
           {key: 'double', 'label': '金额'},
           {key: 'date', label: '单据日期'},
           {key: 'boolean', label: '启用'},
           {key: 'enum', label: '性别', data: [
               {
                   key: 'male',
                   value: '男'
               },
               {
                   key: 'female',
                   value: '女'
               }
           ]},
           {key: 'ref', label: '组织（参照类型）'}*/
       ];

       var table = (
           <Grid columnsModel={mockColumnsData} tableData={tableData} paging checkboxColumn={true}/>
        );
       return table ;
   }


    render() {
        var _this = this ;
        return (
            <div>
                {_this.renderTable()}
            </div>
          )

    }
};

export default VoucherTable;