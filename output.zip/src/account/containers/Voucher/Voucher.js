/**
 * 凭证录入组件页面
 */
import React from 'react';
import TabStore from '../../stores/TabStore';
import Tab from '../common/Tab';

const tabStore = new TabStore();

class Voucher extends React.Component {
    render() {
        return (
          <div>
            {this.props.children}
          </div>
        );
    }
}

export default Voucher;