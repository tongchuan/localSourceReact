/**
 *
 */
import React from 'react';
import * as voucher from '../../stores/voucher';

import DateTimePicker from '../../../common/components/SimpleDateTimePicker' ;
import StaticModel from '../../../common/components/StaticModel';
import {Button} from 'react-bootstrap'

class VoucherEdit_Old extends React.Component {
    constructor(props) {
        super(props);
        props;
        this.state = {
            cols: [
                {"field":"description","dataType":"String","title":"摘要","editType":"ncReferEditType","renderType":"ncReferRender","width":240,"sumRenderType": "certiGridComp.summarySumRender"},
                {"field":"account","dataType":"String","title":"会计科目","editType":"ncReferEditType","renderType":"ncReferRender","width":240,"sumRenderType": "certiGridComp.accountSumRender"},
                {"field":"debit_original","dataType":"float","title":"借方金额","editType":"float","width":218,"sumCol":true,"renderType":"certiGridComp.localamountRender","sumRenderType":"certiGridComp.amountSumRender"},
                {"field":"credit_original","dataType":"float","title":"贷方金额","editType":"float","width":218,"sumCol":true,"renderType":"certiGridComp.localamountRender","sumRenderType":"certiGridComp.amountSumRender"}
            ],
            //                {"field":"pk_help","dataType":"String","title":"辅助核算","editType":"ncReferEditType","renderType":"ncReferRender","width":260,"sumRenderType": "certiGridComp.accountSumRender"},
            rowsLength: 4,
            fileNum:""
        }
    }

    componentWillMount = ()=>{
        let currentTime = this.getCurrentTime() ;
        this.setState({
            currentTime : currentTime
        })
    }

    // 初始化时间 ，获取当前日期
    getCurrentTime = () => {
        var datetime = new Date();
        var year = datetime.getFullYear();
        var month = datetime.getMonth() + 1 < 10 ? "0" + (datetime.getMonth() + 1) : datetime.getMonth() + 1;
        var date = datetime.getDate() < 10 ? "0" + datetime.getDate() : datetime.getDate();
        return year + "-" + month + "-" + date ;
    }
    setCurrentTime =(event)=>{
        this.setState({
            currentTime : event.target.value
        })
    }
    setFileNum =(event)=>{
        this.setState({
            fileNum : event.target.value
        })
    }




    insertRow = () => {
        let _this = this;
               return (
                <tr>
                    {
                        _this.state.cols.map(function(val,i){
                            if(val.dataType == "String"){
                                return(<td key={val.field+i}  onClick={_this.focusIn}><span className="form-text"></span><textarea className="form-control" ref="" onBlur={_this.blurOut} data-type={val.dataType} data-field ={val.field}></textarea></td>);
                            }else if(val.dataType == "float"){
                                return(<td key={val.field+i} className = "v-table-td-bg" onClick={_this.focusIn}><span className="form-text"></span><input className="form-control" onBlur={_this.blurOut} data-type={val.dataType} data-field ={val.field}/></td>);
                            }
                        })
                    }
                </tr>);
    }
    insertRows = (count) => {
        let _this = this;
        for(let i = 0;i<count;i++){
            _this.insertRow();
        }
    }
    deleteRow = (data) => {
        //remove
    }

    focusIn = (event) =>{
        let that = event.target;
        let value = $(that).children(".form-text").addClass("hidden").html();
        let type = $(that).children(".form-control").attr("data-type");
        if(type=="float"&& value!="")
            value = value.substring(0,value.length-2)+"."+value.substring(value.length-2,value.length)
        $(that).children(".form-control").css({"visibility":"visible"}).focus().val(value);
        // $("#voucher_grid")
    }
    blurOut = (event) =>{
        let that = event.target;
        $(that).css({"visibility":"hidden"});
        let value = $(that).val();
        let type = $(that).attr("data-type");
        if(type=="float"&& value!="")
            value=parseFloat(value).toFixed(2).replace(".","");
        $(that).prev().removeClass("hidden").html(value);
    }

    // 输入金额

    focusInMoney = (event) =>{
        let that = event.target;
        $(that).children(".form-control").css({"visibility":"visible"}).focus();

       //  $(that).parent(".v-table-td-bg").css("background","none");
        // $("#voucher_grid")
    }
    saveVoucher= ()=>{
        let _this = this;

        let time = this.state.currentTime;
        let file = this.state.fileNum;
        var formData = [];

        let bodiesLength = $("#voucher_tbody tr").length;//.find(".form-control");
        console.log(time);
        for(let i = 0;i<bodiesLength;i++){
            let tr = $("#voucher_tbody tr:eq("+i+")");
            let formInputs = tr.find(".form-control");
            var formItem={}
            for(let index =0,length = formInputs.length;index<length;index++){
                let val = $(formInputs)[index];
                let value=$(val).val();
                if(value!=""){
                    let key = $(val).attr("data-field");
                    formItem[key]=value;
                }
            }
            if($.isEmptyObject(formItem)){
                continue;

            }else{
                formData.push(formItem);
            }
        }
        // let para = {"maketime":time,"attachedbill":file,"bodies":formData};
        let para = {"attachedbill":file,"bodies":formData};
        this.props.saveVoucherData(data => {
            if (data.success) {
                let alert = {
                    message: "保存成功"
                };
                console.log(data);
                // _this.handlerStaticModel(alert);
                debugger;
                location.hash="#/voucher/detail/"+data.data.id;
            } else {
                let alert = {
                    message: "保存失败！" + data.message
                };
                _this.handlerStaticModel(alert);
            }
        }, para);

    }
    handlerStaticModel = (para) => {
        this.refs.alertmodel.showAlert(para);
    };
    render() {
        let _this= this;
        return (
            <div>
                <StaticModel ref="alertmodel"/>
                <div className="certificate_wrap">
		            <span  className="tip" id="tip1"></span>
                    <div id="voucher_grid" className="voucher-grid">

                        <div className="v-header">
                            <button className="v-header-addSave " type="button" onClick={_this.insertRow.bind(this)}>保存并新增</button>
                            <button className="v-header-add" type="button"  onClick={_this.saveVoucher.bind(this)}>保存</button>
                            <label>账簿</label>

                            <div className="input-group v-header-input">
                                <input type="text" className="form-control" placeholder="Search"/>
                                <span className="input-group-btn">
                                    <button className="btn btn-default  " type="button">
                                        <i className="glyphicon glyphicon-search"></i>
                                    </button>
                                </span>
                            </div>

                            <div className="v-header-page">
                                <span className="glyphicon glyphicon-chevron-left"></span>
                                <span className="glyphicon glyphicon-chevron-right"></span>
                            </div>
                        </div>


                        {/**table 部分 */}

                        <div className = "v-table">
                            <div className ="v-table-header">
                                <div className="form-group fl">
                                    记字
                                    <input type="text" className="form-control v-table-input30"  placeholder=""/>
                                    号
                                </div>

                                <div className="form-group fl ml50">
                                    <span className="fl v-table-header-font">制单日期：</span>
                                    <div className="input-group">
                                        <DateTimePicker value={this.state.currentTime } onChange={this.setCurrentTime}/>
                                    </div>
                                </div>


                                <div className="form-group fr">
                                    附单据
                                    <input type="text"  className="form-control v-table-input30"  placeholder="" value={this.state.fileNum } onChange={this.setFileNum}/>
                                    张
                                </div>

                            </div>



                            <table id="voucher_table" className="table table-hover table-bordered">
                                <thead>
                                <tr>
                                    <th>摘要</th>
                                    <th>会计科目</th>
                                    <th className="v-table-th">
                                        <p>借方金额</p>
                                        <div className ="v-table-th-bg">

                                        </div>
                                    </th>
                                    <th className="v-table-th">
                                        <p>贷方金额</p>
                                        <div className ="v-table-th-bg">

                                        </div>
                                    </th>
                                </tr>
                                </thead>
                                <tbody id="voucher_tbody">
                                {
                                    _this.insertRow()
                                }{
                                    _this.insertRow()
                                }{
                                    _this.insertRow()
                                }{
                                    _this.insertRow()
                                }
                                <tr>
                                    <td colSpan="2">合计：</td>
                                    <td><input className="form-control" data-type ="float" /></td>
                                    <td><input className="form-control" data-type ="float" /></td>
                                </tr>
                                </tbody>
                            </table>




                        </div>



                    </div>
                    <div className="maker">
                        <span id="certi-username"></span>
                    </div>
                </div>




            </div>
        );
    }
};

export default VoucherEdit_Old;
