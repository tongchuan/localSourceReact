/**
 * Created by Administrator on 2017/2/13.
 */

import React from 'react';
import { Link } from 'react-router';

export default class VoucherQueryFuzzySearch extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            value: ""
        }
    }

    componentDidMount() {

    }

    handleChange =(event) =>  {
        this.setState({value: event.target.value});
    }

    updateQuery = () => {
        let obj = {};
        obj.value = this.state.value;
        obj.key = "likeQueryValue";
        this.props.updateFilter(obj);
    }

    getCurrentBillNo =() => {
        return this.state.value;
    }

    render() {
        var billNo = this.state.value;
        return (
            <li>
                <span className="portal-table-search-span">账簿</span>
                <input  type="text" placeholder="单据编号"  value={billNo} onChange={this.handleChange}   />
                <span  onClick={this.updateQuery} className="portal-table-search-btn">
                    <i className="glyphicon glyphicon-search"></i>查询
                </span>
            </li>
        )
    }
};
