/**
 * Created by liuyyg on 2017/2/8.
 * 余额表
 */

import React from 'react';

export default class AccountBalance extends React.Component {
    render() {
        return (
            <div>
                余额表
                <img src="/images/demo/demoye.png"/>
                <img src="/images/demo/demoye2.png"/>
            </div>
        );
    }
};