/**
 * Created by liuyyg on 2017/2/8.
 * 明细账
 */
import React from 'react';

export default class AccountSubsidiary extends React.Component {
    render() {
        return (
          <div className="detailist">
            <div className="head">
              <div className="head-l"><span className="books">核算单位</span><span className="books-link">用友网络科技股份有限公司</span></div>
              <div className="head-m"><span>明细表</span></div>
              <div className="head-r">
                <div className="button mr">打印</div>
                <div className="button mr">导出</div>
                <div className="button">更多</div>
                <input type="image" src="/account/images/button.jpg" />
              </div>
            </div>
            <div className="nav">
              <div className="select">
                <select name="科目">
                  <option value="科目" selected="selected">科目</option>
                  <option value="期间">期间</option>
                  <option value="币种">币种</option>
                  <option value="更多条件">更多条件</option>
                </select>
              </div>
              <div className="select">
                <select name="">
                  <option value="科目" >科目</option>
                  <option value="期间" selected="selected">期间</option>
                  <option value="币种">币种</option>
                  <option value="更多条件">更多条件</option>
                </select>
              </div>
              <div className="select">
                <select name="">
                  <option value="科目" >科目</option>
                  <option value="期间">期间</option>
                  <option value="币种" selected="selected">币种</option>
                  <option value="更多条件">更多条件</option>
                </select>
              </div>
              <div className="select">
                <select name="">
                  <option value="科目">科目</option>
                  <option value="期间">期间</option>
                  <option value="币种">币种</option>
                  <option value="更多条件" selected="selected">更多条件</option>
                </select>
              </div>
              <div className="button active">搜索</div>
            </div>

            <div className="detailist-content clearfix">
              <div className="detailist-content-left">
                <div className="detailist-content-left-input">
                  <input type="text" value="输入科目编码或名称" />
                  <img src="/account/images/search-input.jpg" alt="" />
                </div>
                <div className="tree">
                  <div className="tree-head">&nbsp;库存现金</div>
                  <div>
                    <ul>
                      <li><a href="#">100101_个人现金</a></li>
                      <li><a href="#">100101_个人现金</a></li>
                      <li><a href="#">100101_个人现金</a></li>
                    </ul>
                  </div>
                </div>
                <div className="tree middle">
                  <div className="tree-head">&nbsp;库存现金</div>
                  <ul>
                    <div>
                      <div className="tree-head-middle">100101_个人现金</div>
                      <ul style={{display: "none"}}>
                        <div className="tree-head-middle">100101_个人现金</div>
                        <li><a href="#">100101_个人现金</a></li>
                      </ul>
                    </div>
                    <li><a href="#">100101_个人现金</a></li>
                  </ul>
                </div>
                <div className="tree tree-bottom">
                  <div className="tree-head">&nbsp;库存现金</div>
                  <ul style={{display: "none"}}>
                    <li><a href="#">100101_个人现金</a></li>
                    <li><a href="#">100101_个人现金</a></li>
                    <li><a href="#">100101_个人现金</a></li>
                  </ul>
                </div>
                <div className="tree tree-bottom">
                  <div className="tree-head">&nbsp;库存现金</div>
                  <ul style={{display: "none"}}>
                    <li><a href="#">100101_个人现金</a></li>
                    <li><a href="#">100101_个人现金</a></li>
                    <li><a href="#">100101_个人现金</a></li>
                  </ul>
                </div>
              </div>
              <div className="detailist-content-right">
                <div className="grid">
                  <table>
                    <thead>
                    <tr>
                      <th>期间</th>
                      <th>凭证</th>
                      <th>科目</th>
                      <th>摘要</th>
                      <th>借方</th>
                      <th>贷方</th>
                      <th>方向</th>
                      <th>金额</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                      <td>2017.0125</td>
                      <td>记-01</td>
                      <td>1001-库存现金</td>
                      <td>期初余额</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td className="grid-redcolor">借</td>
                      <td>6209.00</td>
                    </tr>
                    <tr>
                      <td>2017.0125</td>
                      <td>记-01</td>
                      <td>1001-库存现金</td>
                      <td>期初余额</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td className="grid-greencolor">贷</td>
                      <td>6209.00</td>
                    </tr>
                    <tr>
                      <td>2017.0125</td>
                      <td>记-01</td>
                      <td>1001-库存现金</td>
                      <td>期初余额</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td className="grid-redcolor">借</td>
                      <td>6209.00</td>
                    </tr>
                    <tr>
                      <td>2017.0125</td>
                      <td>记-01</td>
                      <td>1001-库存现金</td>
                      <td>期初余额</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td className="grid-redcolor">借</td>
                      <td>6209.00</td>
                    </tr>
                    <tr>
                      <td>2017.0125</td>
                      <td>记-01</td>
                      <td>1001-库存现金</td>
                      <td>期初余额</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td className="grid-redcolor">借</td>
                      <td>6209.00</td>
                    </tr>
                    <tr>
                      <td>2017.0125</td>
                      <td>记-01</td>
                      <td>1001-库存现金</td>
                      <td>期初余额</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td className="grid-greencolor">贷</td>
                      <td>6209.00</td>
                    </tr>
                    <tr>
                      <td>2017.0125</td>
                      <td>记-01</td>
                      <td>1001-库存现金</td>
                      <td>期初余额</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td className="grid-redcolor">借</td>
                      <td>6209.00</td>
                    </tr>
                    <tr>
                      <td>2017.0125</td>
                      <td>记-01</td>
                      <td>1001-库存现金</td>
                      <td>期初余额</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td className="grid-redcolor">借</td>
                      <td>6209.00</td>
                    </tr>
                    <tr>
                      <td>2017.0125</td>
                      <td>记-01</td>
                      <td>1001-库存现金</td>
                      <td>期初余额</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td className="grid-redcolor">借</td>
                      <td>6209.00</td>
                    </tr>
                    <tr>
                      <td>2017.0125</td>
                      <td>记-01</td>
                      <td>1001-库存现金</td>
                      <td>期初余额</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td className="grid-redcolor">借</td>
                      <td>6209.00</td>
                    </tr>
                    <tr>
                      <td>2017.0125</td>
                      <td>记-01</td>
                      <td>1001-库存现金</td>
                      <td>期初余额</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td className="grid-redcolor">借</td>
                      <td>6209.00</td>
                    </tr>
                    <tr>
                      <td>2017.0125</td>
                      <td>记-01</td>
                      <td>1001-库存现金</td>
                      <td>期初余额</td>
                      <td>10.00</td>
                      <td>10.00</td>
                      <td className="grid-redcolor">借</td>
                      <td>6209.00</td>
                    </tr>


                    </tbody>
                  </table>
                </div>
                <div className="grid-page">
                  <img src="/account/images/grid-bottom-2.jpg" alt="" />
                </div>
              </div>

            </div>

          </div>
        );
    }
};
