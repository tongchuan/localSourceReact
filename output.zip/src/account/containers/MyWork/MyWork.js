/**
 * 工作台页面组件
 */
import React from 'react';
import TabStore from '../../stores/TabStore';
import Tab from '../common/Tab';
import UserAjaxStore from '../../stores/UserAjaxStore';
import User from '../common/User';


const tabStore = new TabStore();
const userAjaxStore = new UserAjaxStore();

class MyWork extends React.Component {
    render() {
        return (
            <div>
                <div className="main">
                  <div className="head clearfix">
                    <div className="head-l">
                      早上好！目前您登陆的公司账号为: <span className="gongsi">用友网络科技股份有限公司</span>
                    </div>
                    <div className="head-m">
                      上次登录时间为 <span className="gongsi">2017/2/14&nbsp;09:14:19</span>,祝您工作愉快！
                    </div>
                    <div className="head-r">
                      <img src="/account/images/shezhi.png" alt="" />
                    </div>
                  </div>
                  <div className="middle clearfix">
                    <div className="middle-1 middle-img">
                      <div className="img"><img src="/account/images/photo1.jpg" alt=""/></div>
                      <p>实时预算完成率</p>
                    </div>
                    <div className="middle-2 middle-img">
                      <div className="img"><img src="/account/images/photo1.jpg" alt=""/></div>
                      <p>实时预算完成率</p>
                    </div>
                    <div className="middle-3 middle-img">
                      <div className="img"><img src="/account/images/photo1.jpg" alt=""/></div>
                      <p>实时预算完成率</p>
                    </div>
                    <div className="middle-4 middle-img">
                      <div className="img"><img src="/account/images/photo1.jpg" alt=""/></div>
                      <p>实时预算完成率</p>
                    </div>
                  </div>
                  <div className="middle-line">
                    <div className="middle-line-span"><span>您最近打开：</span></div>
                    <hr />
                  </div>
                  <div className="bottom clearfix">
                    <div className="bottom-1 bottom-img">
                      <h3><span>新增凭证</span></h3>
                      <p><img src="/account/images/photo2.png" alt=""/></p>
                    </div>
                    <div className="bottom-2 bottom-img ">
                      <h3><span>查看凭证</span></h3>
                      <p><img src="/account/images/photo2.png" alt=""/></p>
                    </div>
                    <div className="bottom-3 bottom-img">
                      <h3><span>总账</span></h3>
                      <p><img src="/account/images/photo2.png" alt=""/></p>
                    </div>
                    <div className="bottom-4 bottom-img ">
                      <h3><span>查询凭证</span></h3>
                      <p><img src="/account/images/photo2.png" alt=""/></p>
                    </div>
                  </div>
                  <div className="bottom2 clearfix">
                    <div className="bottom-1 bottom-img">
                      <h3><span>明细账</span></h3>
                      <p><img src="/account/images/photo2.png" alt=""/></p>
                    </div>
                    <div className="bottom-2 bottom-img ">
                      <h3><span>科目余额表</span></h3>
                      <p><img src="/account/images/photo2.png" alt=""/></p>
                    </div>
                    <div className="bottom-3 bottom-img">
                      <h3><span>科目余额表</span></h3>
                      <p><img src="/account/images/photo2.png" alt=""/></p>
                    </div>
                    <div className="bottom-4 bottom-img ">
                      <h3><span>科目余额表</span></h3>
                      <p><img src="/account/images/photo2.png" alt=""/></p>
                    </div>
                  </div>
                </div>

                {/*<Tab tabStore={tabStore}/>*/}
              {
                /* <User userAjaxStore={userAjaxStore}/>*/
              }
            </div>
        );
    }
}

export default MyWork;
