/**
 * Created by liuyyg on 2017/2/9.
 */
import React from 'react';

export default class SettingSubject extends React.Component {
    render() {
        return (
            <div>
                科目期初
                <img src="/images/demo/demokm.png"/>
            </div>
        );
    }
};