/**
 * Created by liuyyg on 2017/2/9.
 */
import React from 'react';

export default class SettingAccount extends React.Component {
    render() {
        return (
            <div>
                账套设置
                <img src="/images/demo/demozt.png"/>
            </div>
        );
    }
};