/**
 * Created by liuyyg on 2017/2/9.
 */
import React from 'react';

export default class SettingBasic extends React.Component {
    render() {
        return (
            <div>
                辅助核算
                <img src="/images/demo/demofzhs.png"/>
            </div>
        );
    }
};