/**
 * 基础设置页面组件
 */
import React from 'react';
import TabStore from '../../stores/TabStore';
import Tab from '../common/Tab';

const tabStore = new TabStore();

class Setting extends React.Component {
    render() {
        return (
            <div>
              {this.props.children}
            </div>
        );
    }
}

export default Setting;
