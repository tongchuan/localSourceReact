/**
 * Created by liuyyg on 2017/1/17.
 */
import Api from '../../common/restfulApi';
import Config from '../config'

var rootPath = Config.serverUrl;
var api = new Api(rootPath);

export function getVoucherData(callback) {
    return (dispatch, getState) => {
        api.postApi(url, state => {
            console.log(state);
        },suss =>{
            if (suss.success == true) {
                if (typeof callback === 'function') {
                    callback(suss.rows);
                }
            }
        },err => {
            console.log(err);
        });
    };

}
export function getVoucherDetail(callback, para) {
    return () => {
        $.ajax({
            type: "POST",
            url: Config.account.voucherDetail,
            contentType: "application/x-www-form-urlencoded",
            // headers: {
            //     "Accept": "application/x-www-form-urlencoded; charset=utf-8"
            // },
            data: para,
            success: data => {
                if (typeof callback === 'function') {
                    callback(data);
                }
            },
            error: (xhr, status, err) => {
                console.log(err.toString());
            }
        });
    };
}
export function saveVoucherData(callback,para) {
    return () => {
        $.ajax({
            type: "POST",
            url: Config.account.voucherSave,
            dataType: "json",
            contentType: "application/json",
            headers: {
                "Accept": "application/json; charset=utf-8"
            },
            data: JSON.stringify(para),
            success: data => {
                if (typeof callback === 'function') {
                    callback(data);
                }
            },
            error: (xhr, status, err) => {
                console.log(err.toString());
            }
        });
    };

}