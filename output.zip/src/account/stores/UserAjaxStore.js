import {observable} from 'mobx';
// import Api from '../../common/restfulApi';
// import Config from '../config'
import fetch from 'isomorphic-fetch';
// var rootPath = Config.serverUrl;
// var api = new Api(rootPath);

// const f = () => {
//     return new Promise((resolve, reject) => {
//         setTimeout(() => {
//             resolve(123);
//         }, 2000);
//     });
// };
//
// const testAsync = async() => {
//     const t = await f();
//     console.log(t);
// };


class UserAjaxStore {
    @observable user = {};
    constructor() {
    }

    getUser() {
        fetch('https://api.github.com/users/atom')
            .then((res)=>res.json())
            .then((json)=> {
                console.log("json:", json);
                this.user = json;
            });
    }
}

export default UserAjaxStore;