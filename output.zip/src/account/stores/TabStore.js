import { observable } from 'mobx';

class TabStore {
  @observable timer = 0;
  @observable name = 'test name';
  @observable age = 20;

  constructor() {
    setInterval(() => {
      this.timer += 5;
    }, 1000);
  }

  resetTimer() {
    this.timer = 0;
  }
  
  rename(val) {
    this.name = val;
  }
}

export default TabStore;