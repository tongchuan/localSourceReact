# 财务云前端项目—友报账
## 上线环境地址https://ybz.yonyoucloud.com/workbench/
    用户名 17712345674
    密码 a123456
    内部体验账号：
        管理员：15512341234/123456a
        员工：15512341235/a123456
        经理：15512341236/a123456
        会计：15512341237/a123456
        出纳：15512341238/a123456

#### 开发环境
```
npm run start
```

#### 发布
```
npm run expense:aly
```
## 此项目中包含的功能
    首页homepage
    我的单据列表
    待审批/已审批
    支付结算列表
    我的账本（此版本未做）
## 项目目录
### 友报账expense

<pre>
ROOT
|-- src
|   |-- client
|   |-- common
|   |   |-- actions
|   |   |-- components
|   |   |-- containers
|   |   |-- middlewares
|   |   `-- store
|   `-- server
|-- static
`-- test
</pre>


